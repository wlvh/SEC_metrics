"""Read an 8-K item's own text for E01's content-confirmed meaning.

E01's approved definition counts items 1.01, 2.01 and 8.01 and says of the last
"8.01 需正文关键词确认". The frozen matcher (``deterministic_router.
match_event_claims``) compares the declared aliases with each claim's
``brief``, and when the filing's hdr.sgml carries item codes - every saved 8-K
here - that brief is the program's own sentence ``"8-K item 8.01 parsed from
hdr.sgml"``, so no 8.01 was ever read. The router is frozen by every
``issue_28`` generation and the ordinary route uses it unchanged.

The owner's decision (recorded with the other owner decisions under
docs/evidence/issue47_history/) replaced the meaning for the historical route:
E01 counts content-confirmed M&A announcements - an item counts when its own
text reports a merger, acquisition, disposition or business combination the
registrant or a subsidiary is party to, whichever candidate code it is filed
under, and a keyword never confirms one. Over the forty saved 8.01 items a
keyword rule was right twice, wrong five times and missed three transactions,
and eleven of the thirteen 1.01 items in the answered windows are borrowing
agreements (docs/evidence/issue47_history/e01-item-text/census.json,
e01-keyword-branch/decision.json), so no item-code or keyword rule stands in
for the reading.

The successor route (catalog/r6/E01_content_confirmed_ma_v1.json) names the
approved route it replaces by hash, keeps the approved candidate codes, and
carries the confirmation meaning. What this module owns is reading each
candidate: it locates the item in the filing's primary document and reads its
text from its heading to the next item heading or the signatures, and binds
that span to its bytes, so a confirmation can be asked of exactly that span.
Nothing here confirms a candidate. A window with a candidate whose confirmation
is not registered is withheld by name, listing each candidate; a window with no
candidate item is answered zero. Values and acceptances under the approved
definition do not carry over: the successor route has its own hash, so its
Spec, and every acceptance bound to a Spec, is a different one.

The heading is found in the frozen ``_visible_text`` view of the primary bytes,
so a reader can rebuild the same span from the same bytes. A heading is an
``Item x.yy`` occurrence followed by a capitalised word and not introduced by a
word that makes it a reference ("into this Item 2.03", or "under" before an item's
name) or by an opening quotation mark. Consecutive headings of one item - its
number, then the same number with a lettered part, as 5.02 and 5.02(b) - are one
item. An item that cannot be located, or that is headed
twice with another item between, stops the answer by name: an unread item
never counts and never silently fails to count.

The frozen view keeps every text node of the document, including those a
reader never sees: <style>, <script>, the inline-XBRL ix:hidden header and
anything styled display:none. So the view is rebuilt beside it, node by node,
with what hides each node recorded, and the rebuilt text must equal the frozen
view; an item whose span holds a node that is hidden, or styled so that it
cannot be seen (zero opacity or font size, transparent colour, pushed a
thousand points off the page), is refused by name rather than read with text
nobody reading the filing saw. Ordinary colours and hanging indents are not
hiding: measured over the 56 candidate items of the 51 saved 8-Ks, every
document carries hidden text somewhere and no item span does, and a rule that
refused any inline colour, position or background would have refused 36 of
the 56. An item must also end where exactly one reading says it ends: the item
heading that ends it is that code's only section after the item starts (a
caption followed by distinct lettered parts is one section), and a
span ended by the signatures meets only one of them - otherwise a
cross-reference that looks like the next heading would cut the item short
silently. Over the same corpus every end was unique, so neither check refuses
a saved item; both hold for filings not saved yet.

The candidates are the claims' items, and a claim is EDGAR's header index of
the filing (hdr.sgml), written from the filer's submission form; the document is
the filing itself. Where the document heads a candidate item its header does not
list, the claims miss a candidate, and a count confirmed over them would be one
short. Over the 794 saved 8-Ks this happens once: Pfizer's December 2023 8-K
heads a 2.01 item, the completion of an acquisition (the Seagen merger), and its
header lists 2.02 (docs/evidence/issue47_history/e01-item-text/
header-document-census.json). There is no claim to count such an item by, so
the window stops by name (``HEADED_NOT_LISTED``) rather than being answered
without it. A heading inside a link is a contents entry, not the item, and does
not count as headed. The other direction - a listed candidate the document does
not head - already stops at the item's text.

Not read: exhibits the item incorporates by reference. They are separate
documents and none of them is saved; each candidate records whether its own
text incorporates an exhibit, so a confirmation that needs one says so.
Outside the candidate set: an announcement made only under another item (a
press release furnished under 7.01). The candidate codes are the approved
definition's; widening them would be a further change of meaning.
"""
import re
from html.parser import HTMLParser

from pathlib import Path

from .canonical import content_hash, sha256_bytes, strict_json_loads
from .deterministic_router import _visible_text
from .sources import resolve_repository_file

RULE = "ITEM_TEXT_FROM_ITS_HEADING_TO_THE_NEXT_ITEM_HEADING_OR_THE_SIGNATURES"
TEXT_VIEW = "deterministic_router._visible_text"
CONFIRMATION_POLICY = "CONTENT_CONFIRMED_M_AND_A_ANNOUNCEMENT_V1"
CONFIRMATION_REASON = "HISTORICAL_E01_CONTENT_CONFIRMATION_NOT_REGISTERED"
NOT_LOCATED_REASON = "HISTORICAL_EVENT_ITEM_TEXT_NOT_LOCATED"
HEADED_NOT_LISTED = "EVENT_ITEM_HEADED_BUT_NOT_LISTED"
HEADED_NOT_LISTED_REASON = "HISTORICAL_EVENT_ITEM_HEADED_BUT_NOT_LISTED"
# A metric whose route the owner replaced, and the file that carries the
# successor. The frozen catalog keeps the approved route for the ordinary path
# and for every Run frozen under it.
SUCCESSOR_EVENT_ROUTES = {"E01": "catalog/r6/E01_content_confirmed_ma_v1.json"}
# The Spec each successor route compiles to, as the Markdown MetricSpec file a
# Run compiles its Specs from. Generated from the route by the ordinary set's
# own document writer (normal_run_specs._spec_document) and held to its bytes,
# so the file cannot say anything the route does not.
SUCCESSOR_SPEC_DOCUMENTS = {"E01": "catalog/r6/E01_content_confirmed_ma_v1.md"}

_HEADING = re.compile(
    r"(?<![A-Za-z])Items?\s*(\d{1,2}\.\d{2})(?:\([a-z]\))*\s*[.:\-\u2013\u2014]?\s*(?=[A-Z])")
# A reference is introduced by a word that points at an item, or by an opening
# quote around an item's title. A closed list of English function words, so
# nothing here names a filer; a checkbox glyph before a heading is not a word
# on this list, which is why the list is closed rather than "any lowercase".
# The words are matched in any case ("SEE Item 2.01 Completion of ...") and
# only in the visible text of the heading's own block (``_visible_before``):
# #28's review of its port (4711a488) and its controls found an uppercase "SEE"
# read as no reference, and a word ending the previous paragraph ("... see",
# "Portland, OR") or hidden text taken into the 40-character window.
_REFERENCE_BEFORE = re.compile(
    r"(?:\b(?:this|that|these|those|in|into|under|and|or|of|to|see|with|from|by|per|"
    r"pursuant|such|also)|[\u201c\u2018\"'])\s*$", re.IGNORECASE)
_REFERENCE_WINDOW = 40
_SIGNATURES = re.compile(r"\bSIGNATURES?\b")
# Form 8-K's own captions for the items a successor route reads as candidates,
# and for the items filers most often head beside them. An item whose text is
# nothing but its caption, followed at once by another item's heading, is one
# whose content the filer wrote once under the headings together - Ford heads a
# credit-agreement amendment "Item 1.01 ... Item 2.03 ..." and writes it under
# 2.03 - so it shares the body that follows. The captions are the form's, not
# any filer's, and nothing is inferred from a caption that is not on this list.
_CAPTIONS = {
    "1.01": "Entry into a Material Definitive Agreement",
    "1.02": "Termination of a Material Definitive Agreement",
    "2.01": "Completion of Acquisition or Disposition of Assets",
    "2.03": ("Creation of a Direct Financial Obligation or an Obligation under an "
             "Off-Balance Sheet Arrangement of a Registrant"),
    "7.01": "Regulation FD Disclosure",
    "8.01": "Other Events",
    "9.01": "Financial Statements and Exhibits",
}
# Endpoint recognition also includes the Form 8-K 5.02 caption. Keep it out
# of the separate caption-only combined-body routing above.
_END_CAPTIONS = {**_CAPTIONS,
    "5.02": ("Departure of Directors or Certain Officers; Election of Directors; "
             "Appointment of Certain Officers; Compensatory Arrangements of Certain Officers")}
_LETTERS = re.compile(r"[^a-z]+")
_EXHIBIT = re.compile(r"\bExhibits?\s+\d+(?:\.\d+)?", re.I)
_CONTEXT = 240


# Elements whose text is never displayed, and the inline declarations that hide
# an element or make its text invisible. A value that cannot be read as a
# number is treated as hiding for the properties that hide by their value: an
# item is refused rather than read when its visibility cannot be established.
_NONDISPLAY = frozenset(("head", "title", "script", "style", "template", "noscript", "svg",
                         "ix:hidden"))
_VOID = frozenset(("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
                   "param", "source", "track", "wbr"))
# Elements that start or end a block of text. A line break does not: "see<br>
# Item 2.01" is one sentence. An element taken out of the layout altogether
# (``_removed``) starts no block either - the text on its two sides runs on -
# but one laid out and unseen (visibility, opacity, colour, size, an offset)
# still breaks the line.
_BLOCK = frozenset(("address", "article", "aside", "blockquote", "body", "center", "dd", "div", "dl",
                    "dt", "footer", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "html", "li",
                    "main", "nav", "ol", "p", "pre", "section", "table", "tbody", "td", "tfoot", "th",
                    "thead", "tr", "ul"))
_NUMBER = re.compile(r"^([+-]?(?:\d+\.?\d*|\.\d+))(px|pt|em|rem|%|in|cm|mm|pc|ex|ch|vw|vh)?$")
_OFF_THE_PAGE = 999


def _number(value):
    match = _NUMBER.match(value)
    return None if match is None else (float(match.group(1)), match.group(2) or "")


def _removed(tag, attributes, style):
    """Whether the element is out of the layout: no box, so no line break around it."""
    return (tag in _NONDISPLAY or "hidden" in attributes
            or any(name == "display" and value.replace("!important", "") == "none"
                   for name, _, value in (declaration.partition(":")
                                          for declaration in style.split(";"))))


def _hidden_by_style(style):
    """The inline declaration that keeps an element's text from being seen, or None."""
    for declaration in style.split(";"):
        name, _, value = declaration.partition(":")
        value = value.replace("!important", "")
        if not name or not value:
            continue
        if ((name == "display" and value == "none")
                or (name == "visibility" and value in ("hidden", "collapse"))
                or (name == "content-visibility" and value == "hidden")
                or (name == "color" and (value == "transparent"
                                         or re.fullmatch(r"rgba\([^)]*,0*\.?0*\)", value)))):
            return name + ":" + value
        number = _number(value)
        if name == "opacity" and (number is None or number[0] * (0.01 if number[1] == "%" else 1)
                                  < 0.1):
            return name + ":" + value
        if name == "font-size" and number is not None and number[0] == 0:
            return name + ":" + value
        # An offset this large moves the text off the page whichever way it
        # points: left or up past the page's start, or right or down past where
        # a reader looks. #28's review of its own reader found right/bottom and
        # large positive offsets admitted (7fc74694); this reader had them too.
        if (name in ("text-indent", "left", "right", "top", "bottom", "margin-left", "margin-top")
                and number is not None and abs(number[0]) >= _OFF_THE_PAGE):
            return name + ":" + value
    return None


class _Visibility(HTMLParser):
    """The frozen view's text nodes: what hides each, whether a link holds it, and its block."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags, self.stack, self.links, self.nodes = [], [], [], []
        self.removed, self.block = [], 0

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        hidden = self.stack[-1] if self.stack else None
        linked = (self.links[-1] if self.links else False) or (tag == "a" and "href" in attributes)
        style = re.sub(r"\s+", "", attributes.get("style") or "").lower()
        removed = (self.removed[-1] if self.removed else False) or _removed(tag, attributes, style)
        if hidden is None:
            if tag in _NONDISPLAY:
                hidden = "element:" + tag
            elif "hidden" in attributes:
                hidden = "attribute:hidden"
            elif (attributes.get("aria-hidden") or "").lower() == "true":
                hidden = "attribute:aria-hidden"
            else:
                hidden = _hidden_by_style(style)
                hidden = None if hidden is None else "style:" + hidden
        if tag in _BLOCK and not removed:
            self.block += 1
        if tag not in _VOID:
            self.tags.append(tag)
            self.stack.append(hidden)
            self.links.append(linked)
            self.removed.append(removed)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in _VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for index in range(len(self.tags) - 1, -1, -1):
            if self.tags[index] == tag:
                if tag in _BLOCK and not self.removed[index]:
                    self.block += 1
                del self.tags[index:]
                del self.stack[index:]
                del self.links[index:]
                del self.removed[index:]
                return

    def handle_data(self, data):
        text = " ".join(data.split())
        if text:
            self.nodes.append((text, self.stack[-1] if self.stack else None,
                               self.links[-1] if self.links else False, self.block))


def _text_nodes(*, raw_bytes, text):
    """``(start, end, hidden, linked, block)`` for each node of the frozen view, rebuilt and checked."""
    parser = _Visibility()
    parser.feed(raw_bytes.decode("utf-8", errors="replace"))
    parser.close()
    _need(" ".join(node for node, _, _, _ in parser.nodes) == text, "EVENT_ITEM_TEXT_VIEW_NOT_REBUILT")
    spans, offset = [], 0
    for node, hidden, linked, block in parser.nodes:
        spans.append((offset, offset + len(node), hidden, linked, block))
        offset += len(node) + 1
    return spans


def _hidden_in_span(*, nodes, start, end):
    """What hides a node inside [start, end) of the frozen view, or None."""
    for node_start, node_end, hidden, _, _ in nodes:
        if hidden is not None and node_start < end and node_end > start:
            return hidden
    return None


def _linked_in_span(*, nodes, start, end):
    """Whether a node inside [start, end) of the frozen view sits inside a link."""
    return any(linked and node_start < end and node_end > start
               for node_start, node_end, _, linked, _ in nodes)


def _visible_before(*, text, nodes, position):
    """The last ``_REFERENCE_WINDOW`` visible characters before ``position``, within its block.

    Text a reader cannot see and text of another block (the previous
    paragraph, a table cell before) does not introduce a reference.
    """
    own = next((node for node in nodes if node[0] <= position < node[1]), None)
    if own is None:
        return ""
    pieces = [text[start:min(end, position)] for start, end, hidden, _, block in nodes
              if block == own[4] and hidden is None and start < position]
    return " ".join(pieces)[-_REFERENCE_WINDOW:]


class EventItemTextError(ValueError):
    """The item's own text could not be read; never a disclosure conclusion."""

    def __init__(self, reason, category="IMPLEMENTATION_GAP"):
        super().__init__(reason)
        self.category = category


def _need(condition, reason, category="IMPLEMENTATION_GAP"):
    if not condition:
        raise EventItemTextError(reason, category)


def item_headings(text, nodes):
    """(start, end, code) for every item heading, in document order.

    ``nodes`` are the view's text nodes (``_text_nodes``); a heading is a
    reference when its own block's visible text just before it is one.
    """
    found = []
    for match in _HEADING.finditer(text):
        if _REFERENCE_BEFORE.search(_visible_before(text=text, nodes=nodes, position=match.start())):
            continue
        found.append((match.start(), match.end(), match.group(1)))
    return found


def item_text(*, raw_bytes, item_code):
    """The item's own text in the frozen visible-text view of ``raw_bytes``."""
    text = _visible_text(raw_bytes=raw_bytes)
    nodes = _text_nodes(raw_bytes=raw_bytes, text=text)
    headings = item_headings(text, nodes)
    runs = []
    for heading in headings:
        if runs and runs[-1][-1][2] == heading[2]:
            runs[-1].append(heading)
        else:
            runs.append([heading])
    own = [run for run in runs if run[0][2] == item_code]
    _need(bool(own), "EVENT_ITEM_TEXT_NOT_LOCATED:" + item_code)
    _need(len(own) == 1, "EVENT_ITEM_HEADED_MORE_THAN_ONCE:" + item_code)
    start, heading_end, _ = own[0][0]
    later = [heading[0] for heading in headings if heading[0] > start and heading[2] != item_code]
    # Caption-only items share the body of the headings that follow them, as
    # far as each one in turn is caption-only too.
    shared, body_from = [], own[0][-1][1]
    following = [heading for heading in headings if heading[0] >= body_from]
    while (following and following[0][2] != item_code
           and _caption_only(text[body_from:following[0][0]], code=item_code if not shared
                             else shared[-1])):
        shared.append(following[0][2])
        body_from = following[0][1]
        following = following[1:]
        later = [heading[0] for heading in following if heading[2] != item_code]
    signatures = _SIGNATURES.search(text, heading_end if not shared else body_from)
    if later and (signatures is None or later[0] < signatures.start()):
        end, marker = later[0], "NEXT_ITEM_HEADING"
    elif signatures is not None:
        end, marker = signatures.start(), "SIGNATURES"
    else:
        end, marker = len(text), "END_OF_DOCUMENT"
    if marker == "NEXT_ITEM_HEADING":
        end_code = next(code for position, _, code in headings if position == end)
        _need(_unique_item_end(text=text, nodes=nodes, headings=headings,
                               start=start, end=end, end_code=end_code),
              "EVENT_ITEM_END_HEADING_NOT_UNIQUE:" + item_code + ":" + end_code)
    elif marker == "SIGNATURES":
        _need(len(_SIGNATURES.findall(text, start)) == 1,
              "EVENT_ITEM_END_SIGNATURES_NOT_UNIQUE:" + item_code)
    # A heading inside a link is a reference to the item - a contents entry -
    # not the item's own heading. The frozen view does not know links, so an
    # item whose only heading is a link would read the contents as its text.
    _need(not _linked_in_span(nodes=nodes, start=start, end=heading_end),
          "EVENT_ITEM_HEADING_IS_A_LINK:" + item_code)
    hidden = _hidden_in_span(nodes=nodes, start=start, end=end)
    _need(hidden is None, "EVENT_ITEM_TEXT_A_READER_CANNOT_SEE:" + item_code + ":" + str(hidden))
    body = text[start:end]
    return {"item_code": item_code, "text_view": TEXT_VIEW, "rule": RULE,
            "start": start, "end": end, "end_marker": marker,
            "heading": text[start:heading_end].strip(), "text": body,
            "text_sha256": "sha256:" + sha256_bytes(content=body.encode("utf-8")),
            "shares_the_body_of": shared}


def headed_item_codes(*, raw_bytes):
    """The item codes a document heads itself, as its reader sees them.

    A heading inside a link is a contents entry. A heading in text a reader
    cannot see - the elements, attributes and styles the item reader names - is
    not one the document shows: #28's review of its port (4711a488) found a
    display:none heading of a candidate item counted as headed, which stopped
    a window over nothing a reader could read. Neither counts as headed.
    """
    text = _visible_text(raw_bytes=raw_bytes)
    nodes = _text_nodes(raw_bytes=raw_bytes, text=text)
    return {code for start, end, code in item_headings(text, nodes)
            if not _linked_in_span(nodes=nodes, start=start, end=end)
            and _hidden_in_span(nodes=nodes, start=start, end=end) is None}


def _caption_only(gap, *, code):
    """True where ``gap`` - what follows an item's heading - is only that item's own caption."""
    caption = _CAPTIONS.get(code)
    return caption is not None and _LETTERS.sub("", gap.lower()) == _LETTERS.sub("", caption.lower())


def _unique_item_end(*, text, nodes, headings, start, end, end_code):
    """A single next heading, or its caption followed by distinct lettered parts.

    Repeated base headings can be references that would cut the item short.
    Consecutive 5.02, 5.02(b), 5.02(d) instead name one section. Admit that
    shape only with the known caption and visible, unlinked headings; keep
    repeated bases, repeated letters and separated sections ambiguous.
    """
    matching = [h for h in headings if h[0] > start and h[2] == end_code]
    if len(matching) == 1:
        return True
    if not matching or matching[0][0] != end:
        return False
    first, second = matching[:2]
    caption = _END_CAPTIONS.get(end_code)
    gap = _LETTERS.sub("", text[first[1]:second[0]].lower())
    if caption is None or gap != _LETTERS.sub("", caption.lower()):
        return False
    if (_hidden_in_span(nodes=nodes, start=first[0], end=second[0]) is not None
            or _linked_in_span(nodes=nodes, start=first[0], end=second[0])
            or _SIGNATURES.search(text, first[1], matching[-1][0])):
        return False
    between = [h for h in headings if first[0] <= h[0] <= matching[-1][0]]
    if between != matching:
        return False
    base = r"Items?\s*" + re.escape(end_code)
    if not re.fullmatch(base + r"\s*[.:\-\u2013\u2014]?\s*", text[first[0]:first[1]]):
        return False
    letters = []
    for heading in matching[1:]:
        part = re.fullmatch(base + r"\(([a-z])\)\s*[.:\-\u2013\u2014]?\s*",
                            text[heading[0]:heading[1]])
        if part is None or part.group(1) in letters:
            return False
        letters.append(part.group(1))
    return all(not _linked_in_span(nodes=nodes, start=a, end=b)
               and _hidden_in_span(nodes=nodes, start=a, end=b) is None
               for a, b, _ in matching)


def _primary_bytes(*, repo_root, records, reference_id):
    reference = records.get(reference_id)
    _need(reference is not None and reference["record_type"] == "SOURCE_REFERENCE",
          "EVENT_ITEM_PRIMARY_REFERENCE_ABSENT:" + str(reference_id), "SOURCE_INTEGRITY_ERROR")
    blob = records.get(reference["raw_asset_id"])
    _need(blob is not None and blob["record_type"] == "RAW_BLOB",
          "EVENT_ITEM_PRIMARY_BLOB_ABSENT:" + str(reference_id), "SOURCE_INTEGRITY_ERROR")
    raw = resolve_repository_file(repo_root=repo_root,
                                  repo_relative_path=blob["storage_uri"]).read_bytes()
    _need("sha256:" + sha256_bytes(content=raw) == reference["raw_asset_id"],
          "EVENT_ITEM_PRIMARY_BYTES_CHANGED:" + str(reference_id), "SOURCE_INTEGRITY_ERROR")
    return reference, raw


def successor_event_route(*, repo_root, metric_id, frozen_route):
    """The successor route for one metric, checked against the route it replaces.

    The record names its predecessor by route hash, so a successor written
    against a different approved route is refused rather than substituted. Its
    candidate codes are the codes it projects, and it has no keyword rules:
    under the content meaning a keyword never confirms an item.
    """
    record = strict_json_loads(text=(Path(repo_root) / SUCCESSOR_EVENT_ROUTES[metric_id]).read_text(
        encoding="utf-8"))
    _need(record.get("record_type") == "HISTORICAL_EVENT_ROUTE_SUCCESSOR" and record.get("metric_id") == metric_id,
          "HISTORICAL_EVENT_SUCCESSOR_ROUTE_INVALID:" + metric_id)
    _need(record["predecessor"]["route_hash"] == content_hash(value=dict(frozen_route)),
          "HISTORICAL_EVENT_SUCCESSOR_PREDECESSOR_CHANGED:" + metric_id)
    route = record["route"]
    _need(route["candidate_item_codes"] == route["direct_item_codes"] and not route["keyword_item_rules"]
          and route.get("confirmation", {}).get("policy") == CONFIRMATION_POLICY,
          "HISTORICAL_EVENT_SUCCESSOR_ROUTE_SHAPE_INVALID:" + metric_id)
    return route


def successor_public_notes(*, repo_root, metric_id):
    """What a public row under a successor route says its value means.

    The ordinary presentation policy's note for the metric describes the
    approved route's count, and that policy is bound by the issue_28
    generations, so the successor states its own meaning in its own file -
    beside the route, not inside it, so neither the route hash nor the Spec
    moves with the wording.
    """
    record = strict_json_loads(text=(Path(repo_root) / SUCCESSOR_EVENT_ROUTES[metric_id]).read_text(
        encoding="utf-8"))
    notes = record.get("public_notes")
    _need(type(notes) is str and notes.strip() == notes and bool(notes),
          "HISTORICAL_EVENT_SUCCESSOR_PUBLIC_NOTES_INVALID:" + metric_id)
    return notes


def content_confirmation_candidates(*, repo_root, route, claims, records, keep_text=False):
    """Every candidate item of a content-confirmed route, read from its own text.

    ``claims`` are the frozen adapter's item claims for the whole window and
    ``records`` the Run's source records, from which each primary document is
    read back by its reference and checked against its content hash. Nothing
    here confirms a candidate; it records where each one's own text is, so a
    confirmation can be asked of exactly that span and bound to its bytes.
    """
    _need(route["confirmation"]["policy"] == CONFIRMATION_POLICY,
          "EVENT_ROUTE_CONFIRMATION_POLICY_UNKNOWN:" + str(route["confirmation"].get("policy")))
    codes = [str(code) for code in route["candidate_item_codes"]]
    listed = {}
    for claim in claims:
        attributes = claim["attributes"]
        listed.setdefault(attributes["accession"], (set(), set()))
        listed[attributes["accession"]][0].add(attributes["primary_source_reference_id"])
        listed[attributes["accession"]][1].add(str(attributes["item_code"]))
    for accession, (references, items) in sorted(listed.items()):
        _need(len(references) == 1, "EVENT_ITEM_FILING_HAS_TWO_PRIMARY_DOCUMENTS:" + accession,
              "SOURCE_INTEGRITY_ERROR")
        reference, raw = _primary_bytes(repo_root=repo_root, records=records,
                                        reference_id=next(iter(references)))
        _need(reference["accession"] == accession, "EVENT_ITEM_PRIMARY_IS_ANOTHER_FILING",
              "SOURCE_INTEGRITY_ERROR")
        unlisted = sorted((headed_item_codes(raw_bytes=raw) & set(codes)) - items)
        _need(not unlisted, HEADED_NOT_LISTED + ":" + accession + ":" + ",".join(unlisted))
    candidates = []
    for claim in claims:
        attributes = claim["attributes"]
        code = str(attributes["item_code"])
        if code not in codes:
            continue
        reference, raw = _primary_bytes(repo_root=repo_root, records=records,
                                        reference_id=attributes["primary_source_reference_id"])
        _need(reference["accession"] == attributes["accession"],
              "EVENT_ITEM_PRIMARY_IS_ANOTHER_FILING", "SOURCE_INTEGRITY_ERROR")
        body = item_text(raw_bytes=raw, item_code=code)
        candidates.append({"verified_claim_id": claim["verified_claim_id"],
                           "accession": attributes["accession"], "item_code": code,
                           "primary_source_reference_id": reference["source_reference_id"],
                           "primary_raw_asset_id": reference["raw_asset_id"],
                           "text_view": body["text_view"], "rule": body["rule"],
                           "heading": body["heading"], "start": body["start"], "end": body["end"],
                           "end_marker": body["end_marker"], "text_sha256": body["text_sha256"],
                           "characters": len(body["text"]),
                           "incorporates_an_exhibit": bool(_EXHIBIT.search(body["text"])),
                           "shares_the_body_of": body["shares_the_body_of"],
                           "confirmation": "NOT_REGISTERED",
                           # The text itself only where a confirmation request is
                           # built from it; a binding carries its hash.
                           **({"text": body["text"]} if keep_text else {})})
    return {"policy": CONFIRMATION_POLICY, "rule": RULE, "candidate_item_codes": codes,
            "candidates": candidates,
            "status": "CONFIRMATION_NOT_REGISTERED" if candidates else "NO_CANDIDATE_ITEM",
            "not_read": "exhibits an item incorporates by reference; none is saved"}


def compact_confirmation(answer):
    """The part a Run's observation binds: which candidates were read, and where."""
    return {"policy": answer["policy"], "rule": answer["rule"], "status": answer["status"],
            "candidate_item_codes": answer["candidate_item_codes"],
            "candidates": [{key: item[key] for key in (
                "verified_claim_id", "item_code", "primary_source_reference_id", "start", "end",
                "text_sha256", "confirmation")} for item in answer["candidates"]]}
