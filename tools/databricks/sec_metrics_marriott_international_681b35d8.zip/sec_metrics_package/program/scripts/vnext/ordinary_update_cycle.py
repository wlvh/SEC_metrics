"""Persistent zero-egress update checks over the ordinary source/Run pipeline.

The current runtime admits saved and explicitly recorded sources. This module
does not fetch, enable model calls, publish or reuse closed execution budgets.
It keeps failed attempts separate from the last completely verified candidate.
"""
from contextlib import contextmanager
from datetime import datetime,timezone
import fcntl
from pathlib import Path
from uuid import uuid4

from git_workspace import first_symlink_in_path
from . import normal_run_v3 as normal
from .canonical import atomic_write_json,content_hash,sha256_file,strict_json_file
from .normal_annual_input import _registry_rows
from .ordinary_projection import render_ordinary_run
from .requirements import load_requirement_snapshot


class OrdinaryUpdateError(ValueError):
    pass


def _need(condition,reason):
    if not condition:raise OrdinaryUpdateError(reason)


def _now():return datetime.now(timezone.utc).isoformat()


def _write(path,value):normal._write(path,normal._bytes(value))


def _record(path,body):
    value={**body,'record_id':content_hash(value=body)};_write(path,value);return value


def _read(path):
    _need(first_symlink_in_path(path=path) is None,'UPDATE_STATE_PATH_ALIAS')
    value=strict_json_file(path=path)
    _need(value['record_id']==content_hash(value={k:v for k,v in value.items() if k!='record_id'}),'UPDATE_RECORD_CHANGED')
    return value


@contextmanager
def _locked(root):
    _need(first_symlink_in_path(path=root) is None,'UPDATE_STATE_PATH_ALIAS')
    root.mkdir(parents=True,exist_ok=True);path=root/'update.lock'
    _need(first_symlink_in_path(path=path) is None,'UPDATE_STATE_PATH_ALIAS')
    with path.open('a+b') as handle:
        try:fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as error:raise OrdinaryUpdateError('UPDATE_ALREADY_RUNNING') from error
        yield


def _d02_v2_policy():
    from .ordinary_d02_item8_v2 import POLICY
    return POLICY


def _config(root,source_root,company_id,metrics,native_assessment_mode='LIVE',
            a05_formula=False,d02_category=False):
    policy=normal._policy(normal.ROOT)
    _need(policy['provider_enabled'] is False and policy['sec_fetch_enabled'] is False
          and policy['freeze_enabled'] is False,'UPDATE_ZERO_EGRESS_RUNTIME_REQUIRED')
    _need(company_id in {c['company_id'] for c in _registry_rows(repo_root=normal.ROOT)},'UPDATE_COMPANY_NOT_CONFIGURED')
    _need(type(metrics) is list and metrics and len(metrics)==len(set(metrics))
          and set(metrics)<=set(normal.update_metric_ids()),'UPDATE_METRIC_SCOPE_INVALID')
    native = bool(set(metrics) & {'B13','D04'})
    _need(not native or len(metrics) == 1, 'UPDATE_NATIVE_REQUIRES_PER_METRIC_HISTORY')
    _need(type(a05_formula) is bool and (not a05_formula or metrics == ['A05']),
          'UPDATE_A05_FORMULA_SCOPE_INVALID')
    _need((type(d02_category) is bool or d02_category == 'ITEM8_V2')
          and (not d02_category or metrics == ['D02']),
          'UPDATE_D02_CATEGORY_SCOPE_INVALID')
    requirement_id = normal.REQUIREMENT_ID
    if native:
        from .continuous_call_policy import REQUIREMENT_ID as requirement_id
    requirement=load_requirement_snapshot(snapshot_dir=normal.ROOT/'requirements'/requirement_id)
    body={'record_type':'ORDINARY_UPDATE_CONFIGURATION','schema_version':1,'company_id':company_id,
        'metric_ids':sorted(metrics),'source_root':str(source_root),
        'requirement_closure_hash':requirement['requirement_closure_hash'],
        'provider_enabled':False,'sec_fetch_enabled':False,'production_authorized':False}
    if native:
        body['registered_update_options'] = normal.current_registered_update_options(metrics[0], assessment_mode=native_assessment_mode)
    if a05_formula:
        body['a05_formula_policy'] = normal.A05_FORMULA_POLICY
    if d02_category:
        if d02_category is True:
            from .ordinary_d02_item8_v1 import POLICY
        else:
            from .ordinary_d02_item8_v2 import POLICY
        body['d02_category_policy'] = POLICY
    path=root/'configuration.json'
    if path.exists():
        configured=_read(path)
        _need({k:v for k,v in configured.items() if k!='record_id'}==body,'UPDATE_CONFIGURATION_OR_RUNTIME_CHANGED')
        return configured
    return _record(path,body)


def _descriptor(cases,configuration):
    bodies={};targets={};specs={}
    for metric,case in cases.items():
        targets[metric]=case['target_period'];specs[metric]={k:v['spec_closure_hash'] for k,v in case['compiled_specs'].items()}
        for proof in case['source_proofs']:
            key=(proof['source_url'],proof['accession'],proof['document_name'])
            _need(key not in bodies or bodies[key]==proof['content_sha256'],'UPDATE_SOURCE_BODY_CONFLICT')
            bodies[key]=proof['content_sha256']
    body={'company_id':configuration['company_id'],'metric_ids':configuration['metric_ids'],
        'requirement_closure_hash':configuration['requirement_closure_hash'],'targets':targets,'specs':specs,
        'source_contents':[{'source_url':k[0],'accession':k[1],'document_name':k[2],'sha256':v} for k,v in sorted(bodies.items())]}
    if 'D01' in cases:
        body['d01_emphasis_policy'] = cases['D01']['input_binding'].get('d01_emphasis_policy')
    if 'A05' in cases and 'presentation_policy' in cases['A05']:
        body['a05_formula_policy'] = cases['A05']['presentation_policy']
    if 'D02' in cases and 'd02_category_policy' in cases['D02']['input_binding']:
        body['d02_category_policy'] = cases['D02']['input_binding']['d02_category_policy']
    native_inputs = {}
    for metric, case in cases.items():
        if metric in {'B13','D04'} and 'registered_input' in case:
            registered=case['registered_input']; binding=case['input_binding']
            native_inputs[metric] = {'source_id':binding['source_id'],
                'input_record_id':registered['input_record_id'], 'assessment_set_id':binding['assessment_set_id'],
                'mode':registered['mode'], 'request_context_format':registered.get('request_context_format'),
                'response_contract_version':registered.get('response_contract_version')}
    if native_inputs:
        body['registered_assessment_inputs'] = native_inputs
    return {**body,'content_id':content_hash(value=body)}


def _inspect(source_root,configuration,native_assessment_ledger=None):
    ledger=sha256_file(path=source_root/'evidence/requests_log.csv')
    cases={m:normal.prepare_case(data_root=source_root,company_id=configuration['company_id'],metric_id=m,
                **({'registered_update_options':configuration['registered_update_options'],'native_assessment_ledger':native_assessment_ledger} if 'registered_update_options' in configuration else {}),
                **({'c02_composition':True,'c02_grouped':True} if m == 'C02' else {}),
                **({'d01_emphasis':True} if m == 'D01' else {}),
                **({'a05_formula':True} if m == 'A05' and
                    configuration.get('a05_formula_policy') == normal.A05_FORMULA_POLICY else {}),
                **({'d02_category':('ITEM8_V2' if
                    configuration.get('d02_category_policy') == _d02_v2_policy()
                    else True)} if m == 'D02' and
                    configuration.get('d02_category_policy') is not None else {}))
           for m in configuration['metric_ids']}
    _need(sha256_file(path=source_root/'evidence/requests_log.csv')==ledger,'UPDATE_SOURCE_CHANGED_DURING_INSPECTION')
    return cases,_descriptor(cases,configuration),ledger


def _attempt(root,identity):
    _need(type(identity) is str and len(identity)==32 and all(c in '0123456789abcdef' for c in identity),'UPDATE_ATTEMPT_ID_INVALID')
    path=root/'attempts'/identity
    _need(first_symlink_in_path(path=path) is None,'UPDATE_STATE_PATH_ALIAS')
    return path


def _completed_result(*, metric, result, case, rendered, data_root):
    if result['publication'] == 'PUBLISHED':
        return True
    reasons = {'B13':'B13_DEFINED_SCOPE_NO_RELEVANT_DISCLOSURE',
               'D04':'D04_DEFINED_SCOPE_NO_DOUBT_DISCLOSURE'}
    if (metric not in reasons or result.get('reason_code') != reasons[metric]
            or result.get('value_kind') != 'TEXT_V1' or case.get('kind') != 'TEXT'):
        return False
    # This is not a reason-string exemption. The case was reconstructed by
    # native Run replay and the specialized projector repeats the complete
    # registered source assessment, candidate and original-source checks.
    from .capacity_run import project_defined_absence
    company=next(c for c in _registry_rows(repo_root=data_root) if c['company_id']==result['company_id'])
    row,evidence=project_defined_absence(case=case,result=result,row={},company=company)
    _need(rendered['row']['status']==row['status'] and rendered['row']['value']==row['value']
          and rendered['evidence']==evidence, 'UPDATE_DEFINED_ABSENCE_PROJECTION_CHANGED')
    return True


def _verify_candidate(root,terminal,configuration):
    _need(terminal['status']=='CANDIDATE_READY' and terminal['configuration_id']==configuration['record_id'],
          'UPDATE_SUCCESS_REFERENCE_INVALID')
    work=_attempt(root,terminal['attempt_id']);data=work/'data';cases={};rows={}
    _need(set(terminal['metrics'])==set(configuration['metric_ids']),'UPDATE_SUCCESS_METRIC_SET_CHANGED')
    for metric in configuration['metric_ids']:
        run=work/'runs'/metric
        rendered=render_ordinary_run(data_root=data,run_dir=run,
                                     _return_replay_context=True)
        replay=rendered['replay_context'];records=replay['records']
        cases[metric]=replay['case']
        result=next(r for r in records if r['record_type']=='METRIC_RESULT' and r['metric_id']==metric)
        _need(result['result_id']==terminal['metrics'][metric]['result_id'], 'UPDATE_SUCCESS_RESULT_CHANGED')
        _need(_completed_result(metric=metric,result=result,case=cases[metric],rendered=rendered,data_root=data),
              'UPDATE_SUCCESS_RESULT_CHANGED')
        for name,raw in rendered['files'].items():
            path=work/'rows'/metric/name
            _need(path.read_bytes()==raw and sha256_file(path=path)==terminal['metrics'][metric]['files'][name],
                  'UPDATE_SUCCESS_ROW_CHANGED')
        rows[metric]=result
    _need(_descriptor(cases,configuration)==terminal['input'],'UPDATE_SUCCESS_INPUT_CHANGED')
    return rows


def _state(root,configuration):
    path=root/'current.json'
    _need(first_symlink_in_path(path=path) is None,'UPDATE_STATE_PATH_ALIAS')
    if not path.exists():return {'configuration_id':configuration['record_id'],'latest_attempt':None,'successful_attempt':None}
    state=strict_json_file(path=path)
    _need(set(state)=={'configuration_id','latest_attempt','successful_attempt'}
          and state['configuration_id']==configuration['record_id'],'UPDATE_STATE_CONFIGURATION_CHANGED')
    for key in ['latest_attempt','successful_attempt']:
        if state[key] is not None:_attempt(root,state[key])
    if state['latest_attempt'] is None:
        _need(state['successful_attempt'] is None,'UPDATE_STATE_REFERENCE_CHAIN_CHANGED')
    else:
        work=_attempt(root,state['latest_attempt'])
        _need((work/'intent.json').is_file() and (work/'terminal.json').is_file(),'UPDATE_STATE_REFERENCE_MISSING')
        intent=_intent(root,state['latest_attempt']);terminal=_terminal(root,state['latest_attempt'])
        _need(intent['configuration_id']==terminal['configuration_id']==configuration['record_id']
              and terminal['intent_id']==intent['record_id'],'UPDATE_STATE_REFERENCE_CHAIN_CHANGED')
        expected=state['latest_attempt'] if terminal['status']=='CANDIDATE_READY' else intent['previous_successful_attempt']
        _need(state['successful_attempt']==expected,'UPDATE_STATE_REFERENCE_CHAIN_CHANGED')
    return state


def _intent(root,identity):
    value=_read(_attempt(root,identity)/'intent.json')
    _need(value.get('record_type')=='ORDINARY_UPDATE_INTENT' and value.get('attempt_id')==identity,
          'UPDATE_INTENT_IDENTITY_CHANGED')
    return value


def _terminal(root,identity):
    value=_read(_attempt(root,identity)/'terminal.json')
    _need(value.get('record_type')=='ORDINARY_UPDATE_TERMINAL' and value.get('attempt_id')==identity,
          'UPDATE_TERMINAL_IDENTITY_CHANGED')
    _need(value.get('status') in {'CANDIDATE_READY','NO_SOURCE_CONTENT_CHANGE','CANDIDATE_WITHHELD',
          'PREVIOUS_INPUT_WITHHELD','INPUT_FAILED','EXECUTION_FAILED','INTERRUPTED'},'UPDATE_TERMINAL_STATUS_INVALID')
    return value


def _recover(root,state,configuration,verify_candidate=None):
    """Reconcile the immutable journal before advancing a mutable reference."""
    verifier = _verify_candidate if verify_candidate is None else verify_candidate
    intents={}
    for work in (root/'attempts').iterdir() if (root/'attempts').exists() else []:
        _attempt(root,work.name)
        if (work/'intent.json').is_file():
            intent=_intent(root,work.name)
            _need(intent['configuration_id']==configuration['record_id'] and intent['attempt_id']==work.name,
                  'UPDATE_INTENT_CONFIGURATION_CHANGED')
            intents[work.name]=intent
    seen=set()
    successors={}
    for identity,intent in intents.items():
        parent=intent['previous_attempt']
        _need(parent is None or parent in intents and parent!=identity,'UPDATE_JOURNAL_PREDECESSOR_MISSING')
        successors.setdefault(parent,[]).append(identity)
    visited=set();cursor=None;historical_success=None
    while True:
        children=successors.get(cursor,[])
        if not children:break
        _need(len(children)==1 and children[0] not in visited,'UPDATE_JOURNAL_BRANCH_OR_CYCLE')
        cursor=children[0];visited.add(cursor)
        intent=intents[cursor]
        _need(intent['previous_successful_attempt']==historical_success,'UPDATE_INTENT_PREDECESSOR_CHANGED')
        work=_attempt(root,cursor)
        if (work/'terminal.json').exists():
            terminal=_terminal(root,cursor)
            _need(terminal['intent_id']==intent['record_id'] and terminal['configuration_id']==configuration['record_id'],
                  'UPDATE_TERMINAL_INTENT_CHANGED')
            if terminal['status']=='CANDIDATE_READY':historical_success=cursor
        else:
            _need(not successors.get(cursor),'UPDATE_HISTORICAL_TERMINAL_MISSING')
        if cursor==state['latest_attempt']:
            _need(state['successful_attempt']==historical_success,'UPDATE_STATE_REFERENCE_CHAIN_CHANGED')
    _need(visited==set(intents),'UPDATE_JOURNAL_DISCONNECTED')
    while True:
        following=successors.get(state['latest_attempt'],[])
        if not following:break
        _need(len(following)==1 and following[0] not in seen,'UPDATE_JOURNAL_BRANCH_OR_CYCLE')
        identity=following[0];seen.add(identity);intent=intents[identity];work=_attempt(root,identity)
        _need(intent['previous_successful_attempt']==state['successful_attempt'],'UPDATE_INTENT_PREDECESSOR_CHANGED')
        if not (work/'terminal.json').exists():
            _record(work/'terminal.json',{'record_type':'ORDINARY_UPDATE_TERMINAL','attempt_id':identity,
                'configuration_id':configuration['record_id'],'intent_id':intent['record_id'],
                'status':'INTERRUPTED','completed_at':_now(),'input':None,'metrics':{},
                'calls':{'provider':0,'paid':0,'sec':0},'production_authorized':False})
        terminal=_terminal(root,identity)
        _need(terminal['intent_id']==intent['record_id'] and terminal['configuration_id']==configuration['record_id'],
              'UPDATE_TERMINAL_INTENT_CHANGED')
        if terminal['status']=='CANDIDATE_READY':
            verifier(root,terminal,configuration);state['successful_attempt']=identity
        state['latest_attempt']=identity
    atomic_write_json(path=root/'current.json',value=state)
    return state


def run_once(*,state_root,source_root,company_id,metric_ids,native_assessment_mode='LIVE',native_assessment_ledger=None,
             source_identity_root=None,a05_formula=False,d02_category=False,current_records=False):
    """Check one company's current input and keep a durable candidate history."""
    _need(type(current_records) is bool, 'UPDATE_RECORD_FORMAT_INVALID')
    if current_records:
        _need(len(metric_ids)==1 and source_identity_root is None
              and native_assessment_ledger is None and not a05_formula and not d02_category,
              'UPDATE_CURRENT_RECORD_SCOPE_UNSUPPORTED')
        from .ordinary_current_update import run_once as run_current
        return run_current(state_root=state_root,source_root=source_root,
                           company_id=company_id,metric_id=metric_ids[0])
    _need(type(d02_category) is bool or d02_category == 'ITEM8_V2',
          'UPDATE_D02_CATEGORY_SCOPE_INVALID')
    _need(d02_category is not True, 'UPDATE_D02_CATEGORY_RULE_VALIDATION_SUSPENDED')
    _need(d02_category != 'ITEM8_V2', 'UPDATE_D02_V2_CATEGORY_RULE_VALIDATION_SUSPENDED')
    root=normal._external(Path(state_root));source=(normal._external(Path(source_root))
        if source_identity_root is not None else Path(source_root).resolve())
    identity_source=(source if source_identity_root is None else
                     normal._external(Path(source_identity_root)))
    _need(root!=source and root not in source.parents and source not in root.parents,'UPDATE_SOURCE_STATE_ROOTS_OVERLAP')
    if source_identity_root is not None:
        from .ordinary_processing_source import verify_processing_source
        from .continuous_call_policy import REQUIREMENT_ID
        processing_requirement=load_requirement_snapshot(
            snapshot_dir=normal.ROOT/'requirements'/REQUIREMENT_ID)
        verify_processing_source(acquisition_root=identity_source,
            processing_root=source,requirement=processing_requirement)
    with _locked(root):
        configuration=_config(root,identity_source,company_id,metric_ids,
                              native_assessment_mode,a05_formula,d02_category)
        state=_recover(root,_state(root,configuration),configuration)
        previous=None;successful_results={}
        if state['successful_attempt'] is not None:
            previous=_terminal(root,state['successful_attempt']);successful_results=_verify_candidate(root,previous,configuration)
        identity=uuid4().hex;work=_attempt(root,identity)
        intent=_record(work/'intent.json',{'record_type':'ORDINARY_UPDATE_INTENT','attempt_id':identity,
            'configuration_id':configuration['record_id'],'started_at':_now(),'previous_attempt':state['latest_attempt'],
            'previous_successful_attempt':state['successful_attempt']})
        descriptor=None;metrics={};status='INPUT_FAILED';error=None
        try:
            _,descriptor,ledger=_inspect(source,configuration,native_assessment_ledger)
            if previous:
                _need(all(descriptor['targets'][m]['period_end']>=previous['input']['targets'][m]['period_end']
                          for m in configuration['metric_ids']),'UPDATE_SOURCE_PERIOD_REGRESSED')
            if previous and descriptor==previous['input']:
                status='NO_SOURCE_CONTENT_CHANGE'
            elif state['latest_attempt'] and (prior:=_terminal(root,state['latest_attempt']))['status'] in {'CANDIDATE_WITHHELD','PREVIOUS_INPUT_WITHHELD'} and prior['input']==descriptor:
                status='PREVIOUS_INPUT_WITHHELD'
            else:
                for metric in configuration['metric_ids']:
                    normal.install_normal_inputs(data_root=work/'data',source_root=None if source==normal.ROOT else source,
                        company_id=company_id,metric_id=metric,
                        **({'registered_update_options':configuration['registered_update_options'],'native_assessment_ledger':native_assessment_ledger} if 'registered_update_options' in configuration else {}),
                        **({'c02_composition':True,'c02_grouped':True} if metric == 'C02' else {}),
                        **({'d01_emphasis':True} if metric == 'D01' else {}),
                        **({'a05_formula':True} if a05_formula else {}),
                        **({'d02_category':d02_category} if d02_category else {}))
                    created=normal.create_normal_run(data_root=work/'data',run_dir=work/'runs'/metric,
                        company_id=company_id,metric_id=metric,
                        **({'c02_composition':True,'c02_grouped':True} if metric == 'C02' else {}),
                        **({'d01_emphasis':True} if metric == 'D01' else {}),
                        **({'a05_formula':True} if a05_formula else {}),
                        **({'d02_category':d02_category} if d02_category else {}))
                    rendered=render_ordinary_run(data_root=work/'data',run_dir=work/'runs'/metric)
                    hashes={}
                    for name,raw in rendered['files'].items():
                        path=work/'rows'/metric/name;normal._write(path,raw);hashes[name]=sha256_file(path=path)
                    metrics[metric]={'result_id':created['result']['result_id'],'publication':created['result']['publication'],
                                     'source_credit':created['input_binding']['source_admission']['source_credit'],'files':hashes}
                    if metric in {'B13','D04'}:
                        current_case=normal.replay_case(data_root=work/'data',manifest=created['manifest'])
                        metrics[metric]['native_assessment_completed'] = _completed_result(metric=metric,
                            result=created['result'],case=current_case,rendered=rendered,data_root=work/'data')
                _need(sha256_file(path=source/'evidence/requests_log.csv')==ledger,'UPDATE_SOURCE_CHANGED_DURING_EXECUTION')
                status='CANDIDATE_READY' if all(v['publication']=='PUBLISHED' or v.get('native_assessment_completed') is True for v in metrics.values()) else 'CANDIDATE_WITHHELD'
                if status=='CANDIDATE_READY':
                    successful_results=_verify_candidate(root,{'status':status,'configuration_id':configuration['record_id'],
                        'attempt_id':identity,'input':descriptor,'metrics':metrics},configuration)
            if source_identity_root is not None:
                verify_processing_source(acquisition_root=identity_source,
                    processing_root=source,requirement=processing_requirement)
        except Exception as failure:
            error={'error_type':type(failure).__name__,'reason':str(failure)}
            status='EXECUTION_FAILED' if descriptor is not None else 'INPUT_FAILED'
        terminal=_record(work/'terminal.json',{'record_type':'ORDINARY_UPDATE_TERMINAL','attempt_id':identity,
            'configuration_id':configuration['record_id'],'intent_id':intent['record_id'],'status':status,
            'completed_at':_now(),'input':descriptor,'metrics':metrics,'error':error,
            'calls':{'provider':0,'paid':0,'sec':0},'production_authorized':False})
        if status=='CANDIDATE_READY':
            state['successful_attempt']=identity;previous=terminal
        state['latest_attempt']=identity;atomic_write_json(path=root/'current.json',value=state)
        return {'status':status,'attempt_id':identity,'latest_attempt':identity,
            'successful_attempt':state['successful_attempt'],'previous_successful_attempt':intent['previous_successful_attempt'],
            'last_verified_candidate':None if previous is None else {
                'attempt_id':previous['attempt_id'],'targets':previous['input']['targets'],
                'current_input_matches':descriptor==previous['input'],'results':successful_results,
                'rows_root':str(_attempt(root,previous['attempt_id'])/'rows')},
            'new_candidate_created':bool(metrics),'terminal':terminal,'calls':{'provider':0,'paid':0,'sec':0},'production_authorized':False}


def run_company(*,state_root,source_root,company_id,metric_ids,native_assessment_mode='LIVE',native_assessment_ledger=None,
                source_identity_root=None):
    """Keep each metric's candidate independent of other metric failures."""
    root=normal._external(Path(state_root));policy=normal._policy(normal.ROOT)
    _need(type(metric_ids) is list and metric_ids and len(metric_ids)==len(set(metric_ids))
          and set(metric_ids)<=set(normal.update_metric_ids()),'UPDATE_METRIC_SCOPE_INVALID')
    # Earlier group histories remain intact and must use their pinned runtime.
    # Never silently start unrelated histories beside an existing group pointer.
    _need(not (root/'configuration.json').exists() and not (root/'current.json').exists(),
          'UPDATE_GROUP_HISTORY_REQUIRES_PINNED_RUNTIME')
    outcomes=[]
    for metric in sorted(metric_ids):
        try:
            outcome=run_once(state_root=root/'metrics'/metric,source_root=source_root,
                             company_id=company_id,metric_ids=[metric],native_assessment_mode=native_assessment_mode,
                             native_assessment_ledger=native_assessment_ledger,source_identity_root=source_identity_root)
        except Exception as error:
            outcome={'status':'UPDATE_BLOCKED','error_type':type(error).__name__,'reason':str(error),
                     'last_verified_candidate':None,'calls':{'provider':0,'paid':0,'sec':0},'production_authorized':False}
        outcomes.append({'metric_id':metric,**outcome})
    ready=sum(o['status'] in {'CANDIDATE_READY','NO_SOURCE_CONTENT_CHANGE'} for o in outcomes)
    return {'company_id':company_id,'status':'UPDATES_READY' if ready==len(outcomes) else
            'UPDATES_PARTIAL' if ready else 'UPDATES_INCOMPLETE','metrics':outcomes,
            'calls':{'provider':0,'paid':0,'sec':0},'production_authorized':False}
