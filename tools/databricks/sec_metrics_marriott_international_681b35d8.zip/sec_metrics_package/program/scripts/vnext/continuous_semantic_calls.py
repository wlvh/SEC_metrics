"""Bound semantic requests through the existing provider opener/WB-3.

Saved source authenticity is replayed, never relabelled as new acquisition.
Feasibility responses have no native credit. An explicit D03 recorded-only
entry can create one source-bound Candidate/Evidence, never a company Result.
"""
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
import json
import io
import tarfile
import uuid

from .canonical import canonical_json_bytes, content_hash, sha256_bytes, strict_json_loads, strict_json_file, sha256_file
from .continuous_call_policy import REQUIREMENT_ID, configured_transport_policy, load_delegation, need
from .normal_source_authority import ROOT, verify_saved_source_proofs
from .provider_runtime import load_provider_runtime_authority
from .requirements import load_requirement_snapshot
from . import invocation_control as control
from .request_limits import DEFAULT_LIMITS, configured_limits

_FACTORY = object()
_FEASIBILITY = 'FEASIBILITY_ONLY_NO_NATIVE_EVIDENCE'
REVIEW_POLICY_PATH = 'catalog/r6/semantic_review_v3.json'
SEMANTIC_RULE_PATHS = (
    'scripts/vnext/r6_semantic_source.py','scripts/vnext/r6_semantic_review.py',
    'scripts/vnext/going_concern_source.py','scripts/vnext/regulatory_investigation_candidates.py',
    'scripts/vnext/r6_regulatory_semantics.py','catalog/r6/semantic_source_v1.json',
    'catalog/r6/semantic_review_v1.json','catalog/r6/semantic_review_v2.json',REVIEW_POLICY_PATH,
    'scripts/vnext/r6_semantic_scope.py',
    'catalog/r6/going_concern_source_rules_v1.json',
    'catalog/r6/regulatory_investigation_candidates_v1.json',
    'catalog/r6/regulatory_semantic_review_v1.json','catalog/r6/regulatory_semantic_review_v2.json',
    'catalog/r6/regulatory_semantic_review_v3.json','catalog/r6/regulatory_semantic_review_v4.json',
    'catalog/r6/regulatory_semantic_review_v5.json',
    'catalog/r6/regulatory_semantic_review_v6.json',
    'scripts/vnext/r6_semantic_verification.py',
    'catalog/r6/regulatory_semantic_verification_v1.json','catalog/r6/regulatory_semantic_verification_v2.json',
    'scripts/vnext/r6_historical_controls.py','config/r6_historical_control_sources_v1.json',
    'scripts/vnext/regulatory_statement_facts.py',
    'scripts/vnext/regulatory_fact_review.py',
    'scripts/vnext/d03_native_assessment.py',
    'catalog/r6/D03_regulatory_investigations_assessment_v1.md',
    'scripts/vnext/capacity_semantic_source.py', 'scripts/vnext/capacity_semantic_review.py',
    'scripts/vnext/capacity_two_stage.py',
    'catalog/r5/capacity_semantic_review_v1.json', 'catalog/r5/capacity_semantic_review_v2.json',
    'catalog/r5/capacity_semantic_review_v3.json',
    'catalog/r5/capacity_semantic_review_v4.json',
    'catalog/r5/capacity_semantic_review_v5.json',
    'scripts/vnext/d04_native_assessment.py', 'catalog/r6/semantic_review_v4.json',
    'catalog/r6/semantic_review_v5.json',
    'catalog/r6/D04_going_concern_assessment_v1.md',
    'scripts/vnext/capacity_native_assessment.py',
    'scripts/vnext/capacity_quantity_scope.py',
    'scripts/vnext/capacity_program_roles.py','catalog/r5/capacity_semantic_review_v6.json',
    'scripts/vnext/capacity_quantity_roles.py',
    'scripts/vnext/capacity_update_input.py',
    'scripts/vnext/native_request_construction.py',
    'scripts/vnext/native_unit_index.py',
    'scripts/vnext/capacity_reference_contract.py',
    'scripts/vnext/continuous_request_context.py',
    'config/tokenizers/deepseek_v41/tokenizer.json.gz',
    'requirements-continuous-context.txt')


def validate_semantic_rule_bindings(requirement):
    """Imported source/interpretation modules belong to the call's version."""
    for relative in SEMANTIC_RULE_PATHS:
        raw=(ROOT/relative).read_bytes()
        need(requirement['execution_authority']['files'].get(relative)==
             {'sha256':sha256_bytes(content=raw),'size':len(raw)},
             'CONTINUOUS_SEMANTIC_RULE_NOT_BOUND:'+relative)


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')


def _json(value):
    return canonical_json_bytes(value=value)


def _source_json(value):
    """Keep native source/request strings exact; legacy semantic JSON is unchanged."""
    if value.get('metric_id') in {'B13', 'D03', 'D04'}:
        from .native_unit_index import evidence_json_bytes
        return evidence_json_bytes(value)
    return _json(value)


def validate_source_unit_bytes(source):
    """Reject a lossy source packet before any request can claim a paid slot."""
    if source.get('metric_id') not in {'B13', 'D03', 'D04'}:
        return
    from .r6_semantic_source import _bytes
    for unit in source['units']:
        raw = _bytes(unit['payload'])
        need(unit['payload_sha256'] == sha256_bytes(content=raw)
             and unit['payload_bytes'] == len(raw)
             and unit['unit_id'] == content_hash(value={k:v for k,v in unit.items() if k != 'unit_id'}),
             'CONTINUOUS_SOURCE_UNIT_SERIALIZATION_CHANGED')


def request_body(request, policy, *, limits=None):
    limits = configured_limits(limits)
    payload = {k:v for k,v in request.items() if k not in
        {'system_prompt','provider_request_sent','provider_tokens_measured','production_authorized'}}
    from .native_unit_index import evidence_json_bytes
    encode = evidence_json_bytes if request.get('metric_id') in {'B13', 'D03', 'D04'} else _json
    return encode({'model':policy.model,'messages':[
        {'role':'system','content':request['system_prompt']},
        {'role':'user','content':json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))}],
        'response_format':{'type':'json_object'},'temperature':0,'max_tokens':limits.output_tokens,
        'stream':False,'thinking':{'type':'disabled'}})


def request_digest(request, policy, *, limits=None):
    """New code/provenance IDs alone do not authorize another extraction."""
    body = {'model':policy.model,'system_prompt':request['system_prompt'],
        'target_cik':request['target_cik'],'target_period':request['target_period'],
        'fiscal_label_context':request['fiscal_label_context'],
        'filing':request['document_context']['filing'],
        'units':[{'kind':u['kind'],'payload':u['payload']} for u in request['units']],
        'response_protocol':request['response_protocol'],
        'category_definitions':request['category_definitions'],
        'required_candidate_assessments':request['required_candidate_assessments'],
        # Semantic input IDs do not grant a redraw. Actual decoding settings
        # belong to the request, including the repaired thinking-mode setting.
        'provider_parameters':{k:v for k,v in strict_json_loads(
            text=request_body(request,policy,limits=limits).decode()).items() if k not in {'messages'}}}
    if request['record_type']=='D03_SEMANTIC_VERIFICATION_REQUEST':
        body['verification']={'proposals':request['proposals'],
            'prior_assistant_output_sha256':request['prior_assistant_output_sha256']}
    if request.get('source_statement_facts'):
        body['source_statement_facts'] = request['source_statement_facts']
    if 'source_fact_candidates' in request:
        body['source_fact_candidates'] = request['source_fact_candidates']
        body['source_fact_review_contract'] = request['source_fact_review_contract']
    if 'shared_source_dictionaries' in request:
        body['shared_source_dictionaries'] = request['shared_source_dictionaries']
    if request.get('metric_id') == 'B13':
        body['native_capacity_role_assessments'] = request['native_capacity_role_assessments']
    for field in ('program_quantity_role_contract_version','program_quantity_contract',
                  'quantity_scope_context', 'quantity_scope_instructions', 'response_contract_version',
                  'required_response_unit_ids', 'unit_response_requirements',
                  'unit_index_requirements', 'scan_contract', 'two_stage_contract',
                  'two_stage_scan'):
        if field in request:
            body[field] = request[field]
    if 'indexed_unit_contract' in request:
        # A source/request identity alone never permits a redraw. The complete
        # original ID remains bound in HTTP bytes, request, plan and receipt;
        # this digest compares semantic inputs and the response contract only.
        body['indexed_unit_contract'] = {k:v for k,v in request['indexed_unit_contract'].items()
                                         if k != 'base_request_id'}
    if 'source_reference_contract' in request:
        body['source_reference_contract'] = {k:v for k,v in request['source_reference_contract'].items()
                                              if k != 'base_request_id'}
    return sha256_bytes(content=_json(body))


def source_requests(source):
    from .native_request_construction import reuse_source_requests
    return reuse_source_requests(source,_construct_source_requests)


def _construct_source_requests(source):
    """Keep every existing source unit, with one unit per smaller request."""
    if source['record_type']=='D03_PROVIDER_PROPOSAL_VERIFICATION_SOURCE':
        from .r6_semantic_verification import requests_from_source
        return requests_from_source(source)
    if source['record_type'] in {'D04_NATIVE_COMPLETE_SEMANTIC_SOURCE', 'D04_NATIVE_HISTORICAL_CONTROL_SOURCE'}:
        from .d04_native_assessment import requests_from_source
        return requests_from_source(source)
    if source['metric_id'] == 'B13':
        from .capacity_semantic_review import requests_from_source
        return requests_from_source(source)
    if source['metric_id']=='D03':
        from .r6_regulatory_semantics import requests_from_source
        return requests_from_source(source)
    need(source['metric_id']=='D04','CONTINUOUS_SEMANTIC_METRIC_REQUIRED')
    from .r6_semantic_review import requests_from_source
    from .r6_semantic_review import POLICY as reference_policy, _source_items
    review_policy = strict_json_file(path=ROOT/REVIEW_POLICY_PATH)
    # Reuse the original exact-reference validator with unchanged categories
    # and bounds. Only the model's instructions and explicit per-unit todo grow.
    for key in ('kinds','subjects','timings','current_target_kinds','max_response_bytes',
                'max_findings_per_unit','max_reason_characters','max_quote_characters'):
        need(review_policy[key] == reference_policy[key], 'CONTINUOUS_RESPONSE_PROTOCOL_CHANGED')
    original = requests_from_source(source); requests = []
    for group in original:
        for unit in group['units']:
            body = {k:v for k,v in group.items() if k != 'request_id'}
            body['units'] = [unit]
            body['system_prompt'] = review_policy['system_prompt']
            body['policy_sha256'] = sha256_file(path=ROOT/REVIEW_POLICY_PATH)
            body['category_definitions'] = review_policy['category_definitions']
            kind,items = _source_items(unit)
            context = body['document_context']
            required = (context['language_candidate_block_indices'] if kind=='VISIBLE_BLOCK' else
                        context['native_candidate_ordinals'] if kind=='NATIVE_FACT' else [])
            body['required_candidate_assessments'] = [
                {'unit_id':unit['unit_id'],'kind':kind,'source_index':index}
                for index in required if index in items]
            if source['record_type']=='D04_HISTORICAL_PRIMARY_CONTROL_SOURCE':
                body['historical_control']=source['control']
                body['control_source_scope']=source['control_scope']
                body['system_prompt'] += (' This is a real historical filing control. Interpret CURRENT_REPORT relative '
                    'to this supplied original report, not the present day. Its scope is the complete selected primary HTML, '
                    'with SEC header identity; companion XBRL is not supplied. Do not infer whole-filing absence, current '
                    'company status, or production acceptance from this control.')
            requests.append({**body,'request_id':content_hash(value=body)})
    need([u['unit_id'] for r in requests for u in r['units']] == source['required_unit_ids'],
         'CONTINUOUS_SOURCE_UNIT_COVERAGE_CHANGED')
    return requests


@dataclass(frozen=True)
class SemanticRequest:
    _factory: object
    source_bytes: bytes
    request_bytes: bytes
    provider_request_body_bytes: bytes
    output_schema_bytes: bytes
    requirement: object
    authority: object
    data_root: Path = ROOT
    source_ledger: object = None
    replay_only: bool = False
    current_source_bytes: bytes = None
    current_source_ledger_sha256: str = None
    limits: object = DEFAULT_LIMITS
    d04_saved_response_only: bool = False

    def validate(self, policy):
        need(self._factory is _FACTORY, 'CONTINUOUS_SOURCE_FACTORY_REQUIRED')
        self.authority._check()
        source = strict_json_loads(text=self.source_bytes.decode())
        request = strict_json_loads(text=self.request_bytes.decode())
        need(source['semantic_source_id'] == content_hash(value={k:v for k,v in source.items() if k!='semantic_source_id'}),
             'CONTINUOUS_SOURCE_CHANGED')
        validate_source_unit_bytes(source)
        allowed_control_root=Path(self.requirement['policy']['budget_root'])/'source-inputs'
        from .continuous_call_ledger import CallLedger, _FACTORY as ledger_factory
        registered_source = (type(self.source_ledger) is CallLedger and self.source_ledger._factory is ledger_factory)
        allowed_registered = registered_source and (self.data_root == allowed_control_root or
            self.d04_saved_response_only and self.replay_only and source['metric_id']=='D04'
            if self.source_ledger.live else
            self.data_root != allowed_control_root and self.data_root != ROOT and ROOT not in self.data_root.parents)
        need((self.data_root in {ROOT,allowed_control_root} or allowed_registered)
             and not any(p.is_symlink() for p in [self.data_root,*self.data_root.parents]),
             'CONTINUOUS_SOURCE_ROOT_NOT_ALLOWED')
        current_runtime = self.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1'
        if current_runtime:
            from .saved_source_checks import verify_saved_inputs
            verify_saved_inputs(data_root=self.data_root, proofs=source['source_proofs'])
        elif self.data_root==ROOT:
            verify_saved_source_proofs(data_root=ROOT,proofs=source['source_proofs'])
        else:
            from .ordinary_source_authority import verify_ordinary_source_proofs
            historical = source['record_type'] in {'D04_HISTORICAL_PRIMARY_CONTROL_SOURCE', 'D04_NATIVE_HISTORICAL_CONTROL_SOURCE'}
            ordinary = (registered_source and allowed_registered and (
                source['record_type'] in {'B13_COMPLETE_SEMANTIC_SOURCE',
                    'D04_NATIVE_COMPLETE_SEMANTIC_SOURCE'} or
                source['record_type'] == 'D03_COMPLETE_SEMANTIC_SOURCE'
                and self.replay_only and source.get('external_replay_only') is True
                and request.get('external_replay_only') is True))
            need(historical and source['normal_update_input'] is False or ordinary,
                 'CONTINUOUS_CONTROL_SOURCE_SCOPE_REQUIRED')
            admission=verify_ordinary_source_proofs(data_root=self.data_root,proofs=source['source_proofs'])
            if ordinary and self.source_ledger.live:
                need(admission['source_credit']!='RECORDED_TEST_ONLY','CONTINUOUS_RECORDED_SOURCE_CANNOT_RUN_LIVE')
        if self.current_source_bytes is not None:
            from .ordinary_source_authority import verify_ordinary_source_proofs
            from .capacity_update_input import source_equivalence
            current=strict_json_loads(text=self.current_source_bytes.decode())
            need(self.replay_only and sha256_file(path=self.data_root/'evidence/requests_log.csv')==self.current_source_ledger_sha256,
                 'CONTINUOUS_REPLAY_CURRENT_SOURCE_CHANGED')
            verify_ordinary_source_proofs(data_root=self.data_root,proofs=current['source_proofs'])
            source_equivalence(current=current,original=source)
        original_requests = source_requests(source)
        if request not in original_requests:
            if 'source_fact_review_contract' in request:
                from .regulatory_fact_review import candidate_request
                contract = request['source_fact_review_contract']
                need(type(contract) is dict and
                     type(contract.get('original_request_id')) is str,
                     'D03_SOURCE_ANCHOR_REQUEST_NOT_IN_CURRENT_SOURCE')
                originals = [original for original in original_requests
                    if original['request_id'] == contract['original_request_id']
                    and original.get('source_statement_facts')]
                need(source['metric_id'] == 'D03' and len(originals) == 1
                     and candidate_request(originals[0], source=source,repo_root=self.data_root) == request,
                     'D03_SOURCE_ANCHOR_REQUEST_NOT_IN_CURRENT_SOURCE')
            elif request.get('record_type') == 'B13_REFERENCE_SCAN_REQUEST':
                from .capacity_reference_contract import upgrade_request as reference_request
                from .capacity_two_stage import (SCAN_COVERAGE_VERSION,
                    SCAN_VERSION, coverage_scan_request, scan_request)
                version = request.get('scan_contract', {}).get('version')
                need(version in {SCAN_VERSION, SCAN_COVERAGE_VERSION},
                     'CONTINUOUS_SCAN_REQUEST_VERSION_UNSUPPORTED')
                build_scan = (coverage_scan_request if version == SCAN_COVERAGE_VERSION
                              else scan_request)
                need(source['metric_id'] == 'B13' and
                     any(build_scan(reference_request(original, compact=True,
                         role_labels=True, relevance_scope=True)) == request
                         for original in original_requests),
                     'CONTINUOUS_SCAN_REQUEST_NOT_IN_SOURCE')
            elif 'source_reference_contract' in request:
                from .capacity_reference_contract import restore_base_request
                need(restore_base_request(request) in original_requests, 'CONTINUOUS_REQUEST_NOT_IN_SOURCE')
            else:
                from .native_unit_index import restore_base_request
                need('indexed_unit_contract' in request and restore_base_request(request) in original_requests,
                     'CONTINUOUS_REQUEST_NOT_IN_SOURCE')
        if current_runtime:
            from .current_request_configuration import transport_policy
            selected = transport_policy(configuration=self.requirement,repo_root=ROOT,limits=self.limits)
        else:
            selected = configured_transport_policy(requirement=self.requirement,repo_root=ROOT)
        need(selected == policy
             and request_body(request,policy,limits=self.limits) == self.provider_request_body_bytes
             and _json(request['response_protocol']) == self.output_schema_bytes,
             'CONTINUOUS_PROVIDER_PAYLOAD_CHANGED')
        return request


def prepare_requests(*, company_id, metric_id='D04', prior_call_ordinal=None,control_id=None, native=False,
                     reference_context=False, complete_response_contract=False, source_root=None, source_ledger=None, program_quantity_roles=False,
                     d03_replay_only_external=False, limits=None, d04_saved_response_only=False):
    from .r6_semantic_source import prepare_d04_semantic_source
    from .current_request_configuration import load_current_configuration, transport_policy
    limits = configured_limits(limits)
    requirement = load_current_configuration(repo_root=ROOT)
    policy = transport_policy(configuration=requirement,repo_root=ROOT,limits=limits)
    authority = control.prepare_current_invocation_context(repo_root=ROOT,
        configuration=requirement,transport=policy,limits=limits)
    need(metric_id in {'B13','D03','D04'},'CONTINUOUS_SEMANTIC_METRIC_REQUIRED')
    need(type(d04_saved_response_only) is bool and (not d04_saved_response_only
         or metric_id=='D04' and native and source_root is not None
         and control_id is None and prior_call_ordinal is None),
         'D04_SAVED_RESPONSE_ONLY_SCOPE_REQUIRED')
    need(type(d03_replay_only_external) is bool and
         (not d03_replay_only_external or (metric_id == 'D03' and source_root is not None
          and reference_context and not native and prior_call_ordinal is None)),
         'D03_EXTERNAL_REPLAY_ONLY_SCOPE_REQUIRED')
    need(not native or (metric_id == 'D04' and prior_call_ordinal is None),
         'D04_NATIVE_REQUIRES_CURRENT_COMPLETE_SOURCE')
    need(type(complete_response_contract) is bool and (not complete_response_contract or native),
         'D04_COMPLETE_RESPONSE_REQUIRES_NATIVE_REQUEST')
    need(not reference_context or (prior_call_ordinal is None and (native or metric_id in {'B13', 'D03'})),
         'CONTINUOUS_REFERENCE_GROUPING_UNSUPPORTED')
    from .continuous_request_context import FORMAT_VERSION
    context_format = FORMAT_VERSION if reference_context else None
    data_root=ROOT
    if source_root is not None:
        from .continuous_call_ledger import CallLedger, _FACTORY as ledger_factory
        data_root=Path(source_root).resolve()
        need(control_id is None and prior_call_ordinal is None
             and (metric_id == 'B13' or metric_id == 'D04' and native
                  or metric_id == 'D03' and d03_replay_only_external),
             'CONTINUOUS_ORDINARY_SOURCE_ROUTE_REQUIRED')
        need(type(source_ledger) is CallLedger and source_ledger._factory is ledger_factory,
             'CONTINUOUS_ORDINARY_SOURCE_LEDGER_REQUIRED')
        fixed=Path(requirement['policy']['budget_root'])/'source-inputs'
        need((data_root in {ROOT,fixed} or d04_saved_response_only if source_ledger.live else data_root!=fixed)
             and (not source_ledger.live or source_ledger.root==fixed.parent)
             and not any(p.is_symlink() for p in [Path(source_root),*Path(source_root).parents]),
             'CONTINUOUS_ORDINARY_SOURCE_ROOT_FORBIDDEN')
    if control_id is not None:
        need(metric_id=='D04' and prior_call_ordinal is None,'CONTINUOUS_HISTORICAL_CONTROL_REQUIRES_D04')
        from .r6_historical_controls import prepare_control_source
        data_root=Path(requirement['policy']['budget_root'])/'source-inputs'
        source=prepare_control_source(repo_root=data_root,company_id=company_id,control_id=control_id)
        if native:
            from .d04_native_assessment import native_source
            source = native_source(source, historical_control=True, request_context_format=context_format,
                                   complete_response_contract=complete_response_contract)
    elif prior_call_ordinal is not None:
        need(metric_id=='D03','CONTINUOUS_VERIFICATION_REQUIRES_D03')
        from .r6_semantic_verification import prepare_verification_source
        source=prepare_verification_source(company_id=company_id,prior_call_ordinal=prior_call_ordinal)
    elif metric_id=='D03':
        from .r6_regulatory_semantics import prepare_regulatory_semantic_source
        source = prepare_regulatory_semantic_source(repo_root=data_root,company_id=company_id,
            request_context_format=context_format,ordinary_registered=True)
    elif metric_id == 'B13':
        from .capacity_semantic_source import prepare_capacity_semantic_source
        source = prepare_capacity_semantic_source(repo_root=data_root,company_id=company_id,request_context_format=context_format,ordinary_registered=True)
    else:
        source = prepare_d04_semantic_source(repo_root=data_root,company_id=company_id,ordinary_registered=True)
        if native:
            from .d04_native_assessment import native_source
            source = native_source(source, request_context_format=context_format,
                                   complete_response_contract=complete_response_contract)
    need(type(program_quantity_roles) is bool and (not program_quantity_roles or metric_id=='B13'),
         'B13_PROGRAM_CONTRACT_SELECTION_INVALID')
    if program_quantity_roles:
        from .capacity_program_roles import program_source,quantity_contract
        source=program_source(source)
        program=quantity_contract(units=source['units'],period=source['prepared_annual_input']['table_input']['target_period'],
            scope=source.get('quantity_scope_context'))
        need(not program['implementation_unresolved'],
             'B13_PROGRAM_SOURCE_IMPLEMENTATION_UNRESOLVED:'+repr(program['implementation_unresolved']))
    from .saved_source_checks import verify_saved_inputs
    verify_saved_inputs(data_root=data_root,proofs=source['source_proofs'])
    raw = _source_json(source)
    return [SemanticRequest(_FACTORY,raw,_source_json(request),request_body(request,policy,limits=limits),
        _json(request['response_protocol']),requirement,authority,data_root,source_ledger,
        replay_only=d03_replay_only_external or d04_saved_response_only, limits=limits,
        d04_saved_response_only=d04_saved_response_only) for request in source_requests(source)]


def prepare_d03_replay_only_requests(*, company_id, source_root=None, source_ledger=None):
    """Carry the current complete D03 successor set into the real factory.

    These objects can be identity-checked and planned, but replay_only keeps
    both recorded and live execution closed. No old source fact is treated as
    a compelled answer, and no response or native Result is created here.
    """
    from .native_request_construction import request_construction_session
    need((source_root is None) == (source_ledger is None),
         'D03_REPLAY_ONLY_EXTERNAL_SOURCE_AND_LEDGER_REQUIRED')
    if source_root is not None:
        from .continuous_call_ledger import CallLedger, _FACTORY as ledger_factory
        need(type(source_ledger) is CallLedger and source_ledger._factory is ledger_factory
             and Path(source_root).resolve() == source_ledger.root/'source-inputs',
             'D03_REPLAY_ONLY_EXTERNAL_SOURCE_NOT_LEDGER_OWNED')
    originals = prepare_requests(company_id=company_id, metric_id='D03',
        reference_context=True, source_root=source_root, source_ledger=source_ledger,
        d03_replay_only_external=source_root is not None)
    need(bool(originals) and all(p.source_bytes == originals[0].source_bytes
        for p in originals), 'D03_REPLAY_ONLY_COMPLETE_SOURCE_REQUIRED')
    source = strict_json_loads(text=originals[0].source_bytes.decode('utf-8'))
    from .regulatory_fact_review import candidate_request
    policy = configured_transport_policy(requirement=originals[0].requirement,
                                         repo_root=ROOT)
    selected = []
    for prepared in originals:
        original = strict_json_loads(text=prepared.request_bytes.decode('utf-8'))
        request = (candidate_request(original, source=source,repo_root=prepared.data_root)
                   if original.get('source_statement_facts') else original)
        need(request['source_id'] == source['semantic_source_id']
             and request['units'] == original['units']
             and request['required_candidate_assessments'] ==
                 original['required_candidate_assessments'],
             'D03_REPLAY_ONLY_SOURCE_OR_REQUIRED_SET_CHANGED')
        selected.append(replace(prepared, request_bytes=_source_json(request),
            provider_request_body_bytes=request_body(request, policy),
            output_schema_bytes=_json(request['response_protocol']),
            replay_only=True))
    need([unit['unit_id'] for prepared in selected
          for unit in strict_json_loads(text=prepared.request_bytes.decode('utf-8'))['units']]
         == source['required_unit_ids'],
         'D03_REPLAY_ONLY_SOURCE_UNIT_COVERAGE_CHANGED')
    return selected


def _prepared_transport_policy(prepared):
    if prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
        from .current_request_configuration import transport_policy
        return transport_policy(configuration=prepared.requirement,repo_root=ROOT,limits=prepared.limits)
    return configured_transport_policy(requirement=prepared.requirement,repo_root=ROOT)


def select_native_request_variants(*, prepared_requests, ledger, source_references=False,
                                   compact_references=False, semantic_role_labels=False,
                                   relevance_repair_group_index=None):
    """Keep exact successful receipts; use indexed output for other groups.

    Selection is read-only and covers the existing complete source partition.
    Semantic role labels are opt-in for offline preparation; they never turn a
    failed or currently invalid historical response into fresh-call authority.
    A success that fails current replay stops selection rather than buying a
    replacement. Failed original requests retain their original terminal.
    """
    from .continuous_call_ledger import CallLedger
    from .native_unit_index import BASE, VERSION, upgrade_request, validate_request_partition
    from .native_assessment_replay import replay_native_response
    need(type(ledger) is CallLedger and bool(prepared_requests), 'NATIVE_VARIANT_FACTORY_INPUT_REQUIRED')
    need(all(type(p) is SemanticRequest and p._factory is _FACTORY for p in prepared_requests),
         'NATIVE_VARIANT_FACTORY_INPUT_REQUIRED')
    source = strict_json_loads(text=prepared_requests[0].source_bytes.decode())
    need(source['metric_id'] in {'B13', 'D04'} and all(
        p.source_bytes == prepared_requests[0].source_bytes for p in prepared_requests),
        'NATIVE_VARIANT_COMPLETE_SOURCE_REQUIRED')
    originals = [strict_json_loads(text=p.request_bytes.decode()) for p in prepared_requests]
    need(validate_request_partition(source, originals) == [BASE] * len(originals),
         'NATIVE_VARIANT_BASE_PARTITION_REQUIRED')
    need(type(compact_references) is bool and (not compact_references or source_references),
         'NATIVE_COMPACT_REFERENCE_SELECTION_INVALID')
    need(type(semantic_role_labels) is bool and (not semantic_role_labels or
         (source_references and compact_references and source['metric_id']=='B13')),
         'NATIVE_ROLE_LABEL_SELECTION_INVALID')
    need(type(source_references) is bool and (not source_references or source['metric_id']=='B13'),
         'NATIVE_REFERENCE_SELECTION_INVALID')
    need(relevance_repair_group_index is None or
         (type(relevance_repair_group_index) is int and
          0 <= relevance_repair_group_index < len(originals) and
          source_references and compact_references and semantic_role_labels and
          source['metric_id'] == 'B13'),
         'B13_RELEVANCE_REPAIR_SELECTION_INVALID')
    alternatives = [upgrade_request(r) for r in originals]
    variant_requests = [{BASE:r, VERSION:a} for r,a in zip(originals,alternatives)]
    selected_version = VERSION
    if source_references and source.get('program_quantity_role_contract_version'):
        from .capacity_reference_contract import VERSION as REFERENCE_VERSION, COMPACT_VERSION, ROLE_VERSION, RELEVANCE_VERSION, upgrade_request as reference_request
        for index, (versions, original) in enumerate(zip(variant_requests,originals)):
            versions[REFERENCE_VERSION] = reference_request(original)
            if compact_references:
                versions[COMPACT_VERSION] = reference_request(original, compact=True)
                if semantic_role_labels:
                    versions[ROLE_VERSION] = reference_request(original, compact=True, role_labels=True)
                    if index == relevance_repair_group_index:
                        versions[RELEVANCE_VERSION] = reference_request(original, compact=True,
                            role_labels=True, relevance_scope=True)
        if source_references:
            selected_version = (ROLE_VERSION if semantic_role_labels else
                                COMPACT_VERSION if compact_references else REFERENCE_VERSION)
    need(not source_references or selected_version != VERSION, 'NATIVE_REFERENCE_PROGRAM_SOURCE_REQUIRED')
    candidates = {r['request_id']:(i,version) for i,versions in enumerate(variant_requests)
                  for version,r in versions.items()}
    successful = {}
    with ledger.locked():
        state = ledger.snapshot()
        batch = None
        if ledger.live and (ledger.root/'batch33-authorization.json').exists():
            from .continuous_batch33 import read_authorization
            batch = read_authorization(ledger)
        for row in state['rows']:
            if row['channel'] != 'PROVIDER' or row['status'] != 'SUCCEEDED':
                continue
            path = ledger.root / 'calls' / ('%04d' % row['ordinal'])
            saved_path = path / 'semantic-request.json'
            if not saved_path.exists():
                continue
            saved = strict_json_file(path=saved_path)
            if 'source_reference_contract' in saved and saved.get('request_id') not in candidates:
                from .capacity_reference_contract import VERSION as REFERENCE_VERSION, restore_base_request as reference_base
                if saved.get('source_id') == source['semantic_source_id']:
                    original = reference_base(saved)
                    need(original in originals, 'NATIVE_REFERENCE_SAVED_SOURCE_CHANGED')
                    i = originals.index(original)
                    saved_version = saved['source_reference_contract']['version']
                    variant_requests[i][saved_version] = saved
                    candidates[saved['request_id']] = (i, saved_version)
            match = candidates.get(saved.get('request_id'))
            if match is None:
                continue
            i,version = match
            need(i not in successful, 'NATIVE_VARIANT_MULTIPLE_SUCCESSFUL_VERSIONS')
            if batch is not None and semantic_role_labels and row['ordinal'] == 111:
                from .continuous_batch33 import historical_successor_allowed
                candidate = variant_requests[i][ROLE_VERSION]
                policy = _prepared_transport_policy(prepared_requests[i])
                if historical_successor_allowed(authorization=batch, ledger=ledger,
                        ordinal=row['ordinal'], saved_request=saved,
                        replacement_request=candidate,
                        replacement_digest=request_digest(candidate, policy, limits=getattr(prepared_requests[i],'limits',DEFAULT_LIMITS))):
                    continue
            request = variant_requests[i][version]
            need(saved == request, 'NATIVE_VARIANT_SAVED_REQUEST_CHANGED')
            prepared = prepared_requests[i]
            policy = _prepared_transport_policy(prepared)
            selected = replace(prepared, request_bytes=_source_json(request),
                provider_request_body_bytes=request_body(request, policy, limits=getattr(prepared,'limits',DEFAULT_LIMITS)),
                output_schema_bytes=_json(request['response_protocol']))
            replay = replay_native_response(prepared=selected, path=path)
            successful[i] = (selected, {'request_id':request['request_id'], 'variant':version,
                'original_ordinal':row['ordinal'], 'revalidation':replay['revalidation']})
    selected, report = [], []
    for i,prepared in enumerate(prepared_requests):
        if i in successful:
            item, entry = successful[i]
        else:
            version = (RELEVANCE_VERSION if i == relevance_repair_group_index else selected_version)
            request = variant_requests[i][version]
            policy = _prepared_transport_policy(prepared)
            item = replace(prepared, request_bytes=_source_json(request),
                provider_request_body_bytes=request_body(request,policy,limits=getattr(prepared,'limits',DEFAULT_LIMITS)),
                output_schema_bytes=_json(request['response_protocol']))
            entry = {'request_id':request['request_id'], 'variant':version, 'original_ordinal':None}
        selected.append(item); report.append(entry)
    return selected, report


def transport_payload(*, request, policy):
    """Called by the existing DeepSeek transport immediately before sending."""
    need(type(request) is SemanticRequest, 'CONTINUOUS_REQUEST_TYPE_REQUIRED')
    request.validate(policy)
    return request.request_bytes,request.provider_request_body_bytes,request.output_schema_bytes


def usage_observation(raw):
    """Unknown token/cost observations stay null, including HTTP errors."""
    usage = {}
    if raw:
        try:
            value = strict_json_loads(text=raw.decode())
            if type(value) is dict and type(value.get('usage')) is dict: usage = value['usage']
        except (ValueError,UnicodeError): pass
    def count(key):
        value = usage.get(key)
        return value if type(value) is int and value>=0 else None
    return {'input_tokens':count('prompt_tokens'),'output_tokens':count('completion_tokens'),
        'cache_hit_input_tokens':count('prompt_cache_hit_tokens'),
        'cache_miss_input_tokens':count('prompt_cache_miss_tokens'),
        'actual_cost':None}


def usage_error(raw, *, expected_prompt_tokens=None, enforce_total_context=False, limits=None):
    explicit_limits = limits is not None
    limits = configured_limits(limits)
    observed = usage_observation(raw)
    if observed['input_tokens'] is None or observed['output_tokens'] is None:return 'USAGE_UNKNOWN'
    usage = strict_json_loads(text=raw.decode())['usage']
    total = usage.get('total_tokens')
    if type(total) is not int or total != observed['input_tokens']+observed['output_tokens']:
        return 'USAGE_UNKNOWN'
    hit,miss = observed['cache_hit_input_tokens'],observed['cache_miss_input_tokens']
    for key,value in [('prompt_cache_hit_tokens',hit),('prompt_cache_miss_tokens',miss)]:
        if key in usage and value is None:return 'USAGE_UNKNOWN'
    if hit is not None and miss is not None and hit+miss!=observed['input_tokens']:return 'USAGE_UNKNOWN'
    if observed['input_tokens'] > limits.max_context_tokens or (enforce_total_context and total > limits.max_context_tokens):
        return 'CONTEXT_LIMIT'
    if explicit_limits and observed['output_tokens'] > limits.output_tokens:
        return 'OUTPUT_LIMIT'
    if expected_prompt_tokens is not None and observed['input_tokens'] != expected_prompt_tokens:
        return 'CONTEXT_REFERENCE_MISMATCH'
    return ''


def build_plan(prepared, *, d03_native_assessment=False):
    requirement = prepared.requirement
    if requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
        from .current_request_configuration import transport_policy
        policy = transport_policy(configuration=requirement,repo_root=ROOT,limits=prepared.limits)
    else:
        policy = configured_transport_policy(requirement=requirement,repo_root=ROOT)
    request = prepared.validate(policy)
    metric_id = request.get('metric_id','D04')
    need(not d03_native_assessment or
         (metric_id == 'D03' and prepared.replay_only),
         'D03_NATIVE_PLAN_SCOPE_CHANGED')
    runtime = load_provider_runtime_authority(repo_root=ROOT,provider=policy.provider,model=policy.model,api=policy.api)
    from .continuous_request_context import measure_request
    context = measure_request(prepared.provider_request_body_bytes,
        provider=policy.provider, model=policy.model, api=policy.api, limits=prepared.limits)
    plan = control.build_successor_ai_invocation_plan(repo_root=ROOT,requirement_id=requirement['requirement_id'],
        authority=prepared.authority,
        release_input_plan_id=content_hash(value={'purpose':metric_id+('_SOURCE_ASSESSMENT' if metric_id == 'B13'
            or request.get('native_evidence_requested') is True or d03_native_assessment
            else '_FEASIBILITY'),'source':request['source_id']}),
        source_identity_hash=request['source_id'],selected_representation_hash=request['request_id'],
        task_contract_hash=content_hash(value={'metric':metric_id,'prompt':request['system_prompt']}),
        output_schema_hash=content_hash(value=request['response_protocol']),serialization_version='continuous-'+metric_id.lower()+'-chat-v1',
        provider=policy.provider,model=policy.model,api=policy.api,request_body=prepared.provider_request_body_bytes,
        maximum_payload_bytes=policy.maximum_payload_bytes,maximum_context_tokens=prepared.limits.max_context_tokens,
        estimated_context_tokens=context['context_tokens'],
        context_authority_hash=content_hash(value={'provider_runtime':runtime['context_authority_hash'],
            'bounded_chat_context':context['context_authority_hash']}),estimator_id=context['estimator_id'],
        estimator_version=context['estimator_version'],estimator_method=context['estimator_method'],
        billing_class=runtime['billing_class'],paid_call_observation_source=runtime['paid_call_observation_source'],
        pricing_snapshot_hash=content_hash(value={'provider':policy.provider,'model':policy.model,
            'status':'NON_BLOCKING_PRICE_UNAVAILABLE'}),estimated_cost=None)
    need(plan['observability']['estimated_context_tokens']<=prepared.limits.max_context_tokens
         and len(prepared.provider_request_body_bytes)<=policy.maximum_payload_bytes,
         'CONTINUOUS_REQUEST_RESOURCE_LIMIT')
    return policy,plan


def preserve_execution_rules(prepared, path):
    """Retain the exact rules/configuration used before later draft changes."""
    from .sources import resolve_repository_file
    if prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
        import subprocess
        version = subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,text=True,
            capture_output=True,check=False)
        commit = version.stdout.strip() if version.returncode == 0 else None
        actual_files = {name:sha256_file(path=ROOT/'scripts/vnext'/name) for name in (
            'continuous_semantic_calls.py','continuous_request_context.py','request_limits.py',
            'current_request_configuration.py','continuous_call_ledger.py','invocation_control.py','ai_adapter.py')}
        control._exclusive_write_json(path=path/'execution-configuration.json', value={
            'record_type':'CURRENT_REQUEST_EXECUTION_CONFIGURATION','configuration':prepared.requirement,
            'program_root':str(ROOT),'program_commit':commit,'actual_program_files':actual_files,
            'request_limits':prepared.limits.as_dict(),
            'source_sha256':sha256_bytes(content=prepared.source_bytes),
            'request_sha256':sha256_bytes(content=prepared.provider_request_body_bytes)})
        return
    prepared.authority._check()
    files = strict_json_loads(text=prepared.authority._files.decode())
    with (path/'execution-rules.tar.gz').open('xb') as output:
        with tarfile.open(fileobj=output,mode='w:gz') as archive:
            for relative,binding in sorted(files.items()):
                raw = resolve_repository_file(repo_root=ROOT,repo_relative_path=relative).read_bytes()
                need({'sha256':sha256_bytes(content=raw),'size':len(raw)}==binding,
                     'CONTINUOUS_EXECUTION_RULE_CHANGED:' + relative)
                member=tarfile.TarInfo(relative);member.size=len(raw);member.mode=0o600
                archive.addfile(member,io.BytesIO(raw))
        output.flush()
        import os
        os.fsync(output.fileno())
    control._exclusive_write_json(path=path/'execution-rules.json',value={
        'requirement_id':prepared.requirement['requirement_id'],
        'requirement_closure_hash':prepared.requirement['requirement_closure_hash'],'files':files})


class SourceAuthenticityFailure(ValueError):
    pass


class _Transport:
    def __init__(self, *, prepared, policy, ledger, path, intent, recorded_wire, owner_token,
                 native_assessment=False):
        self.prepared,self.policy,self.ledger = prepared,policy,ledger
        self.path,self.intent,self.recorded_wire = path,intent,recorded_wire
        self.wire = None
        self.owner_token = owner_token
        self.native_assessment = native_assessment

    @property
    def transport_kind(self):
        return 'REAL_MODEL_PROVIDER' if self.ledger.live else 'MOCK'

    def send(self, *, request_body, plan, execution_id, attempt_ordinal):
        from . import ai_adapter as adapter
        from .sources import resolve_repository_file
        import os
        need(attempt_ordinal==1 and request_body==self.prepared.provider_request_body_bytes
             and plan['ai_invocation_plan_id']==self.intent['plan_id'], 'CONTINUOUS_EXECUTION_REQUEST_CHANGED')
        need(control._SUCCESSOR_AUTHORITY.get() is self.prepared.authority and self.ledger._locked,
             'CONTINUOUS_WB3_OWNER_CONTEXT_REQUIRED')
        root = self.path/'invocation_control'
        reservation = control._validate_active_reservation_for_plan(
            reservation=strict_json_loads(text=resolve_repository_file(repo_root=root,
                repo_relative_path='reservations/'+plan['provider_request_identity'].split(':')[1]+'.json').read_text()),
            plan=plan)
        markers = control._egress_markers_for_execution(root=root,execution_id=execution_id)
        need(reservation['owner_process_id']==os.getpid()
             and reservation['owner_token_hash']==content_hash(value=self.owner_token)
             and reservation['execution_id']==execution_id
             and len(markers)==1 and markers[0]['ai_invocation_plan_id']==plan['ai_invocation_plan_id']
             and markers[0]['transport_kind']==self.transport_kind, 'CONTINUOUS_WB3_RESERVATION_OWNER_REQUIRED')
        def source_check():
            try:self.prepared.validate(self.policy)
            except ValueError as error:raise SourceAuthenticityFailure(str(error)) from error
        raw = None; output = None; request_id = ''; error_class = ''; error_detail = ''; status_code = 200
        try:
            current_runtime = self.prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1'
            if self.ledger.live or current_runtime:
                need(self.ledger.live or adapter.recorded_provider_http_active(),
                     'CURRENT_RECORDED_HTTP_BOUNDARY_REQUIRED')
                need(self.recorded_wire is None and self.ledger._locked, 'CONTINUOUS_LIVE_LEDGER_REQUIRED')
                source_check()
                if not current_runtime:
                    load_delegation(requirement=self.prepared.requirement,online=True)
                result = adapter._build_repository_transport(policy=self.policy).complete(
                    prepared_request=self.prepared,
                    egress_capability=adapter._RESERVATION_OWNER_EGRESS_CAPABILITY,
                    before_socket_open=source_check)
                raw,output,request_id = result.raw_response_bytes,result.response_bytes,result.provider_request_id
                mismatch = adapter.transport_observation_mismatch(policy=self.policy,
                    observation=result.observation,request_bytes=request_body)
                need(mismatch is None, 'CONTINUOUS_TRANSPORT_OBSERVATION_CHANGED')
            else:
                need(type(self.recorded_wire) is bytes, 'CONTINUOUS_RECORDED_WIRE_REQUIRED')
                raw = self.recorded_wire
                request_id,model,text = adapter._deepseek_chat_output_text(raw_response_bytes=raw)
                need(model==self.policy.model,'CONTINUOUS_RECORDED_MODEL_CHANGED')
                output = text.encode()
        except adapter.TransportAttemptError as error:
            raw,output,request_id = error.raw_response_bytes,error.assistant_output_bytes,error.provider_request_id
            error_class = error.error_class; status_code = adapter._controller_status_code(error_class=error_class)
            error_detail = str(error)
        except SourceAuthenticityFailure as error:
            error_class = 'SOURCE_AUTHENTICITY_FAILED'; status_code = 0
            error_detail = str(error)
        usage = usage_observation(raw)
        if not error_class:
            # The plan counted the exact outgoing body before opening a socket.
            # Compare genuine service observations without treating synthetic
            # recorded usage as evidence for the reference tokenizer.
            reference_input = None
            if self.ledger.live and plan['observability']['estimator_method'] == 'PINNED_REFERENCE_CHAT_FORMAT':
                reference_input = plan['observability']['estimated_context_tokens'] - self.prepared.limits.output_tokens
            error_class = usage_error(raw, expected_prompt_tokens=reference_input,
                                      enforce_total_context=self.ledger.live, limits=self.prepared.limits)
        for name,data in [('raw-response.bin',raw),('assistant-output.bin',output)]:
            if data is not None: control._exclusive_write_bytes(path=self.path/'wire'/name,content=data)
        body = {'record_type':'CONTINUOUS_ORIGINAL_WIRE','execution_id':execution_id,
            'intent_id':self.intent['intent_id'],'ai_invocation_plan_id':plan['ai_invocation_plan_id'],
            'request_sha256':sha256_bytes(content=request_body),'provider_request_id':request_id,
            'status_code':status_code,'error_class':error_class,'error_detail':error_detail,
            'usage':usage,'observed_at_utc':now(),
            'raw_response_sha256':None if raw is None else sha256_bytes(content=raw),
            'assistant_output_sha256':None if output is None else sha256_bytes(content=output),
            'mode':'LIVE' if self.ledger.live else 'RECORDED_TEST_ONLY'}
        self.wire = {**body,'wire_id':content_hash(value=body)}
        control._exclusive_write_json(path=self.path/'wire/journal.json',value=self.wire)
        if error_class in {'UNKNOWN_REMOTE_OUTCOME','TIMEOUT'}:
            raise control.UnknownRemoteOutcomeError(error_class)
        return {'status_code':status_code,'error_class':error_class or ('' if self.native_assessment else _FEASIBILITY),
            'response_body':output if output is not None else raw or b'',
            'provider_request_id':request_id,'usage':usage}


def execute_feasibility(*, prepared, ledger, recorded_wire=None):
    """A response is a feasibility observation, never a native result."""
    need(strict_json_loads(text=prepared.request_bytes.decode()).get('metric_id') != 'B13',
         'B13_REQUIRES_NATIVE_ASSESSMENT_ENTRY')
    need(not strict_json_loads(text=prepared.request_bytes.decode()).get('native_evidence_requested'),
         'D04_NATIVE_REQUEST_REQUIRES_NATIVE_ENTRY')
    return _execute_semantic(prepared=prepared, ledger=ledger, recorded_wire=recorded_wire,
                             native_assessment=False)


def execute_capacity_assessment(*, prepared, ledger, recorded_wire=None):
    """Accept new B13 source proposals through full native Candidate/Evidence."""
    need(strict_json_loads(text=prepared.request_bytes.decode()).get('metric_id') == 'B13',
         'B13_NATIVE_ASSESSMENT_REQUIRED')
    need(strict_json_loads(text=prepared.request_bytes.decode()).get('record_type') !=
         'B13_REFERENCE_SCAN_REQUEST', 'B13_SCAN_STAGE_HAS_NO_METRIC_RESULT')
    from .capacity_reference_contract import (ASSERTION_SCOPED_VERSION,
        CLAIM_CONTEXT_VERSION, MODEL_SPAN_VERSION, SCANNED_VERSION)
    need(strict_json_loads(text=prepared.request_bytes.decode()).get(
         'source_reference_contract', {}).get('version') not in {
             SCANNED_VERSION, ASSERTION_SCOPED_VERSION, CLAIM_CONTEXT_VERSION,
             MODEL_SPAN_VERSION},
         'B13_TWO_STAGE_EXECUTION_PROOF_REQUIRED')
    return _execute_semantic(prepared=prepared, ledger=ledger, recorded_wire=recorded_wire,
                             native_assessment=True)


def execute_capacity_scan(*, prepared, ledger, recorded_wire=None):
    """Record a bounded scan with no metric Result or live-call authority."""
    request = strict_json_loads(text=prepared.request_bytes.decode())
    need(request.get('record_type') == 'B13_REFERENCE_SCAN_REQUEST'
         and request.get('metric_id') == 'B13', 'B13_SCAN_STAGE_REQUIRED')
    need(not ledger.live, 'B13_TWO_STAGE_LIVE_EXECUTION_NOT_AUTHORIZED')
    return _execute_semantic(prepared=prepared, ledger=ledger, recorded_wire=recorded_wire,
                             native_assessment=True, scan_stage=True)


def execute_capacity_interpretation(*, prepared, ledger, recorded_wire=None):
    """Recorded V5 assessment requires an earlier exact successful scan."""
    from .capacity_reference_contract import (ASSERTION_SCOPED_VERSION,
        CLAIM_CONTEXT_VERSION, MODEL_SPAN_VERSION, SCANNED_VERSION)
    from .capacity_two_stage import saved_scan_stage
    request = strict_json_loads(text=prepared.request_bytes.decode())
    need(request.get('source_reference_contract', {}).get('version')
         not in {ASSERTION_SCOPED_VERSION, CLAIM_CONTEXT_VERSION,
                 MODEL_SPAN_VERSION},
         'B13_ASSERTION_SCOPE_ACCEPTANCE_SUSPENDED')
    need(request.get('metric_id') == 'B13'
         and request.get('source_reference_contract', {}).get('version') == SCANNED_VERSION,
         'B13_TWO_STAGE_INTERPRETATION_REQUIRED')
    need(not ledger.live, 'B13_TWO_STAGE_LIVE_EXECUTION_NOT_AUTHORIZED')
    proof = request['two_stage_contract']['scan_execution_proof']
    ordinal = proof['scan_ordinal']
    need(type(ordinal) is int and ordinal > 0, 'B13_TWO_STAGE_SCAN_ORDER_INVALID')
    path = ledger.root/'calls'/('%04d' % ordinal)
    with ledger.locked():
        state = ledger.snapshot()
        need(any(row['ordinal'] == ordinal and row['status'] == 'SUCCEEDED'
                 for row in state['rows']), 'B13_TWO_STAGE_SCAN_LEDGER_SUCCESS_REQUIRED')
        stage = saved_scan_stage(prepared=prepared, scan_path=path)
        need(stage['stage_proof'] == proof, 'B13_TWO_STAGE_SCAN_PROOF_CHANGED')
    return _execute_semantic(prepared=prepared, ledger=ledger, recorded_wire=recorded_wire,
                             native_assessment=True, two_stage_scan=(path, stage))


def execute_d04_assessment(*, prepared, ledger, recorded_wire=None):
    """Fresh current-source D04 Evidence; historical diagnostics are not inputs."""
    need(strict_json_loads(text=prepared.request_bytes.decode())['record_type'] == 'D04_NATIVE_INTERPRETATION_REQUEST',
         'D04_FRESH_NATIVE_REQUEST_REQUIRED')
    return _execute_semantic(prepared=prepared, ledger=ledger, recorded_wire=recorded_wire,
                             native_assessment=True)


def _require_d03_recorded_ledger(ledger):
    """Reject a live or relabelled budget root before any D03 read or claim."""
    from .continuous_call_ledger import CallLedger, _FACTORY as ledger_factory
    live_root = Path(strict_json_file(path=ROOT/
        'config/issue28_continuous_calls_v1.json')['budget_root']).resolve()
    need(type(ledger) is CallLedger and ledger._factory is ledger_factory
         and not ledger.live
         and ledger.root == ledger.root.resolve()
         and ledger.root != live_root and live_root not in ledger.root.parents
         and ledger.binding.get('execution_mode') == 'RECORDED_TEST_ONLY'
         and ledger.binding.get('root') == str(ledger.root),
         'D03_NATIVE_RECORDED_LEDGER_REQUIRED')


def execute_d03_recorded_assessment(*, prepared, ledger, recorded_wire=None):
    """Prove the native request chain offline without opening D03 live calls."""
    request = strict_json_loads(text=prepared.request_bytes.decode())
    _require_d03_recorded_ledger(ledger)
    current_runtime = prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1'
    need((recorded_wire is None if current_runtime else type(recorded_wire) is bytes),
         'D03_NATIVE_RECORDED_WIRE_REQUIRED')
    external = (prepared.source_ledger is ledger and
                prepared.data_root == ledger.root/'source-inputs')
    need(prepared.replay_only and (prepared.data_root == ROOT or external)
         and (not external or request.get('external_replay_only') is True)
         and request.get('record_type') == 'D03_INTERPRETATION_REQUEST'
         and request.get('metric_id') == 'D03'
         and not request.get('source_statement_facts'),
         'D03_NATIVE_REPLAY_ONLY_CURRENT_REQUEST_REQUIRED')
    from .native_request_construction import request_construction_session
    if prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
        return _execute_semantic(prepared=prepared, ledger=ledger, recorded_wire=None,
            native_assessment=True, d03_recorded_native=True)
    with request_construction_session(prepared.requirement):
        return _execute_semantic(prepared=prepared, ledger=ledger,
            recorded_wire=recorded_wire, native_assessment=True,
            d03_recorded_native=True)


def _execute_semantic(*, prepared, ledger, recorded_wire, native_assessment,
                      scan_stage=False, two_stage_scan=None,
                      d03_recorded_native=False):
    from .r6_semantic_scope import validate_response
    need(not prepared.d04_saved_response_only, 'D04_SAVED_RESPONSE_CANNOT_EXECUTE')
    request_fields=strict_json_loads(text=prepared.request_bytes.decode())
    if request_fields.get('metric_id') == 'D03':
        source_fields = strict_json_loads(text=prepared.source_bytes.decode())
        if (prepared.data_root != ROOT or source_fields.get('external_replay_only')
                or request_fields.get('external_replay_only')):
            need(d03_recorded_native and prepared.replay_only
                 and source_fields.get('external_replay_only') is True
                 and request_fields.get('external_replay_only') is True
                 and prepared.source_ledger is ledger
                 and prepared.data_root == ledger.root/'source-inputs',
                 'D03_EXTERNAL_REPLAY_EXECUTION_NOT_AUTHORIZED')
    need(not scan_stage or (native_assessment and not ledger.live
         and request_fields.get('record_type') == 'B13_REFERENCE_SCAN_REQUEST'),
         'B13_SCAN_STAGE_EXECUTION_SCOPE_CHANGED')
    need(two_stage_scan is None or (native_assessment and not ledger.live
         and request_fields.get('metric_id') == 'B13'),
         'B13_TWO_STAGE_EXECUTION_SCOPE_CHANGED')
    need(not d03_recorded_native or (native_assessment and not ledger.live
         and (type(recorded_wire) is bytes or prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1'
              and recorded_wire is None) and prepared.replay_only
         and (prepared.data_root == ROOT or
              prepared.source_ledger is ledger and prepared.data_root == ledger.root/'source-inputs')
         and request_fields.get('record_type') == 'D03_INTERPRETATION_REQUEST'
         and request_fields.get('metric_id') == 'D03'
         and not request_fields.get('source_statement_facts')),
         'D03_NATIVE_RECORDED_SCOPE_CHANGED')
    if request_fields.get('metric_id') == 'B13':
        from .capacity_reference_contract import ROLE_VERSION, RELEVANCE_VERSION
        need(not (ledger.live and request_fields.get('source_reference_contract', {}).get('version')
                  in {ROLE_VERSION, RELEVANCE_VERSION}
                  and not (getattr(ledger, 'root', None) is not None
                           and (ledger.root/'batch33-authorization.json').exists())),
             'B13_ROLE_V3_LIVE_VALIDATION_NOT_AUTHORIZED')
    need(not prepared.replay_only or d03_recorded_native,
         'CONTINUOUS_REPLAY_OBJECT_CANNOT_EXECUTE')
    if prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
        from .ai_adapter import recorded_provider_http_active
        need(not ledger.live or not recorded_provider_http_active(),
             'CURRENT_RECORDED_HTTP_CANNOT_RUN_LIVE')
    # The D03 source-fact successor is a diagnostic request identity only.
    # A copied dataclass with replay_only=False cannot turn it into a call.
    need('source_fact_review_contract' not in request_fields or d03_recorded_native,
         'D03_SOURCE_ANCHOR_EXECUTION_NOT_AUTHORIZED')
    if prepared.source_ledger is not None:
        need(prepared.source_ledger.live==ledger.live and prepared.source_ledger.root==ledger.root,
             'CONTINUOUS_SOURCE_EXECUTION_LEDGER_CHANGED')
    need(not native_assessment or request_fields.get('metric_id') == 'B13'
         or request_fields['record_type'] == 'D04_NATIVE_INTERPRETATION_REQUEST'
         or d03_recorded_native,
         'NATIVE_DIAGNOSTIC_UPGRADE_FORBIDDEN')
    if request_fields['record_type']=='D03_SEMANTIC_VERIFICATION_REQUEST':
        from .r6_semantic_verification import validate_response
    elif request_fields.get('metric_id')=='D03':
        if d03_recorded_native:
            from .d03_native_assessment import _validate_bound_response
            def validate_response(*, request, raw_response):
                return _validate_bound_response(request=request,
                                                raw_response=raw_response)
        else:
            from .r6_regulatory_semantics import validate_response
    elif scan_stage:
        from .capacity_two_stage import prior_for_scan, validate_scan
        from .capacity_two_stage import (SCAN_COVERAGE_VERSION,
                                         validate_coverage_scan)
        prior = prior_for_scan(source=strict_json_loads(text=prepared.source_bytes.decode()),
                               scan=request_fields)
        scan_validate = (validate_coverage_scan
            if request_fields['scan_contract']['version'] == SCAN_COVERAGE_VERSION
            else validate_scan)
        def validate_response(*, request, raw_response):
            return scan_validate(request=prior, scan_request_value=request,
                                 raw_response=raw_response)
    elif two_stage_scan is not None:
        from .capacity_two_stage import validate_interpretation
        _, stage = two_stage_scan
        def validate_response(*, request, raw_response):
            return validate_interpretation(request=stage['prior_request'],
                scan_result=stage['scan_result'],
                scan_raw_response=stage['scan_raw_response'],
                interpretation=request, raw_response=raw_response,
                source=strict_json_loads(text=prepared.source_bytes.decode()))
    elif request_fields.get('metric_id') == 'B13':
        from .capacity_semantic_review import validate_response as capacity_validate_response
        def validate_response(*,request,raw_response):
            return capacity_validate_response(request=request,raw_response=raw_response,
                source=strict_json_loads(text=prepared.source_bytes.decode()))
    elif request_fields['record_type'] == 'D04_NATIVE_INTERPRETATION_REQUEST':
        from .d04_native_assessment import validate_response
    policy,plan = build_plan(prepared,
        d03_native_assessment=d03_recorded_native)
    digest = request_digest(request_fields, policy, limits=prepared.limits)
    batch_group_id = None
    repair189 = None
    v4_enphase = None
    if not ledger.live and (ledger.root/'batch33-authorization.json').exists():
        from .continuous_batch33 import read_authorization as read_batch_authorization, group_for_request
        if (ledger.root/'batch33-repair-189.json').exists():
            from .continuous_batch33_repair189 import read_authorization as read_repair189
            repair189 = read_repair189(ledger)
        if (ledger.root/'batch33-b13-v4-enphase.json').exists():
            from .continuous_b13_v4_enphase import read_authorization as read_v4
            v4_enphase = read_v4(ledger)
        batch_group_id = group_for_request(authorization=read_batch_authorization(ledger),
                                           request=request_fields, request_digest=digest,
                                           repair189=repair189, v4_enphase=v4_enphase)
    def response_validator(**kwargs):
        if native_assessment:
            try:
                validate_response(request=request_fields, raw_response=kwargs['response_body'])
            except (ValueError, KeyError, TypeError) as error:
                raise control.SchemaViolationError(str(error)) from error

    def evidence_validator(**kwargs):
        if native_assessment:
            if scan_stage:
                from .capacity_two_stage import build_scan_acceptance as build_acceptance
            elif two_stage_scan is not None:
                from .capacity_two_stage import build_interpretation_acceptance
                def build_acceptance(*, prepared, plan, response_body):
                    return build_interpretation_acceptance(prepared=prepared,
                        plan=plan, response_body=response_body,
                        scan_path=two_stage_scan[0])
            elif request_fields.get('metric_id') == 'B13':
                from .capacity_native_assessment import build_acceptance
            elif d03_recorded_native:
                from .d03_native_assessment import _build_bound_acceptance as build_acceptance
            else:
                from .d04_native_assessment import build_acceptance
            try:
                return build_acceptance(prepared=prepared, plan=plan, response_body=kwargs['response_body'])
            except (ValueError, KeyError, TypeError) as error:
                raise control.EvidenceFailureError(str(error)) from error
    if ledger.live:
        if prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
            from .current_request_configuration import live_scope
            live_scope(configuration=prepared.requirement,metric_id=request_fields['metric_id'],limits=prepared.limits)
        need(recorded_wire is None, 'CONTINUOUS_RECORDED_BYTES_CANNOT_RUN_LIVE')
        need(ledger.root == Path(prepared.requirement['policy']['budget_root'])
             and ledger.binding['delegation_url'] == prepared.requirement['policy']['delegation_url']
             and ledger.binding['delegation_body_sha256'] == prepared.requirement['policy']['delegation_body_sha256']
             and ledger.binding['limits'] == [240,240,80], 'CONTINUOUS_LIVE_ALLOWANCE_CHANGED')
        if prepared.requirement['policy'].get('recovery_110_policy_path'):
            from .continuous_recovery_110 import authorization, read_authorization
            need(request_fields.get('metric_id') in {'B13', 'D04'}, 'RECOVERY110_FOLLOWING_METRIC_FORBIDDEN')
            need(read_authorization(ledger) == authorization(ledger=ledger, online=True),
                 'RECOVERY110_LIVE_AUTHORIZATION_CHANGED')
        from .continuous_batch33 import (authorization as batch_authorization,
            read_authorization as read_batch_authorization, group_for_request)
        batch = read_batch_authorization(ledger)
        need(batch is not None and batch == batch_authorization(ledger=ledger, online=True),
             'BATCH33_LIVE_AUTHORIZATION_REQUIRED')
        if (ledger.root/'batch33-repair-189.json').exists():
            from .continuous_batch33_repair189 import read_authorization as read_repair189
            repair189 = read_repair189(ledger)
        if (ledger.root/'batch33-b13-v4-enphase.json').exists():
            from .continuous_b13_v4_enphase import read_authorization as read_v4
            v4_enphase = read_v4(ledger)
        batch_group_id = group_for_request(authorization=batch, request=request_fields,
                                           request_digest=digest, repair189=repair189,
                                           v4_enphase=v4_enphase)
        from .ai_adapter import api_key_environment_name
        import os
        need(bool(os.environ.get(api_key_environment_name(policy=policy),'').strip()),
             'DEEPSEEK_API_KEY_REQUIRED')
        # This flag is installed only after the actual offline bridge and count
        # tests have been saved and bound to this implementation.
        if prepared.requirement.get('record_type') != 'CURRENT_REQUEST_CONFIGURATION_V1':
            from .continuous_call_wiring import validate_wiring_receipt
            validate_wiring_receipt(requirement=prepared.requirement)
    # Current recorded execution uses the real repository transport. Tests must
    # replace _open_provider_request at the HTTP boundary, not feed raw output
    # directly to this controller or turn a recorded ledger into a live one.
    if prepared.requirement.get('record_type') == 'CURRENT_REQUEST_CONFIGURATION_V1':
        need(recorded_wire is None, 'CURRENT_RECORDED_EXECUTION_REQUIRES_HTTP_BOUNDARY')
        from .ai_adapter import recorded_provider_http_active
        need(ledger.live or recorded_provider_http_active(),
             'CURRENT_RECORDED_HTTP_BOUNDARY_REQUIRED')
    with ledger.locked():
        path,intent = ledger.claim(channel='PROVIDER',request_digest=digest,
            requirement=prepared.requirement,plan_id=plan['ai_invocation_plan_id'],
            purpose='remaining_development_feasibility',batch_group_id=batch_group_id,
            batch_repair_receipt=(repair189 if repair189 is not None and
                digest == repair189['repaired_request_digest'] else None),
            batch_b13_v4_receipt=(v4_enphase if v4_enphase is not None and
                any(row['v4_digest'] == digest for row in v4_enphase['successor_groups'])
                else None))
        control._exclusive_write_bytes(path=path/'source.json',content=prepared.source_bytes)
        control._exclusive_write_bytes(path=path/'semantic-request.json',content=prepared.request_bytes)
        preserve_execution_rules(prepared,path)
        owner = str(uuid.uuid4()); when = now()
        transport = _Transport(prepared=prepared,policy=policy,ledger=ledger,path=path,intent=intent,
            recorded_wire=recorded_wire,owner_token=owner,native_assessment=native_assessment)
        execution = control.execute_successor_invocation(repo_root=ROOT,authority=prepared.authority,
            workspace_dir=path,plan=plan,request_body=prepared.provider_request_body_bytes,
            execution_id=control.execution_identity(ai_invocation_plan_id=plan['ai_invocation_plan_id'],owner_token=owner,authorized_at_utc=when),
            owner_token=owner,authorized_at_utc=when,clock=now,transport=transport,
            response_validator=response_validator,evidence_validator=evidence_validator)
        terminal = ledger.finish_provider(path=path,intent=intent,execution=execution,wire=transport.wire)
        result = {'execution_receipt_id':execution['execution_receipt_id'],'terminal':terminal,
            'semantic_correctness_verified':False,'native_result_created':False,'production_authorized':False}
        if native_assessment:
            result['native_candidate_evidence_created'] = execution['status'] == 'SUCCEEDED'
            result['acceptance_scope'] = ('SCAN_SHAPE_ONLY_NO_B13_METRIC_CREDIT' if scan_stage
                else 'ONE_HISTORICAL_CONTROL_REQUEST_NOT_CURRENT_OR_WHOLE_FILING'
                if 'historical_control' in request_fields else 'ONE_REQUEST_SOURCE_ASSESSMENT_NOT_COMPLETE_METRIC')
        output = path/'wire/assistant-output.bin'
        if output.exists() and not transport.wire['error_class']:
            try:
                result['response_check'] = validate_response(request=strict_json_loads(text=prepared.request_bytes.decode()),
                    raw_response=output.read_bytes())
            except (ValueError,KeyError,TypeError) as error:
                result['response_check_error'] = str(error)
        filename = ({'B13': 'capacity-assessment.json',
                     'D03': 'd03-assessment.json',
                     'D04': 'd04-assessment.json'}[request_fields['metric_id']]
                    if native_assessment else 'feasibility.json')
        control._exclusive_write_json(path=path/filename,value=result)
        return path,result


def reconcile_saved_provider_terminal(*, ledger, ordinal):
    """Complete a known written terminal after a crash, without sending again.

    An intent/unknown remote outcome is never guessed into success. Existing
    marker, journal, receipt and original count checks remain ledger-owned.
    This produces no Candidate/Result and does not reopen a failed opportunity.
    """
    need(type(ordinal) is int and ordinal > 0,'CURRENT_RECONCILE_ORDINAL_INVALID')
    path = ledger.root/'calls'/('%04d' % ordinal)
    with ledger.locked():
        ledger.snapshot()
        if (path/'terminal.json').is_file():
            return strict_json_file(path=path/'terminal.json')
        config = strict_json_file(path=path/'execution-configuration.json')
        need(config['record_type'] == 'CURRENT_REQUEST_EXECUTION_CONFIGURATION',
             'CURRENT_RECONCILE_CONFIGURATION_REQUIRED')
        intent = strict_json_file(path=path/'intent.json')
        wire = strict_json_file(path=path/'wire/journal.json')
        name = wire['execution_id'].split(':',1)[1]
        execution = strict_json_file(path=path/'invocation_control/executions'/(name+'.json'))
        need(wire['intent_id'] == intent['intent_id']
             and wire['request_sha256'] == config['request_sha256']
             and wire['execution_id'] == execution['execution_id'],
             'CURRENT_RECONCILE_EXECUTION_CHANGED')
        for relative, field in [('raw-response.bin','raw_response_sha256'),
                                ('assistant-output.bin','assistant_output_sha256')]:
            need(wire[field] is None or sha256_file(path=path/'wire'/relative) == wire[field],
                 'CURRENT_RECONCILE_RESPONSE_CHANGED')
        root = path/'invocation_control'
        plan = strict_json_file(path=root/'plans'/(intent['plan_id'].split(':',1)[1]+'.json'))
        need(plan['ai_invocation_plan_id'] == intent['plan_id']
             and plan['provider_request_body_sha256'] == wire['request_sha256'],
             'CURRENT_RECONCILE_PLAN_CHANGED')
        reservation_path = control._reservation_path(root=root,
            request_identity=plan['provider_request_identity'])
        if reservation_path.exists():
            reservation = control._validate_active_reservation_for_plan(
                reservation=strict_json_file(path=reservation_path),plan=plan)
            need(reservation['execution_id'] == execution['execution_id'],
                 'CURRENT_RECONCILE_RESERVATION_CHANGED')
            control._archive_reservation(root=root,reservation_path=reservation_path,
                reservation=reservation,terminal_status=execution['status'])
        return ledger.finish_provider(path=path,intent=intent,execution=execution,wire=wire)


def read_saved_semantic_call(*, ledger, ordinal):
    """Read ordinary saved current call bytes; never replay a paid request."""
    need(type(ordinal) is int and ordinal > 0,'CURRENT_READ_ORDINAL_INVALID')
    path = ledger.root/'calls'/('%04d' % ordinal)
    need((ledger.root/'binding.json').is_file(),'CURRENT_READ_EXISTING_LEDGER_REQUIRED')
    with ledger.locked():
        state = ledger.snapshot()
        need(any(row['ordinal'] == ordinal for row in state['rows']),
             'CURRENT_READ_CALL_MISSING')
        config = strict_json_file(path=path/'execution-configuration.json')
        need(config['record_type'] == 'CURRENT_REQUEST_EXECUTION_CONFIGURATION',
             'CURRENT_READ_CONFIGURATION_REQUIRED')
        need(sha256_file(path=path/'source.json') == config['source_sha256'],
             'CURRENT_READ_SOURCE_CHANGED')
        source = strict_json_file(path=path/'source.json')
        request = strict_json_file(path=path/'semantic-request.json')
        need(request['source_id'] == source['semantic_source_id'],
             'CURRENT_READ_REQUEST_SOURCE_CHANGED')
        wire = strict_json_file(path=path/'wire/journal.json')
        need(wire['request_sha256'] == config['request_sha256'],
             'CURRENT_READ_REQUEST_CHANGED')
        raw = (path/'wire/raw-response.bin').read_bytes() if (path/'wire/raw-response.bin').exists() else None
        output = (path/'wire/assistant-output.bin').read_bytes() if (path/'wire/assistant-output.bin').exists() else None
        for value, field in [(raw,'raw_response_sha256'),(output,'assistant_output_sha256')]:
            need((None if value is None else sha256_bytes(content=value)) == wire[field],
                 'CURRENT_READ_RESPONSE_CHANGED')
        return {'configuration':config,'source':source,'request':request,'wire':wire,
            'raw_response':raw,'assistant_output':output,
            'terminal':strict_json_file(path=path/'terminal.json') if (path/'terminal.json').exists() else None,
            'calls':{'provider':0,'paid':0,'sec':0},'native_result_created':False,
            'semantic_correctness_verified':False,'production_authorized':False}
