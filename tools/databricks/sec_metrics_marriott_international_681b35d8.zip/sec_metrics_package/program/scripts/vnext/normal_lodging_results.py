"""Ordinary B10/B11 records from rebuilt reported lodging table cells."""
from pathlib import Path

from sec_urls import submissions_url,companyfacts_url
from .calculator import calculate_observation_metric,metric_is_applicable,withheld_metric_result
from .canonical import content_hash,sha256_file
from .lodging_table_source import prepare_saved_lodging_source,LodgingSourceError,POLICY_PATH
from .normal_annual_input_v2 import prepare_saved_annual_input,exact_json_value
from .normal_governance_input import _Sources
from .normal_source_authority import ROOT
from .ordinary_source_authority import verify_ordinary_source_proofs
from .observations import structured_observation,scope_key
from .sources import resolve_repository_file
from .specs import compile_spec_file
from .traits import repository_company_traits
from .calculator import _manual_result_trace


SPEC_PATHS={m:'catalog/ordinary_lodging/'+m+'.md' for m in ['B10','B11']}


class SelectedLodgingCalculationError(ValueError):
    """A selected component does not belong to this metric/source/period."""


def _calculation_need(condition, reason):
    if not condition:raise SelectedLodgingCalculationError(reason)


def _need(condition,reason):
    if not condition:raise ValueError(reason)


def _spec(root,metric):
    path=SPEC_PATHS[metric]
    _need(sha256_file(path=resolve_repository_file(repo_root=root,repo_relative_path=path))==sha256_file(path=ROOT/path),
          'ORDINARY_LODGING_INSTALLED_SPEC_CHANGED')
    spec=compile_spec_file(path=root/path,dependency_specs={});semantic=spec['compiled'];rule=semantic['quality_rule']
    _need(rule['resolver']=='ordinary_lodging_table_v1' and rule['source_policy']==POLICY_PATH
          and rule['source_policy_sha256']==sha256_file(path=ROOT/POLICY_PATH),'ORDINARY_LODGING_SOURCE_POLICY_CHANGED')
    original=compile_spec_file(path=ROOT/rule['original_metric_spec'],dependency_specs={})
    _need(rule['original_metric_spec_sha256']==sha256_file(path=ROOT/rule['original_metric_spec']),
          'ORDINARY_LODGING_ORIGINAL_SPEC_CHANGED')
    fields=['metric_id','kind','canonical_unit','reported_unit','applicability','required_claims',
            'scope_contract','forbidden_confusions','inputs','formula','top_level_guards','dependencies']
    _need(all(semantic[k]==original['compiled'][k] for k in fields),'ORDINARY_LODGING_ECONOMIC_DEFINITION_CHANGED')
    return spec


def calculate_selected_lodging_metric(*, prepared, component, reference, metric_id, spec, traits):
    """Calculate one metric from the table component selected for its actual period.

    Current and historical preparation own filing selection and source reading.
    This function shares the observation binding and Calculator; it never picks
    a newer filing, rereads a source, creates a Run, or writes a result.
    """
    _calculation_need(metric_id in SPEC_PATHS and spec['compiled']['metric_id']==metric_id,
          'LODGING_CALCULATION_METRIC_CONFLICT')
    company_id=prepared['company_id'];period=prepared['table_input']['target_period']
    scope={k:v for k,v in spec['compiled']['required_claims'].items() if k!='period_role'}
    fact=component['selection']['facts'][metric_id]
    _calculation_need(component['company_id']==company_id and component['source_reference']==reference
          and reference['company_id']==company_id
          and reference['accession']==prepared['filing']['accessionNumber'],
          'LODGING_CALCULATION_SOURCE_CONFLICT')
    _calculation_need(fact['scope']==scope and fact['period']==period,
          'LODGING_CALCULATION_SCOPE_OR_PERIOD_CONFLICT')
    witnesses=fact['source_witnesses'];amount=witnesses['amount']
    binding={'raw_asset_id':reference['raw_asset_id'],'source_reference_id':reference['source_reference_id'],
        'source_role':reference['source_role'],'document_name':reference['document_name'],'accession':reference['accession'],
        'entity':prepared['entity'],'form':prepared['filing']['form'],'filed':prepared['filing']['filingDate'],
        'derived_asset_id':component['derived_asset']['derived_asset_id'],'table_locator':amount['locator'],
        'reported_raw_text':amount['raw_text'],'reported_value':fact['reported_value'],'reported_unit':fact['reported_unit'],
        'source_witnesses':witnesses,'source_component_id':component['component_id'],
        'period_basis':fact['period_basis'],'ordinary_source_policy_hash':component['policy_hash']}
    observation=structured_observation(metric_id=metric_id,semantic_role=fact['semantic_role'],
        company_id=company_id,period_start=period['period_start'],period_end=period['period_end'],scope=scope,
        value=fact['value'],unit=fact['unit'],quality='EXACT',source_binding=binding)
    target={'company_id':company_id,'period_start':period['period_start'],'period_end':period['period_end'],
            'scope':scope,'scope_key':scope_key(scope=scope)}
    result,trace=calculate_observation_metric(compiled_spec=spec,target=target,company_traits=traits,observation=observation)
    selection={'classification':'DETERMINISTIC_REPORTED_TABLE','reason_code':result['reason_code'],
        'table_id':component['selection']['table_id'],'source_component_id':component['component_id'],
        'source_witnesses':witnesses,'period_basis':fact['period_basis'],'ai_response_used':False,
        'qualification_credit':False}
    return {'observation':observation,'result':result,'trace':trace,'selection':selection}


def prepare_ordinary_lodging_case(*,repo_root:Path,company_id:str,metric_id:str,rules_root=None):
    _need(metric_id in SPEC_PATHS,'ORDINARY_LODGING_METRIC_UNSUPPORTED')
    rules=repo_root if rules_root is None else Path(rules_root)
    spec=_spec(rules,metric_id)
    if rules_root is not None:
        from .company_registry import _registry_rows
        source_row=next(r for r in _registry_rows(repo_root=repo_root) if r['company_id']==company_id)
        rule_row=next(r for r in _registry_rows(repo_root=rules) if r['company_id']==company_id)
        _need(source_row==rule_row,'ORDINARY_LODGING_SOURCE_SUBJECT_REGISTRY_CHANGED')
    prepared=prepare_saved_annual_input(repo_root=repo_root,company_id=company_id,
        **({} if rules_root is None else {'ordinary_registered':True}))
    period=prepared['table_input']['target_period'];traits=repository_company_traits(repo_root=rules,company_id=company_id)
    reader=_Sources(repo_root,company_id,prepared['entity'])
    reader.read(submissions_url(cik=int(prepared['entity'])),role='sec_submissions_inventory',media_type='application/json')
    primary=reader.primary(prepared['filing'])
    reader.read(companyfacts_url(cik=int(prepared['entity'])),accession=prepared['filing']['accessionNumber'],role='companyfacts',media_type='application/json')
    scope={k:v for k,v in spec['compiled']['required_claims'].items() if k!='period_role'}
    target={'company_id':company_id,'period_start':period['period_start'],'period_end':period['period_end'],
            'scope':scope,'scope_key':scope_key(scope=scope)}
    observations=[];assets=[];source_component=None;selection=None
    if not metric_is_applicable(applicability=spec['compiled']['applicability'],traits=traits):
        result,trace=_manual_result_trace(metric_id=metric_id,company_id=company_id,
            period_start=period['period_start'],period_end=period['period_end'],scope=scope,spec_closure_hash=spec['spec_closure_hash'],
            applicability='N_A_STRUCTURAL',quality='NONE',reason_code='TRAIT_NOT_APPLICABLE',input_observation_ids=[],
            steps=[{'event':'N_A_STRUCTURAL'}],accession=None,entity=None,unit=None)
        selection={'classification':'STRUCTURAL','reason_code':'TRAIT_NOT_APPLICABLE'}
    else:
        try:
            source_component=prepare_saved_lodging_source(repo_root=repo_root,company_id=company_id,prepared_input=prepared,
                **({} if rules_root is None else {'rules_root':rules}))
            component=source_component['component'];fact=component['selection']['facts'][metric_id]
            _need(source_component['prepared_input']==prepared and component['source_reference']==primary['source_reference'],
                  'ORDINARY_LODGING_SOURCE_SELECTION_CHANGED')
            _need(fact['scope']==scope and fact['period']==period,'ORDINARY_LODGING_SCOPE_OR_PERIOD_CHANGED')
            calculated=calculate_selected_lodging_metric(prepared=prepared,component=component,
                reference=primary['source_reference'],metric_id=metric_id,spec=spec,traits=traits)
            observation,result,trace=(calculated[k] for k in ('observation','result','trace'))
            observations=[observation];assets=[component['derived_asset']]
            selection=calculated['selection']
        except LodgingSourceError as error:
            result,trace=withheld_metric_result(compiled_spec=spec,target=target,reason_code='ORDINARY_LODGING_SOURCE_UNRESOLVED')
            selection={'classification':'SOURCE_OR_IMPLEMENTATION_UNRESOLVED','reason':str(error),'reason_code':result['reason_code']}
    proofs=list({content_hash(value=p):p for p in [*prepared['source_proofs'],*[x['proof'] for x in reader.proofs.values()]]}.values())
    admission=verify_ordinary_source_proofs(data_root=repo_root,proofs=proofs);records=list(reader.records.values())
    binding=exact_json_value({'record_type':'ORDINARY_LODGING_INPUT','prepared_input':prepared,'source_component':source_component,
        'source_proofs':proofs,'source_admission':admission,'selection':selection,'module_sha256':sha256_file(path=Path(__file__))})
    return {'kind':'STRUCTURED','primary_metric_id':metric_id,'input_binding':binding,
        'source_records':records,'references':[r for r in records if r['record_type']=='SOURCE_REFERENCE'],
        'source_proofs':proofs,'admission':admission,'spec_paths':{metric_id:SPEC_PATHS[metric_id]},
        'compiled_specs':{metric_id:spec},'target_period':period,'expected_records':[*records,*assets,*observations,trace,result],
        'results':{metric_id:result},'traces':{metric_id:trace},'observations':observations,'selection':selection,
        **({} if rules_root is None else {'rules_root':str(rules)})}
