---
{
  "metric_id": "E01",
  "name": "M&A announcements (content-confirmed)",
  "kind": "direct_numeric",
  "canonical_unit": "count",
  "reported_unit": "count",
  "unit_policy": "fixed_canonical",
  "source_mode": "structured",
  "applicability": {
    "all": [],
    "none": []
  },
  "required_claims": {},
  "scope_contract": null,
  "forbidden_confusions": [],
  "inputs": {},
  "formula": null,
  "top_level_guards": [],
  "identity_constraints": [],
  "quality_rule": {},
  "legacy_projection": {
    "status": "8K_ITEM_OK",
    "source_class": "8K_ITEM",
    "event_route_hash": "sha256:b19f55b6662020ec0676ab807326de20b4d8371ed9bfa0400677aad0d909c8d2"
  },
  "review_policy": "none",
  "selection_policy": {
    "semantic_version": "1",
    "period_filter": "target_period",
    "form_rule": "10-K_PREFIX_AND_FY",
    "within_concept_order": [
      "filed_desc",
      "accession_desc",
      "unit_desc"
    ],
    "target_accession_priority": true,
    "ambiguous_after_tie_break": "AMBIGUOUS_CANDIDATE"
  },
  "dependencies": [],
  "disclosure_group": null
}
---

# M&A announcements (content-confirmed)
