import contextlib,hashlib,io,json,socket,sys,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
company,name=sys.argv[1:3]
start_year,end_year=sys.argv[3:5] if len(sys.argv)>3 else ("2021","2025")
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence')/('successor-outcomes-'+name+'-20261009')
source='/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs'
def snapshot():
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (root/'state/updates').rglob('*') if p.is_file()
            and ('results' in p.parts or p.name=='current-result.json')}
args=['run','--company',company,'--period','fiscal-years','--fiscal-year-start',start_year,
      '--fiscal-year-end',end_year,'--metric','B02','--metric','B04','--metric','B05','--metric','B07','--source-root',source,
      '--work-dir',str(root/'state'),'--output-dir',str(root/'outputs')]
before=snapshot();out=io.StringIO();start=time.monotonic()
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')), \
     patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('No repeat preparation')) as select, \
     patch('vnext.historical_statement_cases._deterministic_metric_graph',side_effect=AssertionError('No repeat calculation')) as graph, \
     contextlib.redirect_stdout(out):
    rc=main(args)
repeat=json.loads(out.getvalue());repeat_seconds=time.monotonic()-start;after=snapshot()
out=io.StringIO();start=time.monotonic()
read_args=['results','--company',company,'--state-root',str(root/'state'),
           '--output-root',str(root/'independent-read')]
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')), \
     patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('No read selection')) as read_select, \
     patch('vnext.company_current_records.run_once',side_effect=AssertionError('No read update')) as update, \
     contextlib.redirect_stdout(out):
    read_rc=main(read_args)
read=json.loads(out.getvalue());read_seconds=time.monotonic()-start
record={'company':company,'command':args,'repeat_exit':rc,'repeat_seconds':repeat_seconds,
        'repeat_preparation_calls':select.call_count,'repeat_calculation_calls':graph.call_count,
        'saved_files':len(before),'saved_files_unchanged':before==after==snapshot(),
        'read_exit':read_rc,'read_seconds':read_seconds,'read_selection_calls':read_select.call_count,
        'read_update_calls':update.call_count,'repeat':repeat,'read':read,
        'new_calls':dict(provider=0,paid=0,sec=0)}
Path('work/'+name+'-earnings-repeat-read.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in record.items() if k not in {'repeat','read','command'}})
assert before==after==snapshot() and select.call_count==graph.call_count==read_select.call_count==update.call_count==0
assert all(r['status'] in {'NO_SOURCE_CONTENT_CHANGE','PREVIOUS_INPUT_WITHHELD'} for r in repeat['metrics'])
assert read_rc==0 and len(read['metrics'])==4
