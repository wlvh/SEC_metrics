import hashlib,json,shutil,socket,time
from pathlib import Path
from unittest.mock import patch
from vnext.company_current_records import run_saved_company,read_current_company
from vnext.historical_bank_performance_cases import METRICS,PROCESSING_FILES,prepare_historical_bank_year_case
from vnext.normal_companyfacts_results import NormalCompanyfactsError
base=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence');root=base/'bank-prior-constructed-isolation-20261009';original=base/'bank-performance-jpm-20261009/state'
if root.exists():raise RuntimeError('Control root already exists; preserve it')
(root/'state').mkdir(parents=True);shutil.copyfile(original/'company-task.json',root/'state/company-task.json')
# Copy only the completed FY2021 tiny states; another real year run is independent.
for m in sorted(METRICS):shutil.copytree(original/'updates'/m/'periods/FY2021',root/'state/updates'/m/'periods/FY2021')
source=Path('/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs');prior={'A05','A06','A07'}
args=dict(company_id='jpmorgan_chase',source_root=source,work_dir=root/'state',output_dir=root/'outputs',metric_ids=sorted(METRICS),fiscal_years=[2021],case_factories={m:prepare_historical_bank_year_case for m in METRICS},processing_files_by_metric={m:(*PROCESSING_FILES,'tests/vnext/test_historical_bank_performance_cases.py') if m in prior else PROCESSING_FILES for m in METRICS})
def snap():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'state/updates').rglob('*') if p.is_file() and ('results' in p.parts or p.name=='current-result.json')}
old=snap();start=time.monotonic()
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')):
 with patch('vnext.historical_bank_performance_cases.prior_filing',side_effect=NormalCompanyfactsError('CONSTRUCTED_PRIOR_SOURCE_UNAVAILABLE')):
  held=run_saved_company(**args)
 held_seconds=time.monotonic()-start;before=snap();start=time.monotonic()
 with patch('vnext.historical_bank_performance_cases.resolve_period_selection',side_effect=AssertionError('No stable repeat preparation')) as select:
  repeat=run_saved_company(**args)
 repeat_seconds=time.monotonic()-start;after=snap()
 view=read_current_company(state_root=root/'state',company_id='jpmorgan_chase',output_root=root/'read-exports')
record={'constructed_control':True,'actual_financial_conclusion':False,'held_seconds':held_seconds,'repeat_seconds':repeat_seconds,'held_statuses':{r['metric_id']:r['status'] for r in held['metrics']},'repeat_statuses':{r['metric_id']:r['status'] for r in repeat['metrics']},'repeat_preparation_calls':select.call_count,'saved_files_unchanged':before==after,'old_success_files_retained':all(before.get(k)==v for k,v in old.items()),'read':view,'new_calls':{'provider':0,'paid':0,'sec':0}}
Path('work/bank-prior-isolation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='read'}));print([(r['metric_id'],r['value'],r['publication']) for r in view['metrics']])
assert all(record['held_statuses'][m]=='CANDIDATE_WITHHELD' for m in prior)
assert all(record['held_statuses'][m]=='NO_SOURCE_CONTENT_CHANGE' for m in ['A08','A10'])
assert select.call_count==0 and before==after and record['old_success_files_retained']
assert all(r['value'] is None for r in view['metrics'] if r['metric_id'] in prior)
