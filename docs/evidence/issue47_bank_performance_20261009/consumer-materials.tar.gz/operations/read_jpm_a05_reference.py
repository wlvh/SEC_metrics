import json,time
from decimal import Decimal
from pathlib import Path
from lxml import etree
source=Path('/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs');run=json.loads(Path('work/jpm-performance-2021-first.json').read_text());root=Path(next(m['record_root'] for m in run['metrics'] if m['metric_id']=='A05'));records=[json.loads(l) for l in (root/'records.jsonl').read_text().splitlines()];blobs={r['raw_asset_id']:r for r in records if r['record_type']=='RAW_BLOB'};refs=[r for r in records if r['record_type']=='SOURCE_REFERENCE' and r['source_role']=='target_primary'];out=[];start=time.monotonic()
for ref in refs:
 raw=(source/blobs[ref['raw_asset_id']]['storage_uri']).read_bytes();tree=etree.fromstring(raw,parser=etree.XMLParser(huge_tree=True,resolve_entities=False));contexts={x.get('id'):x for x in tree.xpath('//*[local-name()="context" and namespace-uri()="http://www.xbrl.org/2003/instance"]')};units={x.get('id'):x for x in tree.xpath('//*[local-name()="unit" and namespace-uri()="http://www.xbrl.org/2003/instance"]')};facts=[]
 for node in tree.xpath('//*[local-name()="nonFraction"]'):
  name=node.get('name','');prefix,sep,local=name.partition(':');uri=node.nsmap.get(prefix,'')
  if local not in ['Assets','NetIncomeLoss'] or not uri.startswith('http://fasb.org/us-gaap/'):continue
  c=contexts.get(node.get('contextRef'));u=units.get(node.get('unitRef'))
  if c is None or u is None or c.xpath('.//*[local-name()="explicitMember" or local-name()="typedMember"]'):continue
  identifiers=c.xpath('.//*[local-name()="identifier"]');ends=c.xpath('.//*[local-name()="instant" or local-name()="endDate"]/text()');begins=c.xpath('.//*[local-name()="startDate"]/text()');measures=u.xpath('.//*[local-name()="measure"]')
  if len(identifiers)!=1 or not (identifiers[0].text or '').isdigit() or int(identifiers[0].text)!=19617 or identifiers[0].get('scheme')!='http://www.sec.gov/CIK' or not ends or ends[0] not in ['2020-12-31','2021-12-31'] or len(measures)!=1:continue
  measure=measures[0];mp,_,ml=(measure.text or '').partition(':')
  if ml!='USD' or measure.nsmap.get(mp)!='http://www.xbrl.org/2003/iso4217':continue
  lexical=''.join(node.itertext()).strip();value=Decimal(lexical.replace(',',''))*(Decimal(10)**int(node.get('scale','0')))
  if node.get('sign')=='-':value=-value
  facts.append({'concept':local,'context_ref':node.get('contextRef'),'start':begins[0] if begins else ends[0],'end':ends[0],'instant':not begins,'unit':'USD','lexical':lexical,'format':node.get('format'),'scale':node.get('scale'),'sign':node.get('sign'),'value':format(value,'f'),'source_line':node.sourceline})
 out.append({'source_reference':ref,'facts':facts})
values={Decimal(f['value']) for d in out for f in d['facts']};expected={Decimal(v) for v in ['3743567000000','3386071000000','48334000000']};assert expected<=values
reference=Decimal('48334000000')/((Decimal('3743567000000')+Decimal('3386071000000'))/2)
r={'scope':'FY2021 A05 direct original-filing operands only; not full bank business acceptance','seconds':time.monotonic()-start,'documents':out,'computed_reference':str(reference),'new_calls':{'provider':0,'paid':0,'sec':0},'new_acceptance':False,'harness_corrections':['Old read_statement_facts.NEEDED excludes Assets; missing output not disclosure conclusion','Native CIK zero padding normalized numerically and scheme checked']}
Path('work/jpm-a05-2021-native-reference.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'seconds':r['seconds'],'reference':r['computed_reference'],'documents':len(out),'selected_fact_count':sum(len(d['facts']) for d in out)},ensure_ascii=False));assert str(reference)=='0.01355861265326514473806383999'
