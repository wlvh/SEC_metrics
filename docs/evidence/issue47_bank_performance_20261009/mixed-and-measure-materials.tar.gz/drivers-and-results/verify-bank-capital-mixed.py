import contextlib, hashlib, io, json, socket, time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main

root = Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/capital-jpm-20261009')
source = '/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs'
def snapshot(metrics):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for m in metrics for p in (root/'state/updates'/m).rglob('*')
            if p.is_file() and ('results' in p.parts or p.name == 'current-result.json')}
argv = ['run', '--company', 'jpmorgan_chase', '--period', 'fiscal-years',
        '--fiscal-year-start', '2025', '--fiscal-year-end', '2025',
        '--metric', 'A01', '--metric', 'A02', '--metric', 'A08',
        '--source-root', source, '--work-dir', str(root/'state'),
        '--output-dir', str(root/'outputs')]
before = snapshot(['A01', 'A02']); out = io.StringIO(); start = time.monotonic()
with patch.object(socket.socket, 'connect', side_effect=AssertionError('No network')), \
     patch('vnext.historical_capital_cases.resolve_period_selection', side_effect=AssertionError('No capital preparation')) as capital, \
     patch('vnext.historical_capital_cases.inspect_historical_capital_source', side_effect=AssertionError('No capital calculation')) as capital_calc, \
     contextlib.redirect_stdout(out):
    rc = main(argv)
result = json.loads(out.getvalue()); first_seconds = time.monotonic()-start
after = snapshot(['A01', 'A02']); all_before = snapshot(['A01', 'A02', 'A08'])
again = io.StringIO(); start = time.monotonic()
with patch.object(socket.socket, 'connect', side_effect=AssertionError('No network')), \
     patch('vnext.historical_capital_cases.resolve_period_selection', side_effect=AssertionError('No stable capital preparation')), \
     patch('vnext.historical_bank_performance_cases.resolve_period_selection', side_effect=AssertionError('No stable bank preparation')) as bank, \
     patch('vnext.historical_bank_performance_cases._deterministic_metric_graph', side_effect=AssertionError('No stable bank calculation')) as graph, \
     contextlib.redirect_stdout(again):
    rc_again = main(argv)
repeat = json.loads(again.getvalue()); repeat_seconds = time.monotonic()-start
record = dict(command=argv, first_seconds=first_seconds, repeat_seconds=repeat_seconds,
              exit_code=rc, repeat_exit_code=rc_again, capital_preparation_calls=capital.call_count,
              capital_calculation_calls=capital_calc.call_count, capital_files=len(before),
              capital_files_unchanged=before==after, stable_files_unchanged=all_before==snapshot(['A01', 'A02', 'A08']),
              repeat_bank_preparation_calls=bank.call_count, repeat_bank_graph_calls=graph.call_count,
              result=result, repeat=repeat, new_calls=dict(provider=0,paid=0,sec=0))
Path('work/bank-capital-mixed.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in {'command','result','repeat'}}))
print([(r['metric_id'],r['status']) for r in result['metrics']])
assert rc==rc_again==0 and before==after and record['stable_files_unchanged']
assert capital.call_count==capital_calc.call_count==bank.call_count==graph.call_count==0
assert all(r['status']=='NO_SOURCE_CONTENT_CHANGE' for r in repeat['metrics'])
