"""Constructed guard failure on saved original sources, not a JPM conclusion."""
import json, socket, time
from pathlib import Path
from unittest.mock import patch
from vnext import historical_bank_performance_cases as bank
from vnext.ordinary_saved_result import save_calculated_case, read_saved_result
from vnext.paired_measure_v1 import PAIRED_MEASURE_REASON

source=Path('/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs')
output=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/bank-measure-constructed-receiving-20261009')
real=bank.paired_measure_problem
seen=[]
def disagree(**fields):
    problem,bridge=real(**fields)
    assert problem is None
    seen.append({'accessions':fields['accessions'],'claims':fields['claims'],
                 'real_guard_problem':problem,'real_guard_bridge':bridge})
    return {'reason_code':PAIRED_MEASURE_REASON,
            'constructed_control':True,
            'current':{'concept':'NetIncomeLoss'},'prior':{'concept':'ProfitLoss'},
            'target_filing_reports_the_prior_year_under_the_current_concept':[]},[]
start=time.monotonic()
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')):
    with patch.object(bank,'paired_measure_problem',side_effect=disagree):
        case=bank.prepare_historical_bank_year_case(repo_root=source,
            company_id='jpmorgan_chase',metric_id='A07',fiscal_year=2025)
    prepared_seconds=time.monotonic()-start
    saved=save_calculated_case(source_root=source,output_root=output,
        company_id='jpmorgan_chase',metric_id='A07',case=case)
    read=read_saved_result(output_root=output)
result=case['results']['A07'];assessment=case['selection']
record={'constructed_control':True,'actual_financial_conclusion':False,
        'prepared_seconds':prepared_seconds,'elapsed_seconds':time.monotonic()-start,
        'guard_calls':len(seen),'actual_selected_claims':seen,
        'result':result,'assessment':assessment,'saved':saved,'read':read,
        'new_calls':dict(provider=0,paid=0,sec=0)}
def csv_bytes(value):
    if isinstance(value, bytes):
        return value.decode('utf-8')
    raise TypeError(type(value).__name__)
Path('work/bank-measure-receiving.json').write_text(json.dumps(record,ensure_ascii=False,indent=2,default=csv_bytes)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in {'actual_selected_claims','saved','read'}}))
assert len(seen)==1 and result['publication']=='WITHHELD' and result['value'] is None
assert assessment['category']=='MEASURE_NOT_COMPARABLE'
assert assessment['reason_code']==PAIRED_MEASURE_REASON
assert not any(r['record_type']=='VERIFIED_OBSERVATION' for r in case['expected_records'])
