import hashlib,json,shutil,socket,time
from pathlib import Path
from unittest.mock import patch
from vnext.company_current_records import run_saved_company,read_current_company
from vnext.historical_liquidity_cases import prepare_historical_liquidity_year_case,PROCESSING_FILES
from vnext.deterministic_catalog import ZeroAiReleaseError
base=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence')
root=base/'liquidity-constructed-stable-hold-20261009'
if root.exists():raise RuntimeError('Constructed control root already exists; preserve it')
# Small copied result/state control, never a copied source/program tree.
shutil.copytree(base/'liquidity-macys-final-20261009/state',root/'state')
source=Path('/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs')
args=dict(company_id='macys',source_root=source,work_dir=root/'state',output_dir=root/'outputs',metric_ids=['B08','B09'],fiscal_years=[2023],case_factories={m:prepare_historical_liquidity_year_case for m in ['B08','B09']},processing_files_by_metric={'B08':(*PROCESSING_FILES,'tests/vnext/test_historical_liquidity_cases.py'),'B09':PROCESSING_FILES})
def snapshot():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'state/updates').rglob('*') if p.is_file() and ('results' in p.parts or p.name=='current-result.json')}
old=snapshot();start=time.monotonic()
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')):
 with patch('vnext.historical_liquidity_cases._deterministic_metric_graph',side_effect=ZeroAiReleaseError('CONSTRUCTED_CHANGED_PROCESSING_GAP')):
  held=run_saved_company(**args)
 after_hold=snapshot();held_seconds=time.monotonic()-start;start=time.monotonic()
 with patch('vnext.historical_liquidity_cases.resolve_period_selection',side_effect=AssertionError('No repeat selection')) as select:
  repeated=run_saved_company(**args)
 repeat_seconds=time.monotonic()-start;after_repeat=snapshot()
 subset=run_saved_company(**{**args,'metric_ids':['B09'],'case_factories':{'B09':prepare_historical_liquidity_year_case},'processing_files_by_metric':{'B09':PROCESSING_FILES}})
 with patch('vnext.company_current_records.run_once',side_effect=AssertionError('No read update')):
  read=read_current_company(state_root=root/'state',company_id='macys',output_root=root/'read-exports')
rows={m['metric_id']:m for m in read['metrics']}
record={'constructed_control':True,'actual_financial_conclusion':False,'source_backed_small_state_copy':True,'hold_seconds':held_seconds,'repeat_seconds':repeat_seconds,'hold_statuses':{m['metric_id']:m['status'] for m in held['metrics']},'repeat_statuses':{m['metric_id']:m['status'] for m in repeated['metrics']},'repeat_selection_calls':select.call_count,'saved_files_unchanged_on_repeat':after_hold==after_repeat,'old_result_files_retained':all(after_hold.get(k)==v for k,v in old.items()),'read':read,'new_calls':{'provider':0,'paid':0,'sec':0}}
Path('work/liquidity-withheld-state.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='read'}));print([(m,r['value'],r['publication'],r['requested_in_latest_execution']) for m,r in rows.items()])
assert record['hold_statuses']=={'B08':'CANDIDATE_WITHHELD','B09':'NO_SOURCE_CONTENT_CHANGE'}
assert record['repeat_statuses']=={'B08':'PREVIOUS_INPUT_WITHHELD','B09':'NO_SOURCE_CONTENT_CHANGE'}
assert select.call_count==0 and after_hold==after_repeat and record['old_result_files_retained']
assert rows['B08']['value'] is None and rows['B08']['publication']=='WITHHELD' and not rows['B08']['requested_in_latest_execution']
assert rows['B09']['value']=='1034000000'
