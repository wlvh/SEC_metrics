import contextlib,hashlib,io,json,socket,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/statement-pilot-macys-20261009')
def snap():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'state/updates/B04').rglob('*') if p.is_file() and ('results' in p.parts or p.name=='current-result.json')}
before=snap();out=io.StringIO();start=time.monotonic()
args=['run','--company','macys','--period','fiscal-years','--fiscal-year-start','2023','--fiscal-year-end','2023','--metric','B04','--metric','B08','--metric','B09','--source-root','/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs','--work-dir',str(root/'state'),'--output-dir',str(root/'outputs')]
with patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('No statement recalculation')) as old,patch.object(socket.socket,'connect',side_effect=AssertionError('No network')),contextlib.redirect_stdout(out):
 rc=main(args)
d=json.loads(out.getvalue());after=snap();record={'exit_code':rc,'seconds':time.monotonic()-start,'old_statement_selection_calls':old.call_count,'old_statement_files_unchanged':before==after,'old_statement_files':len(before),'result':d,'command':args}
Path('work/liquidity-mixed.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['result','command']}));print([(m['metric_id'],m['status']) for m in d['metrics']])
assert rc==0 and old.call_count==0 and before==after
assert {m['metric_id']:m['status'] for m in d['metrics']}=={'B04':'NO_SOURCE_CONTENT_CHANGE','B08':'CANDIDATE_READY','B09':'CANDIDATE_READY'}
