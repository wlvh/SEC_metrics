import contextlib, io, json, socket, sys, time
from unittest.mock import patch
from tools.vnext_company import main
with patch.object(socket.socket,'connect',side_effect=AssertionError('UNEXPECTED_NETWORK')):
    raise SystemExit(main(sys.argv[1:]))
