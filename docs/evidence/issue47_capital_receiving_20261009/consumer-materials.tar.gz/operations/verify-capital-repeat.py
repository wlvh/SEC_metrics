import argparse, contextlib, hashlib, io, json, socket, time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main

p=argparse.ArgumentParser()
p.add_argument('--company',required=True);p.add_argument('--start',type=int,required=True);p.add_argument('--end',type=int,required=True);p.add_argument('--task',type=Path,required=True);p.add_argument('--source',required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
def snapshot():
    root=a.task/'state'/'updates'
    return {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file() and ('results' in f.parts or f.name=='current-result.json')}
before=snapshot();out=io.StringIO();beg=time.monotonic()
argv=['run','--company',a.company,'--period','fiscal-years','--fiscal-year-start',str(a.start),'--fiscal-year-end',str(a.end),'--source-root',a.source,'--work-dir',str(a.task/'state'),'--output-dir',str(a.task/'outputs')]
for metric in ['A01','A02']:argv.extend(['--metric',metric])
with patch('vnext.historical_capital_cases.resolve_period_selection',side_effect=AssertionError('UNEXPECTED_SOURCE_SELECTION')) as select, patch('vnext.historical_capital_cases.inspect_historical_capital_source',side_effect=AssertionError('UNEXPECTED_CALCULATION')) as graph, patch('vnext.historical_capital_cases.calculate_observation_metric',side_effect=AssertionError('UNEXPECTED_CALCULATION')) as calc, patch.object(socket.socket,'connect',side_effect=AssertionError('UNEXPECTED_NETWORK')), contextlib.redirect_stdout(out):
    rc=main(argv)
result=json.loads(out.getvalue());after=snapshot()
a.output.write_text(json.dumps({'exit_code':rc,'elapsed_seconds':time.monotonic()-beg,'selection_calls':select.call_count,'calculation_calls':graph.call_count+calc.call_count,'saved_file_count':len(before),'saved_files_unchanged':before==after,'command':argv,'result':result},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':rc,'status':result['status'],'statuses':sorted(set(m['status'] for m in result['metrics'])),'calculation_calls':graph.call_count+calc.call_count,'saved_file_count':len(before),'saved_files_unchanged':before==after,'elapsed_seconds':time.monotonic()-beg}))
assert rc==0 and before==after and select.call_count==graph.call_count==calc.call_count==0
assert all(m['status']=='NO_SOURCE_CONTENT_CHANGE' and not m['calculation_performed'] for m in result['metrics'])
