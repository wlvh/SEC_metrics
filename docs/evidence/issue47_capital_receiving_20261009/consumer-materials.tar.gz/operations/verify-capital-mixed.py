import contextlib,hashlib,io,json,socket,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/capital-jpm-20261009')
def snap():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for m in ['A01','A02'] for p in (root/'state/updates'/m).rglob('*') if p.is_file() and ('results' in p.parts or p.name=='current-result.json')}
before=snap();out=io.StringIO();beg=time.monotonic();args=['run','--company','jpmorgan_chase','--period','fiscal-years','--fiscal-year-start','2025','--fiscal-year-end','2025','--metric','A01','--metric','A02','--metric','B08','--source-root','/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs','--work-dir',str(root/'state'),'--output-dir',str(root/'outputs')]
with patch('vnext.historical_capital_cases.resolve_period_selection',side_effect=AssertionError('No repeated capital preparation')) as selector,patch.object(socket.socket,'connect',side_effect=AssertionError('No network')),contextlib.redirect_stdout(out):rc=main(args)
d=json.loads(out.getvalue());after=snap();r={'seconds':time.monotonic()-beg,'exit_code':rc,'capital_selection_calls':selector.call_count,'capital_files_unchanged':before==after,'capital_files':len(before),'command':args,'result':d}
Path('work/capital-mixed.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['result','command']}));print([(m['metric_id'],m['status']) for m in d['metrics']]);assert rc==0 and before==after and selector.call_count==0
