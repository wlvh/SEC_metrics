import hashlib,json,shutil,socket,time
from pathlib import Path
from unittest.mock import patch
from vnext.company_current_records import run_saved_company,read_current_company
from vnext.historical_capital_cases import prepare_historical_capital_year_case,PROCESSING_FILES
base=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence');root=base/'capital-constructed-hold-20261009'
if root.exists():raise RuntimeError('Control root already exists; preserve it')
shutil.copytree(base/'capital-jpm-20261009/state',root/'state')
source=Path('/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs')
args=dict(company_id='jpmorgan_chase',source_root=source,work_dir=root/'state',output_dir=root/'outputs',metric_ids=['A01','A02'],fiscal_years=[2025],case_factories={m:prepare_historical_capital_year_case for m in ['A01','A02']},processing_files_by_metric={'A01':(*PROCESSING_FILES,'tests/vnext/test_historical_capital_cases.py'),'A02':PROCESSING_FILES})
def snap():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'state/updates').rglob('*') if p.is_file() and ('results' in p.parts or p.name=='current-result.json')}
old=snap();start=time.monotonic()
# Constructed source-scope rejection; the original reports are not labelled wrong.
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')):
 with patch('vnext.historical_capital_cases.inspect_historical_capital_source',return_value=({'status':'UNRESOLVED','conflicts':[{'reason':'CONSTRUCTED_SCOPE_CONFLICT'}],'selected_claims':[]},{})):
  held=run_saved_company(**args)
 held_seconds=time.monotonic()-start;before=snap();start=time.monotonic()
 with patch('vnext.historical_capital_cases.resolve_period_selection',side_effect=AssertionError('No stable repeat preparation')) as select:
  repeated=run_saved_company(**args)
 repeat_seconds=time.monotonic()-start;after=snap()
 subset=run_saved_company(**{**args,'metric_ids':['A02'],'case_factories':{'A02':prepare_historical_capital_year_case},'processing_files_by_metric':{'A02':PROCESSING_FILES}})
 with patch('vnext.company_current_records.run_once',side_effect=AssertionError('No read update')):
  view=read_current_company(state_root=root/'state',company_id='jpmorgan_chase',output_root=root/'read-exports')
 rows={r['metric_id']:r for r in view['metrics'] if r['fiscal_year']==2025}
record={'constructed_control':True,'actual_financial_conclusion':False,'copied_small_state_not_sources_or_program':True,'held_seconds':held_seconds,'repeat_seconds':repeat_seconds,'held_statuses':{r['metric_id']:r['status'] for r in held['metrics']},'repeat_statuses':{r['metric_id']:r['status'] for r in repeated['metrics']},'repeat_preparation_calls':select.call_count,'saved_files_unchanged':before==after,'old_success_files_retained':all(before.get(k)==v for k,v in old.items()),'read':view,'new_calls':{'provider':0,'paid':0,'sec':0}}
Path('work/capital-held-control.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='read'}));print([(m,r['value'],r['publication'],r['requested_in_latest_execution']) for m,r in rows.items()])
assert record['held_statuses']=={'A01':'CANDIDATE_WITHHELD','A02':'NO_SOURCE_CONTENT_CHANGE'}
assert record['repeat_statuses']=={'A01':'PREVIOUS_INPUT_WITHHELD','A02':'NO_SOURCE_CONTENT_CHANGE'} and select.call_count==0 and before==after and record['old_success_files_retained']
assert rows['A01']['value'] is None and rows['A01']['publication']=='WITHHELD' and not rows['A01']['requested_in_latest_execution'] and rows['A02']['value']=='0.146'
