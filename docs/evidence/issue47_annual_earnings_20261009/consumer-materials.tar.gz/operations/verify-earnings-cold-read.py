import contextlib,hashlib,io,json,socket,sys,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
company,name=sys.argv[1:3]
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence')/('annual-earnings-'+name+'-20261009')
def snapshot():
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (root/'state/updates').rglob('*') if p.is_file()
            and ('results' in p.parts or p.name=='current-result.json')}
before=snapshot();out=io.StringIO();start=time.monotonic()
args=['results','--company',company,'--state-root',str(root/'state'),
      '--output-root',str(root/'cold-read')]
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')), \
     patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('No cold selection')) as select, \
     patch('vnext.company_current_records.run_once',side_effect=AssertionError('No cold update')) as update, \
     contextlib.redirect_stdout(out):
    rc=main(args)
record={'exit_code':rc,'seconds':time.monotonic()-start,'source_selection_calls':select.call_count,
        'update_calls':update.call_count,'saved_files_unchanged':before==snapshot(),
        'saved_file_count':len(before),'command':args,'result':json.loads(out.getvalue()),
        'new_calls':dict(provider=0,paid=0,sec=0)}
Path('work/'+name+'-earnings-cold-read.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in record.items() if k not in {'command','result'}})
assert rc==0 and select.call_count==update.call_count==0 and before==snapshot()
assert len(record['result']['metrics'])==5
