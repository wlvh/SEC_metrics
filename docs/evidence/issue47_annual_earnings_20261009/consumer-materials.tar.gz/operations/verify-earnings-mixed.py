import contextlib,hashlib,io,json,socket,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
from vnext import historical_statement_cases as cases
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/annual-earnings-macys-20261009')
source='/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs'
def snapshot():
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (root/'state/updates/B07').rglob('*') if p.is_file()
            and ('results' in p.parts or p.name=='current-result.json')}
seen=[];original=cases._prepare_historical_statement_case
def allow_new_metrics(**kwargs):
    seen.append(kwargs['metric_id'])
    assert kwargs['metric_id']!='B07','Unexpected repeated B07 preparation'
    return original(**kwargs)
before=snapshot();out=io.StringIO();start=time.monotonic()
args=['run','--company','macys','--period','fiscal-years','--fiscal-year-start','2023',
      '--fiscal-year-end','2023','--metric','B04','--metric','B05','--metric','B07',
      '--source-root',source,'--work-dir',str(root/'state'),'--output-dir',str(root/'outputs')]
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')), \
     patch.object(cases,'_prepare_historical_statement_case',side_effect=allow_new_metrics), \
     contextlib.redirect_stdout(out):
    rc=main(args)
d=json.loads(out.getvalue());record={'seconds':time.monotonic()-start,'exit_code':rc,
    'prepared_metrics':seen,'old_B07_files':len(before),'old_B07_files_unchanged':before==snapshot(),
    'command':args,'result':d,'new_calls':dict(provider=0,paid=0,sec=0)}
Path('work/annual-earnings-mixed.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in record.items() if k not in {'command','result'}})
print([(r['metric_id'],r['status']) for r in d['metrics']])
assert rc==0 and sorted(seen)==['B04','B05'] and before==snapshot()
