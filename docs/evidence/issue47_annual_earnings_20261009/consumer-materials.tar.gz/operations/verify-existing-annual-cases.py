"""Compare two affected existing producers, not whole pilot replay."""
import importlib.util,json,socket,subprocess,time,types
from pathlib import Path
from unittest.mock import patch
from vnext import historical_statement_cases as received

source=Path('/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs')
old=types.ModuleType('vnext.original_statement_receiving')
old.__package__='vnext'
old.__file__='git:7b6803c6:scripts/vnext/historical_statement_cases.py'
text=subprocess.check_output(['git','show','7b6803c6:scripts/vnext/historical_statement_cases.py'],text=True)
exec(compile(text,old.__file__,'exec'),old.__dict__)
checks=[];start=time.monotonic()
with patch.object(socket.socket,'connect',side_effect=AssertionError('No network')):
    for company,metric,year in [('macys','B04',2023),('lumen_technologies','B05',2023)]:
        args=dict(repo_root=source,company_id=company,metric_id=metric,fiscal_year=year)
        before=old.prepare_historical_statement_year_case(**args)
        after=received.prepare_historical_statement_year_case(**args)
        shared=received.prepare_historical_current_annual_year_case(**args)
        same=before==after==shared
        checks.append(dict(company=company,metric=metric,year=year,entire_case_equal=same,
            result=after['results'][metric],trace_id=after['traces'][metric]['trace_id']))
        assert same
record=dict(seconds=time.monotonic()-start,checks=checks,new_calls=dict(provider=0,paid=0,sec=0),
    all_pilot_replayed=False,new_business_acceptance=False)
Path('work/existing-annual-case-comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print({'seconds':record['seconds'],'two_entire_cases_equal':all(c['entire_case_equal'] for c in checks)})
