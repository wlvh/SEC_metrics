import contextlib,hashlib,io,json,socket,sys,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
company,name=sys.argv[1:3]
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence')/('statement-pilot-'+name+'-20261009')
def snap():
 return {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'state/updates').rglob('*') if f.is_file() and ('results' in f.parts or f.name=='current-result.json')}
before=snap();out=io.StringIO();start=time.monotonic();args=['results','--company',company,'--state-root',str(root/'state'),'--output-root',str(root/'guarded-read-exports')]
with patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('UNEXPECTED_SELECTION')) as select,patch('vnext.company_current_records.run_once',side_effect=AssertionError('UNEXPECTED_UPDATE')) as update,patch.object(socket.socket,'connect',side_effect=AssertionError('UNEXPECTED_NETWORK')),contextlib.redirect_stdout(out):
 rc=main(args)
d=json.loads(out.getvalue());after=snap();r={'elapsed_seconds':time.monotonic()-start,'exit_code':rc,'selection_calls':select.call_count,'update_calls':update.call_count,'saved_file_count':len(before),'saved_files_unchanged':before==after,'command':args,'result':d}
Path('work/'+name+'-pilot-read-guarded.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:r[k] for k in r if k not in ['result','command']}));assert rc==0 and before==after and select.call_count==update.call_count==0 and len(d['metrics'])==20
