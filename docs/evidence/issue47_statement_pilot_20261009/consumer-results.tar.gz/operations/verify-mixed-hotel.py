import contextlib,hashlib,io,json,socket,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/history-company-production-20261008')
source=json.loads((root/'state/company-task.json').read_text())['source_root']
def snapshot():
 return {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for metric in ['B10','B11'] for f in (root/'state/updates'/metric).rglob('*') if f.is_file() and ('results' in f.parts or f.name=='current-result.json')}
before=snapshot();out=io.StringIO();start=time.monotonic()
args=['run','--company','marriott_international','--period','fiscal-years','--fiscal-year-start','2024','--fiscal-year-end','2024','--source-root',source,'--work-dir',str(root/'state'),'--output-dir',str(root/'outputs'),'--metric','B04','--metric','B10','--metric','B11']
# The original callable remains installed. Only its selection/calculation dependencies are forbidden.
with patch('vnext.historical_lodging_results.prepare_historical_annual_input',side_effect=AssertionError('UNEXPECTED_HOTEL_PREPARATION')) as hotel,patch.object(socket.socket,'connect',side_effect=AssertionError('UNEXPECTED_NETWORK')),contextlib.redirect_stdout(out):
 rc=main(args)
d=json.loads(out.getvalue());after=snapshot();record={'elapsed_seconds':time.monotonic()-start,'exit_code':rc,'hotel_preparation_calls':hotel.call_count,'hotel_files_unchanged':before==after,'hotel_saved_file_count':len(before),'command':args,'result':d}
Path('work/mixed-hotel-statement.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k] for k in record if k!='result'}));print([(m['metric_id'],m['status'],m.get('reason')) for m in d['metrics']])
assert rc==0 and before==after and hotel.call_count==0
assert all(m['status']=='NO_SOURCE_CONTENT_CHANGE' for m in d['metrics'] if m['metric_id'] in ['B10','B11'])
