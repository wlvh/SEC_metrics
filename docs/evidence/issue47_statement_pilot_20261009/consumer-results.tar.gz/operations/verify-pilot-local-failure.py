import contextlib,hashlib,io,json,socket,time
from pathlib import Path
from unittest.mock import patch
from tools.vnext_company import main
from vnext.normal_companyfacts_results import NormalCompanyfactsError
root=Path('/Users/lyuhongwang/.local/state/sec_metrics/issue47-development-evidence/statement-pilot-constructed-prior-control-20261009')
args=['run','--company','macys','--period','fiscal-years','--fiscal-year-start','2023','--fiscal-year-end','2023','--source-root','/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-company-verified-source-20261006/source-inputs','--work-dir',str(root/'state'),'--output-dir',str(root/'outputs'),'--metric','B02','--metric','B04','--metric','B05']
def invoke(args):
 out=io.StringIO();start=time.monotonic()
 with contextlib.redirect_stdout(out):rc=main(args)
 return {'exit_code':rc,'elapsed_seconds':time.monotonic()-start,'result':json.loads(out.getvalue())}
def snap():
 return {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'state/updates').rglob('*') if f.is_file() and ('results' in f.parts or f.name=='current-result.json')}
with patch.object(socket.socket,'connect',side_effect=AssertionError('UNEXPECTED_NETWORK')):
 with patch('vnext.historical_statement_cases.prior_filing',side_effect=NormalCompanyfactsError('CONSTRUCTED_PRIOR_SOURCE_MISSING')):
  first=invoke(args)
 before=snap()
 with patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('UNEXPECTED_PREPARATION')) as select:
  repeat=invoke(args)
 after=snap()
 with patch('vnext.historical_statement_cases.resolve_period_selection',side_effect=AssertionError('UNEXPECTED_READ_PREPARATION')):
  read=invoke(['results','--company','macys','--state-root',str(root/'state'),'--output-root',str(root/'read-exports')])
record={'constructed_control':True,'description':'Artificial missing prior input; not an actual Macy disclosure conclusion','first':first,'repeat':repeat,'read':read,'repeat_preparation_calls':select.call_count,'saved_files_unchanged':before==after,'saved_file_count':len(before),'command':args}
Path('work/pilot-local-failure.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print([(m['metric_id'],m['status']) for m in first['result']['metrics']]);print([(m['metric_id'],m['status']) for m in repeat['result']['metrics']]);print([(m['metric_id'],m['value'],m['publication']) for m in read['result']['metrics']])
assert first['result']['metrics'][0]['status']=='CANDIDATE_WITHHELD'
assert repeat['result']['metrics'][0]['status']=='PREVIOUS_INPUT_WITHHELD'
assert select.call_count==0 and before==after
assert all(m['status']=='NO_SOURCE_CONTENT_CHANGE' for m in repeat['result']['metrics'][1:])
assert [(m['metric_id'],m['value']) for m in read['result']['metrics']]==[('B02',None),('B04','105000000'),('B05','674000000')]
