"""Read native normal source selection after an already frozen reference.

Development read only. No answer, review, Run, model or SEC transport.
"""
import argparse,datetime,hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
p=argparse.ArgumentParser()
for name in ('current-root','code-root','source-root','reference','freeze','out'):p.add_argument('--'+name,type=Path,required=True)
p.add_argument('--company',required=True);p.add_argument('--report-end',required=True)
a=p.parse_args();sha=lambda b:hashlib.sha256(b).hexdigest()
f=json.loads(a.freeze.read_bytes());expected=f['files'][a.reference.name];assert sha(a.reference.read_bytes())==expected
reference=json.loads(a.reference.read_bytes());assert reference['position']==a.company+':'+a.report_end
names=['historical_text_input.py','historical_text_results.py','historical_board_composition.py','historical_board_composition_v2.py','historical_board_composition_v3.py','historical_proxy_identity.py','historical_legal_review.py'];checks=[]
for name in names:
 current=(a.current_root/'scripts/vnext'/name).read_bytes();code=(a.code_root/'scripts/vnext'/name).read_bytes();assert current==code;checks.append({'module':name,'sha256':sha(code),'same':True})
sys.path.insert(0,str(a.code_root/'scripts'))
from vnext.normal_history_plan import checkpoint_replayed_once
from vnext.normal_period_selection import resolve_period_selection
from vnext.historical_text_input import prepare_historical_business_text_input
from vnext.historical_text_results import prepare_business_text_sources
with patch('socket.socket',side_effect=AssertionError('NO_NETWORK')),checkpoint_replayed_once():
 selection=resolve_period_selection(repo_root=a.source_root,company_id=a.company,report_end=a.report_end)
 admitted=prepare_historical_business_text_input(repo_root=a.source_root,company_id=a.company,metric_id='C02',period_selection=selection,_without_reviews=True)
 assert admitted['text_arguments'] is not None
 result=prepare_business_text_sources(metric_id='C02',**admitted['text_arguments'])
a.out.mkdir(exist_ok=False)
raw=(json.dumps(result,ensure_ascii=False,indent=1)+'\n').encode();(a.out/'current-selector.json').write_bytes(raw)
summary=[]
for sid,proposal in result['proposals'].items():
 doc=result['documents'][sid];assert doc['raw_asset_id']==reference['raw_asset_id']
 for c in proposal['candidates']:
  b=doc['blocks'][c['block_index']];assert c['text']==b['text']
  for key in ('raw_start_byte','raw_end_byte','raw_span_sha256'):assert c[key]==b[key]
 summary.append({'source_reference_id':sid,'raw_asset_id':doc['raw_asset_id'],'candidate_count':len(proposal['candidates']),'candidate_blocks':[c['block_index'] for c in proposal['candidates']]})
receipt={'reference_sha256':expected,'original_freeze_receipt_sha256':sha(a.freeze.read_bytes()),'selector_read_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selector_sha256':sha(raw),'code_byte_checks':checks,'current_candidates_match_original_text_and_raw_spans':True,'source_selection_modified':False,'native_run_or_result_compared':False,'calls':[0,0,0],'new_runs':0,'new_acceptances':0,'proposals':summary}
(a.out/'selector-after-reference.json').write_text(json.dumps(receipt,indent=1)+'\n');print(json.dumps(receipt),flush=True)
