import sys,json,hashlib,datetime
from pathlib import Path
current=Path("/Users/lyuhongwang/.codex/worktrees/7e99/SEC_metrics-issue47-local")
clone=current.parent/"SEC_metrics-issue47-runtime-20261004"
files=["historical_text_input.py","historical_text_results.py","historical_board_composition.py","historical_board_composition_v2.py","historical_board_composition_v3.py","historical_proxy_identity.py","historical_legal_review.py"]
checks=[]
for name in files:
 a=(current/"scripts/vnext"/name).read_bytes();b=(clone/"scripts/vnext"/name).read_bytes();assert a==b;checks.append({"module":name,"sha256":hashlib.sha256(a).hexdigest(),"same":True})
ref=current/"work/lumen2022-c02-executor-reference.json";f=json.loads((current/"work/lumen2022-c02-reference-frozen.json").read_text());assert hashlib.sha256(ref.read_bytes()).hexdigest()==f["reference_sha256"]
sys.path.insert(0,str(clone/"scripts"))
from vnext.normal_history_plan import checkpoint_replayed_once
from vnext.normal_period_selection import resolve_period_selection
from vnext.historical_text_input import prepare_historical_business_text_input
from vnext.historical_text_results import prepare_business_text_sources
with checkpoint_replayed_once():
 source_root=current.parent/"SEC_metrics-issue47-external-source-20261004/source-inputs"
 selection=resolve_period_selection(repo_root=source_root,company_id="lumen_technologies",report_end="2022-12-31")
 prepared=prepare_historical_business_text_input(repo_root=source_root,company_id="lumen_technologies",metric_id="C02",period_selection=selection,_without_reviews=True)
 result=prepare_business_text_sources(metric_id="C02",**prepared["text_arguments"])
path=current/"work/lumen2022-c02-current-selector.json";path.write_text(json.dumps(result,ensure_ascii=False,indent=1)+"\n")
receipt={"reference_sha256":f["reference_sha256"],"reference_frozen_at_utc":f["frozen_at_utc"],"selector_read_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"selector_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"code_byte_checks":checks,"calls":[0,0,0],"new_runs":0,"new_acceptances":0}
(current/"work/lumen2022-c02-selector-after-freeze.json").write_text(json.dumps(receipt,indent=2)+"\n")
for sid,proposal in result["proposals"].items():
 print("proposal",list(proposal));print(json.dumps(proposal,ensure_ascii=False,indent=1))
