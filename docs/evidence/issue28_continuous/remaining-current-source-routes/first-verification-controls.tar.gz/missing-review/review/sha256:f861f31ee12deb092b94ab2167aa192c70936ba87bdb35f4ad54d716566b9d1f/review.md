# Source excerpt review

These are the registrant's source disclosures, not assertions that the risks occurred.

Method: RISK\_FACTOR\_HEADINGS\_V1
Spec: sha256:2cf616ccdb70214edf453184505f984279be5cfa9fd0b966993eeb70b767b400
Evidence: sha256:33f8566fde0aeb0fc458a053c3e969ec0be84546b9ef15685a5ec4549a39e284

- excerpt\_0: Risks Relating to Our Industry
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 423629–423659; SHA256 dcc3056d8bd47ca0ebe0573e8c74d4af134e3a55c90542427c802d00853635a8

- excerpt\_1: Our industry is highly competitive, which may impact our ability to compete successfully for guests
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 423849–423948; SHA256 17bbcc68ea906a630b7416e1ee5f27bffba384a68925daf8dea26c8ff847a1b4

- excerpt\_2: Economic and other global, national, and regional conditions and events have in the past materially impacted, and could in the future materially impact, our business, operations, financial results, and growth
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 425580–425788; SHA256 08d66c616c0cd0aaaa610bfef9a31357cc8bd78d5c03122ef5e11f6f6c4e01fe

- excerpt\_3: Risks Relating to Our Business
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 432587–432617; SHA256 0054f721713a7a57f1acfe6e4c99a81823dcd87f6e736cc713085c1475108d58

- excerpt\_4: Premature termination of our agreements with hotel owners could materially hurt our financial performance
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 433022–433127; SHA256 3edee5180b9f193e59ed9704a3283f9e5a5d36cd3449ac7ce9c6b58e12d119a2

- excerpt\_5: Disagreements with hotel owners and other counterparties could materially impact our business, operations, financial results, and growth\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 436048–436185; SHA256 d51635e1427d34928d23d817f24813f2faff745539b66b74d46d43029f8913b8

- excerpt\_6: Changes in the way hotel rooms are booked could adversely impact our business
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 437537–437614; SHA256 2466b81260e65502c909d702f83ec5a867631832561e85489608e6496db5846d

- excerpt\_7: Our growth strategy depends upon attracting hotel owners to our platform, and future arrangements with these third parties may be less favorable to us, depending on the terms offered by our competitors
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 440132–440333; SHA256 690f3e34cec6863c64e5eb6ada1dd481ca3831ee70274044f91da3c5b01705d9

- excerpt\_8: The effects of, or our failure to comply with, applicable laws, regulations, and government policies may disrupt our business, lower our revenues, increase our costs, reduce our profits, limit our growth, or damage our reputation\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 441469–441700; SHA256 f05f97815828f911bc5ecb12eff634fa16deb607a0326bdd0b6b4eae7f6f7c83

- excerpt\_9: Third-party claims that we infringe the intellectual property rights of others or our failure to defend our own intellectual property rights could materially adversely affect our business\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 445128–445435; SHA256 3135a037e4ed899f8f169b63d577f93b1514ef7cdea5cbe7d156cdc150d441af

- excerpt\_10: If our brands, goodwill, or other intangible assets become impaired, we may be required to record significant non-cash charges to earnings\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 449363–449503; SHA256 1bb3c6ecfafed69da817211eb8b6b407fffaa6ba90fc43b243eb6da02e206837

- excerpt\_11: Our business depends on the quality and reputation of our Company and our brands, and any deterioration could adversely impact our market share, reputation, business, financial condition, or results of operations
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 450738–450950; SHA256 87b7027586769a7a43bf0009bc22cb967e1ddce372c4ac28be4ba8fb2a98bea6

- excerpt\_12: Actions by our hotel owners or others could materially adversely affect our image and reputation
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 453294–453390; SHA256 cf563fcab18bc95087d59d7d1806fd049889b4524b629e5df6cce25fe001359e

- excerpt\_13: Collective bargaining activity and strikes could materially disrupt hotel operations, increase labor costs, and interfere with the ability of our management to focus on executing our business strategies
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 456568–456770; SHA256 6026f85ce052edca8e43b0547bebd1c7bab9ca4c687b1c7e3e93f418438049de

- excerpt\_14: Our business could suffer if we or the hotels in our system cannot attract and retain associates or as the result of the loss of the services of our senior executives
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 459475–459641; SHA256 62d4b186ac3e8de130e0bf2b858c69b961f781bfadd06e5851b8662bf3c6c99b

- excerpt\_15: Extreme weather, natural disasters, climate change, and sustainability-related concerns have impacted our business in the past and could in the future have a material adverse effect on our business and results of operations\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 461357–461701; SHA256 0de8b8501fd0e1ea48fc85c8a6588a3bf0e9292d79dc27ecc6900a1b0a91ceef

- excerpt\_16: Insurance may not cover damage to, or losses involving, hotels in our system or other aspects of our business, and the cost of such insurance could increase
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 465071–465227; SHA256 c26628f73980544ff83b14f29b179c4001ba747fb1a7321a72958837138a6b24

- excerpt\_17: Our Loyalty Program plays a significant role in our business, and unfavorable developments affecting the program could adversely affect our business and results of operations\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 467223–467399; SHA256 6b383bd4e7447ac19635108b9e409e9cb4cb1d535e4c3e40582a6f56bba916eb

- excerpt\_18: Exchange rate fluctuations could result in significant foreign currency gains and losses and affect our business results
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 469054–469174; SHA256 4629bcc85d877abda6c69fea4f5ce31beca225cdcc5cfca80903e8965c9392d7

- excerpt\_19: Our hotel owners depend on capital to buy, develop, and improve hotels, and they may be unable to access capital when necessary
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 471042–471169; SHA256 d86237f960bc334c48fc5a68f73eb13acb9b270ba7b4134db21bb343f82252d3

- excerpt\_20: Our ability to grow our system is subject to the range of risks associated with real estate investments
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 471982–472085; SHA256 8f7b681dc18966253778d3ef131d4345d82833026b5f7c9717af4bf9233d297d

- excerpt\_21: Our owned properties and other real estate investments subject us to numerous risks
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 474331–474414; SHA256 223b5ff0b914f41786a6d695b3a4c036ae35026b5a3ef1991e669ce029e20c12

- excerpt\_22: Risks associated with development and sale of residential properties associated with our lodging properties or brands may reduce our profits
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 476150–476290; SHA256 d0cbbb14748a69a32c2458b1eab7e7edbb21e73de603d75ffe78ea1756d94f44

- excerpt\_23: More hotel projects in our development pipeline may be cancelled or delayed in opening, which could adversely affect our growth prospects
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 477385–477522; SHA256 874479f21ce6749b6af09866b47d54360c4442e46ba5251d51ee179a16eb4619

- excerpt\_24: Losses on loans or guarantees that we have made to third parties impact our profits
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 478658–478741; SHA256 4ad3d137e5d5e1a0d5c967bef5e02ffcfa171cba091814a21e5fa133602c8290

- excerpt\_25: If hotel owners cannot repay or refinance mortgage loans secured by their properties, default under property leases, or experience other financial difficulties, our revenues and profits could materially decrease and our business could be significantly harmed
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 479417–479675; SHA256 e6f4d230a0ffca5f902b164f521162c60c908824234d8d9ea071d1c81d3b7c82

- excerpt\_26: Disruption in the functioning of our reservation, Loyalty Program, or other core operational systems, or our use of certain new technologies, could adversely affect our business
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 481396–481573; SHA256 a733e9b0b7d65654c7493f61db5f3ab09d19c1e64fa18e63e34e7d557d1d73d2

- excerpt\_27: A failure to keep pace with developments in technology could impair our operations or competitive position
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 485268–485374; SHA256 367520b5376cfaecce5dede8652fb918103b54ca19f0af4552726e62345db085

- excerpt\_28: We are exposed to risks and costs associated with protecting the integrity and security of data
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 487191–487286; SHA256 96da2058f8067086a31c052ad983cdce978610ddbdbf9d6e4703414bbd41263c

- excerpt\_29: The Data Security Incident, and other information security incidents, could have numerous adverse effects on our business
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 489540–489661; SHA256 a55eff13733dcbef2b2898a5a251196af86ad2a7e8ea226f1c4cb857117fddd8

- excerpt\_30: Additional cybersecurity incidents could have adverse effects on our business\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 493537–493615; SHA256 e8fcf3db508461602f51192632904f8897a23b2defb3ae8ada159698b7d1ca52

- excerpt\_31: Changes in privacy and data security laws could increase our operating costs and increase our exposure to payment obligations and litigation\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 499258–499518; SHA256 1f6683cca9c285315955e76e1fc6215341d2902cb78bf4660975ee39b6730bbb

- excerpt\_32: Delaware law and our governing corporate documents contain, and our Board of Directors could implement, anti-takeover provisions that could deter takeover attempts\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 502930–503095; SHA256 e5383fc645a9d7abc426876f18a4110dd148d6c7c08db2b80fffb090b52aded1

- excerpt\_33: Changes in tax law, interpretations of existing tax law, or agreements or disputes with tax authorities could increase our tax costs\.
  Source sha256:40127921b5837f721fb7ec41028d9eeeefb0855d09261b0fef4a1985f5298d4b; bytes 503973–504107; SHA256 897b610adca09f1e746415592bdcc978d084574970066278b9add7f4cf3538c9

## Complete source set

- https://www\.sec\.gov/Archives/edgar/data/1048286/000104828626000007/mar-20251231\.htm — sha256:c372495ac4ad3e62399040675f490315db137e17cd9a9a4a8c10cb1d09312547

Competing claims: \[\]
Unresolved claims: \[\]
