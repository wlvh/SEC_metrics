"""Ordinary integrated Runs with exact dependencies and source fiscal labels.

This successor reuses the existing Run/Review/Calculator machinery. The old
V13 source routes and frozen rules stay unchanged; new creation uses its own
Requirement and installs exact source-owned Spec files before any Run exists.
"""
from datetime import datetime, timezone
import json
from pathlib import Path

from .canonical import content_hash, sha256_file, strict_json_file
from .normal_annual_input_v2 import prepare_saved_annual_input, exact_json_value
from .normal_source_authority import ROOT
from .ordinary_source_authority import verify_ordinary_source_proofs
from .normal_run_inputs import prepare_ordinary_zero_ai_run_input
from .normal_run_specs import installed_ordinary_spec_documents
from .requirements import load_requirement_snapshot
from .sources import resolve_repository_file
from .traits import repository_company_traits


REQUIREMENT_ID = "issue_28_v13"
PREFIX = "run:ordinary-integrated:"
POLICY_PATH = "config/issue28_normal_results_v2.json"
BINDING_DIRECTORY = "ordinary_integrated_bindings"


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _external(path):
    from .b06_new_source import _external as check
    return check(Path(path))


def _write(path, content):
    from sec_http import write_immutable_bytes
    write_immutable_bytes(path=path,content=content)


def _bytes(value):
    return (json.dumps(exact_json_value(value),ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n").encode("utf-8")


def _policy(root):
    value = strict_json_file(path=resolve_repository_file(repo_root=root,repo_relative_path=POLICY_PATH))
    _need(value == strict_json_file(path=ROOT/POLICY_PATH),"ORDINARY_INTEGRATED_INSTALLED_POLICY_CHANGED")
    return value


def update_metric_ids():
    """Existing source routes plus registered B13/D04 consumption; no D03."""
    return sorted(set(_policy(ROOT)['metric_ids']) | {'B13', 'D04'})


def registered_update_options(metric_id, *, assessment_mode='LIVE'):
    """A fixed source/request contract, not per-filing answers or call rights."""
    _need(metric_id in {'B13', 'D04'} and assessment_mode in {'LIVE','RECORDED_TEST_ONLY'},
          'ORDINARY_REGISTERED_UPDATE_MODE_INVALID')
    from .continuous_request_context import FORMAT_VERSION
    return {'assessment_mode':assessment_mode, 'request_context_format':FORMAT_VERSION,
            'complete_response_contract':metric_id == 'D04'}


def _registered_update_kwargs(metric_id, options, company_id):
    if options is None:
        return {}
    _need(type(options) is dict and options == registered_update_options(metric_id,
        assessment_mode=options.get('assessment_mode')), 'ORDINARY_REGISTERED_UPDATE_CONTRACT_CHANGED')
    if metric_id == 'B13':
        from .capacity_utilization_source import policy
        _, approved = policy()
        if company_id not in approved['applicable_company_ids']:
            return {}
    return dict(options)


def prepare_case(*, data_root, company_id, metric_id, registered_update_options=None, native_assessment_ledger=None):
    if metric_id in {'B13', 'D04'}:
        from .capacity_run import prepare_case as prepare_capacity_case
        options=_registered_update_kwargs(metric_id, registered_update_options, company_id)
        if options:
            from .capacity_update_input import prepare_registered_update
            selected=prepare_registered_update(source_root=data_root,company_id=company_id,metric_id=metric_id,
                options=options,ledger=native_assessment_ledger)
            return prepare_capacity_case(data_root=data_root,company_id=company_id,metric_id=metric_id,**options,
                current_runtime=True,source_snapshot=selected['source'],assessment_input_id=selected['registered_input']['input_record_id'])
        return prepare_capacity_case(data_root=data_root,company_id=company_id,metric_id=metric_id,
            **({'current_runtime':True} if registered_update_options is not None else {}))
    policy = _policy(data_root)
    _need(metric_id in policy["metric_ids"],"ORDINARY_INTEGRATED_METRIC_NOT_ENABLED")
    note_debt = None
    debt_input = None
    if metric_id == "B06":
        from .b06_current_input import prepare_current_debt_input,withheld_current_debt_case
        debt_input = prepare_current_debt_input(repo_root=data_root,company_id=company_id)
        if debt_input["decision"] != "INPUT_PROPERTY_PROVEN":
            return withheld_current_debt_case(repo_root=data_root,company_id=company_id,packet=debt_input)
        from .ordinary_debt_guard import prepare_current_guarded_b06_result
        # The established denominator guard precedes every debt grammar. A
        # source-layout extension must not require debt evidence to establish
        # a ratio already known to be meaningless from nonpositive equity.
        guarded = prepare_current_guarded_b06_result(repo_root=data_root,company_id=company_id)
        if guarded["status"] != "NOT_MEANINGFUL":
            if guarded['reason_code'] == 'EXISTING_SPECIAL_SCOPE_REQUIRED':
                from .ordinary_special_debt_scope import prepare_special_debt_case
                note_debt = prepare_special_debt_case(repo_root=data_root,company_id=company_id)
            if note_debt is None:
                from .normal_note_debt_results import prepare_note_debt_case
                note_debt = prepare_note_debt_case(repo_root=data_root,company_id=company_id)
            if note_debt is None:
                from .normal_bond_debt_results import prepare_bond_debt_case
                note_debt = prepare_bond_debt_case(repo_root=data_root,company_id=company_id)
            if note_debt is None:
                from .normal_inclusive_debt_results import prepare_inclusive_debt_case
                note_debt = prepare_inclusive_debt_case(repo_root=data_root,company_id=company_id)
    if note_debt is not None:
        case = note_debt
    elif metric_id in {"B10","B11"}:
        from .normal_lodging_results import prepare_ordinary_lodging_case
        case = prepare_ordinary_lodging_case(repo_root=data_root,company_id=company_id,metric_id=metric_id)
    elif metric_id in installed_ordinary_spec_documents():
        original = prepare_ordinary_zero_ai_run_input(repo_root=data_root,company_id=company_id,metric_id=metric_id)
        detail = original["component"]
        if "metrics" in detail:
            detail = detail["metrics"][metric_id]
        selection = detail.get("selection",detail.get("inspection"))
        case = {"kind":"STRUCTURED","primary_metric_id":metric_id,"input_binding":original,
            "source_records":original["source_records"],"references":original["source_references"],
            "source_proofs":original["source_proofs"],"admission":original["source_admission"],
            "spec_paths":original["spec_paths"],"compiled_specs":original["compiled_specs"],
            "target_period":original["target_period"],"expected_records":original["records"],
            "results":original["results"],"traces":original["traces"],
            "observations":[r for r in original["records"] if r["record_type"] == "VERIFIED_OBSERVATION"],
            "selection":selection}
        registered = original.get("component", {}).get("input_binding", {}).get("registered_event_scope")
        if registered is not None:
            # A Run retains its reporting-year coordinate. The approved event
            # lookback is independently preserved in results and source sets.
            case["target_period"] = original["component"]["prepared_input"]["table_input"]["target_period"]
    else:
        from .ordinary_remaining_cases import prepare_current_source_case
        old = prepare_current_source_case(data_root=data_root,company_id=company_id,metric_id=metric_id)
        annual = prepare_saved_annual_input(repo_root=data_root,company_id=company_id)
        year = annual["table_input"]["target_period"]["fiscal_year"]
        if year != old["target_period"]["fiscal_year"]:
            _need(old["compiled_spec"]["compiled"]["quality_rule"].get("resolver") != "reported_compensation_table_v2",
                  "ORDINARY_SCT_SOURCE_YEAR_REPLAY_REQUIRED")
            if old["kind"] == "STRUCTURED":
                _need("fiscal_year" not in old["trace"]["calculation_target"]["scope"],
                      "ORDINARY_SOURCE_SCOPE_YEAR_REPLAY_REQUIRED")
        period = {**old["target_period"],"fiscal_year":year}
        source_records = [r for r in old["records"] if r["record_type"] in {"RAW_BLOB","SOURCE_REFERENCE"}]
        case = {"kind":old["kind"],"primary_metric_id":metric_id,
            "input_binding":{"original_source_route":old["input_binding"],"annual_label_input":annual},
            "source_records":source_records,"references":old["references"],
            "source_proofs":old["source_proofs"],"admission":old["admission"],
            "spec_paths":{metric_id:old["spec_path"]},"compiled_specs":{metric_id:old["compiled_spec"]},
            "target_period":period,"selection":old.get("selection")}
        if old["kind"] == "STRUCTURED":
            case.update(results={metric_id:old["result"]},traces={metric_id:old["trace"]},observations=old["observations"],
                expected_records=[*old["records"],*old.get("derived_assets",[]),*old["observations"],old["trace"],old["result"]])
        else:
            case.update(text_arguments=old["text_arguments"],expected_records=old["records"])
    if debt_input is not None:
        from .b06_current_input import bind_current_debt_input
        case = bind_current_debt_input(case=case,packet=debt_input,repo_root=data_root)
    _need(set(case["compiled_specs"]) == {metric_id,*case["compiled_specs"][metric_id]["compiled"]["dependencies"]},
          "ORDINARY_INTEGRATED_DEPENDENCY_SET_CHANGED")
    for metric,path in case["spec_paths"].items():
        _need(path in policy["metric_spec_paths"][metric],"ORDINARY_INTEGRATED_SPEC_ROUTE_NOT_ENABLED")
    return case


def _binding(case, requirement):
    return exact_json_value({"record_type":"ORDINARY_INTEGRATED_RUN_BINDING","kind":case["kind"],
        "primary_metric_id":case["primary_metric_id"],"input_binding":case["input_binding"],
        "source_admission":case["admission"],"spec_paths":case["spec_paths"],
        "spec_closure_hashes":{key:value["spec_closure_hash"] for key,value in case["compiled_specs"].items()},
        "target_period":case["target_period"],"requirement_closure_hash":requirement["requirement_closure_hash"],
        "production_authorized":False})


def install_normal_inputs(*, data_root, company_id, metric_id, source_root=None, registered_update_options=None, native_assessment_ledger=None):
    if metric_id in {'B13', 'D04'}:
        from .capacity_run import install_inputs
        root=ROOT if source_root is None else source_root
        options=_registered_update_kwargs(metric_id,registered_update_options,company_id)
        if options:
            from .capacity_update_input import prepare_registered_update
            selected=prepare_registered_update(source_root=root,company_id=company_id,metric_id=metric_id,
                options=options,ledger=native_assessment_ledger)
            return install_inputs(data_root=data_root,company_id=company_id,source_root=root,metric_id=metric_id,**options,
                current_runtime=True,source_snapshot=selected['source'],assessment_input_id=selected['registered_input']['input_record_id'])
        return install_inputs(data_root=data_root,company_id=company_id,source_root=root,metric_id=metric_id,
            **({'current_runtime':True} if registered_update_options is not None else {}))
    data_root = _external(data_root)
    source_root = ROOT if source_root is None else _external(source_root)
    _need(source_root != data_root and source_root not in data_root.parents and data_root not in source_root.parents,
          "ORDINARY_INTEGRATED_SOURCE_AND_OUTPUT_OVERLAP")
    case = prepare_case(data_root=source_root,company_id=company_id,metric_id=metric_id)
    requirement = load_requirement_snapshot(snapshot_dir=ROOT/"requirements"/REQUIREMENT_ID)
    _install_case_inputs(data_root=data_root,source_root=source_root,company_id=company_id,case=case,requirement=requirement)
    rebuilt = prepare_case(data_root=data_root,company_id=company_id,metric_id=metric_id)
    _need(_binding(rebuilt,requirement) == _binding(case,requirement),"ORDINARY_INTEGRATED_IMPORTED_INPUT_CHANGED")
    return rebuilt


def _install_case_inputs(*, data_root, source_root, company_id, case, requirement, extra_input_bytes=None):
    """Shared immutable runtime/source installation for explicit native routes."""
    verify_ordinary_source_proofs(data_root=source_root,proofs=case["source_proofs"])
    from .ordinary_source_authority import checkpoint_installation,EXPORT_PATH
    checkpoint,extra_source_paths = checkpoint_installation(source_root=source_root)
    from .annual_runtime import _authority_files
    from .annual_continuity_sources import frozen_foundation_receipts
    paths = set(_authority_files(requirement))
    cursor = requirement
    while cursor:
        paths.update(cursor.get("execution_authority",{}).get("files",{}))
        paths.update(cursor.get("baseline",{}).get("new_rule_files",{}))
        cursor = cursor.get("parent_snapshot")
    paths.update(str(p.relative_to(ROOT)) for p in (ROOT/"requirements").rglob("*") if p.is_file())
    parent_index = strict_json_file(path=ROOT/"docs/evidence/issue28_continuous/frozen-parent-v10-index.json")
    paths.update("docs/evidence/issue28_continuous/frozen-parent-v10/"+p for p in parent_index["files"])
    source_paths = {"config/company_registry.csv","evidence/requests_log.csv","evidence/requests_log_manifest.json",*extra_source_paths}
    for proof in case["source_proofs"]:
        source_paths.update([proof["request_repo_relative_path"],proof["request_headers_repo_relative_path"]])
    # Event completeness also compares the authenticated acquisition census.
    # Header bytes used by that census are bound original inputs, not answers.
    if case["primary_metric_id"] in {"C01","E01","E02","E03","E04","E05"}:
        from .traits import repository_company_ciks
        ciks = {int(cik) for cik in repository_company_ciks(repo_root=source_root,company_id=company_id)}
        for directory in (source_root/"evidence/accession_materials").iterdir():
            fields = directory.name.rsplit("_",2)
            if directory.is_dir() and len(fields)==3 and fields[1].isdigit() and int(fields[1]) in ciks:
                source_paths.update(str(p.relative_to(source_root)) for p in directory.glob("*.hdr.sgml"))
    _need(not source_paths.intersection(_policy(ROOT)["rule_paths"]+_policy(ROOT)["presentation_paths"]),
          "ORDINARY_INTEGRATED_SOURCE_WOULD_REPLACE_RUNTIME")
    receipts = frozen_foundation_receipts()
    for relative in sorted(paths|source_paths):
        source = resolve_repository_file(repo_root=source_root if relative in source_paths else ROOT,repo_relative_path=relative)
        _write(data_root/relative,receipts[relative]["bytes"] if relative in receipts else source.read_bytes())
    if checkpoint is not None:_write(data_root/EXPORT_PATH,_bytes(checkpoint))
    for relative, raw in (extra_input_bytes or {}).items():
        _need(relative not in paths|source_paths and not Path(relative).is_absolute()
              and '..' not in Path(relative).parts, 'ORDINARY_EXTRA_INPUT_WOULD_REPLACE_RUNTIME')
        _write(data_root/relative,raw)


def text_api(metric_id):
    if metric_id in {'B13', 'D04'}:
        from . import capacity_text_results
        return capacity_text_results, capacity_text_results.build_text_review_unit
    from .normal_run_v2 import text_api as select
    return select(metric_id)


def create_normal_run(*, data_root, run_dir, company_id, metric_id, freeze=False):
    if metric_id in {'B13', 'D04'}:
        _need(not freeze, 'ORDINARY_INTEGRATED_DRAFT_FREEZE_DISABLED')
        from .capacity_run import create_run as create_capacity_run
        return create_capacity_run(data_root=data_root, run_dir=run_dir, company_id=company_id, metric_id=metric_id)
    data_root,run_dir = _external(data_root),_external(run_dir)
    _need(not run_dir.exists(),"ORDINARY_INTEGRATED_RUN_PATH_EXISTS")
    _need(not freeze or _policy(data_root)["freeze_enabled"],"ORDINARY_INTEGRATED_DRAFT_FREEZE_DISABLED")
    case = prepare_case(data_root=data_root,company_id=company_id,metric_id=metric_id)
    from .ordinary_source_authority import require_installed_checkpoint
    require_installed_checkpoint(data_root=data_root,admission=case["admission"])
    requirement = load_requirement_snapshot(snapshot_dir=data_root/"requirements"/REQUIREMENT_ID)
    return _create_case_run(data_root=data_root,run_dir=run_dir,company_id=company_id,metric_id=metric_id,
                            case=case,requirement=requirement,freeze=freeze)


def _create_case_run(*, data_root, run_dir, company_id, metric_id, case, requirement, freeze=False):
    """One native record/Review/Result write order for ordinary source routes."""
    from .run_store import (create_run,append_run_record,append_review_decision,write_review_assets,
        validate_and_freeze_run,load_frozen_run,_mechanically_replay_open_run)
    data_root,run_dir = _external(data_root),_external(run_dir)
    _need(not run_dir.exists(),"ORDINARY_INTEGRATED_RUN_PATH_EXISTS")
    _need(not freeze or _policy(data_root)["freeze_enabled"],"ORDINARY_INTEGRATED_DRAFT_FREEZE_DISABLED")
    binding = _binding(case,requirement);key = content_hash(value=binding)[7:]
    _write(data_root/BINDING_DIRECTORY/(key+".json"),_bytes(binding))
    traits = repository_company_traits(repo_root=data_root,company_id=company_id)
    decision,unit,assets = None,None,None
    terminal_records = []
    if case["kind"] == "TEXT":
        api,review_builder = text_api(metric_id)
        spec = case["compiled_specs"][metric_id]
        candidate = api.create_deterministic_text_candidate(**case["text_arguments"])
        evidence = api.build_text_evidence(candidate=candidate,**case["text_arguments"])
        unit,assets = review_builder(compiled_spec=spec,candidate=candidate,evidence_check=evidence,
                                    source_bindings=case["text_arguments"]["source_references"])
        from .review import create_system_review_decision
        decision = create_system_review_decision(review_unit=unit,required_claims=spec["compiled"]["required_claims"],
            decided_at_utc=datetime.now(timezone.utc).isoformat(),requirement=requirement)
        result,trace,observations = api.replay_text_result(company_traits=traits,candidate=candidate,evidence_check=evidence,
            review_unit=unit,review_decisions=[decision],**case["text_arguments"])
        records = [*case["expected_records"],candidate,evidence,unit]
        terminal_records = [*observations,trace,result]
    else:
        records = case["expected_records"];result = case["results"][metric_id]
    create_run(run_dir=run_dir,run_id=PREFIX+key,company_id=company_id,company_traits=traits,
        target_period=case["target_period"],source_references=case["references"],missing_required_source_roles=[],
        spec_file_hashes={p:sha256_file(path=data_root/p) for p in case["spec_paths"].values()},
        requirement_hashes=requirement["hashes"],requirement_id=requirement['requirement_id'],
        requirement_closure_hash=requirement["requirement_closure_hash"],artifact_requirement_generation="EXPLICIT_REQUIREMENT_V1")
    seen = {}
    for record in records:
        identity = content_hash(value=record)
        _need(identity not in seen or seen[identity] == record,"ORDINARY_INTEGRATED_RECORD_COLLISION")
        if identity not in seen:
            append_run_record(run_dir=run_dir,record=record);seen[identity] = record
    if decision:
        write_review_assets(run_dir=run_dir,review_unit=unit,review_context_bytes=assets["review_context_bytes"],
                            rendered_review_bytes=assets["rendered_review_bytes"])
        append_review_decision(run_dir=run_dir,decision=decision)
    for record in terminal_records:
        append_run_record(run_dir=run_dir,record=record)
    if freeze:
        validate_and_freeze_run(run_dir=run_dir,repo_root=data_root)
        manifest,stored,_ = load_frozen_run(run_dir=run_dir,repo_root=data_root)
    else:
        manifest,stored,_ = _mechanically_replay_open_run(run_dir=run_dir,repo_root=data_root,require_complete_results=True)
    _need(result in stored,"ORDINARY_INTEGRATED_RESULT_CHANGED")
    return {"manifest":manifest,"result":result,"input_binding":binding,"selection":case.get("selection"),
            "new_calls":{"provider":0,"paid":0,"sec":0},"production_authorized":False}


def replay_case(*, data_root, manifest, spec=None):
    if manifest.get('requirement_id') == 'issue_28_v14':
        from .capacity_run import validate_run_authority
        case = validate_run_authority(repo_root=data_root, manifest=manifest, records=None, compiled_specs=None)
        _need(spec is None or spec == case['compiled_specs'][case['primary_metric_id']], 'B13_NATIVE_SPEC_CHANGED')
        return case
    _need(manifest["requirement_id"] == REQUIREMENT_ID and manifest["run_id"].startswith(PREFIX),
          "ORDINARY_INTEGRATED_RUN_IDENTITY_REQUIRED")
    key = manifest["run_id"][len(PREFIX):]
    saved = strict_json_file(path=resolve_repository_file(repo_root=data_root,repo_relative_path=BINDING_DIRECTORY+"/"+key+".json"))
    metric_id = saved["primary_metric_id"]
    _need(metric_id in _policy(data_root)['metric_ids'], 'ORDINARY_INTEGRATED_METRIC_NOT_ENABLED')
    case = prepare_case(data_root=data_root,company_id=manifest["company_id"],metric_id=metric_id)
    from .ordinary_source_authority import require_installed_checkpoint
    require_installed_checkpoint(data_root=data_root,admission=case["admission"])
    requirement = load_requirement_snapshot(snapshot_dir=data_root/"requirements"/REQUIREMENT_ID)
    expected = _binding(case,requirement)
    _need(saved == expected and content_hash(value=expected)[7:] == key,"ORDINARY_INTEGRATED_INPUT_BINDING_CHANGED")
    _need(manifest["target_period"] == case["target_period"] and manifest["source_references"] == case["references"]
          and manifest["requirement_closure_hash"] == requirement["requirement_closure_hash"]
          and manifest["spec_file_hashes"] == {p:sha256_file(path=data_root/p) for p in case["spec_paths"].values()},
          "ORDINARY_INTEGRATED_SOURCE_SPEC_OR_PERIOD_CHANGED")
    if spec is not None:
        _need(case["compiled_specs"].get(spec["compiled"]["metric_id"]) == spec,"ORDINARY_INTEGRATED_SPEC_NOT_IN_GRAPH")
    return case


def validate_normal_run_authority(*, repo_root, manifest, records, compiled_specs):
    case = replay_case(data_root=repo_root,manifest=manifest)
    _need(compiled_specs == case["compiled_specs"],"ORDINARY_INTEGRATED_EXACT_SPEC_SET_REQUIRED")
    source_records = [r for r in records if r["record_type"] in {"RAW_BLOB","SOURCE_REFERENCE"}]
    _need(sorted(source_records,key=lambda r:content_hash(value=r)) == sorted(case["source_records"],key=lambda r:content_hash(value=r)),
          "ORDINARY_INTEGRATED_SOURCE_RECORD_SET_CHANGED")
    if case["kind"] == "STRUCTURED":
        kinds = {"DETERMINISTIC_VERIFIED_CLAIM","VERIFIED_OBSERVATION","EXECUTION_TRACE","METRIC_RESULT"}
        expected = {content_hash(value=r):r for r in case["expected_records"] if r["record_type"] in kinds}
        actual = [r for r in records if r["record_type"] in kinds]
        _need(sorted(actual,key=lambda r:content_hash(value=r)) == [expected[k] for k in sorted(expected)],
              "ORDINARY_INTEGRATED_COMPLETE_COMPUTATION_GRAPH_CHANGED")
    return case


def prepare_text_contexts(*, repo_root, manifest, records, compiled_specs, **unused):
    candidates = [r for r in records if r["record_type"] == "DETERMINISTIC_TEXT_CANDIDATE"]
    if not candidates:
        return {}
    _need(len(candidates) == len(compiled_specs) == 1,"ORDINARY_INTEGRATED_TEXT_EXACT_SET_REQUIRED")
    spec = next(iter(compiled_specs.values()))
    case = replay_case(data_root=repo_root,manifest=manifest,spec=spec)
    _need(case["kind"] == "TEXT","ORDINARY_INTEGRATED_TEXT_ROUTE_REQUIRED")
    api,_ = text_api(spec["compiled"]["metric_id"])
    expected = api.create_deterministic_text_candidate(**case["text_arguments"])
    _need(candidates[0] == expected,"ORDINARY_INTEGRATED_TEXT_CANDIDATE_CHANGED")
    return {expected["candidate_hash"]:case["text_arguments"]}
