"""Run the vNext fast local verification set concurrently.

Purpose:
    Provide the fast/local feedback loop inherited by Issue #15. Its D-26 tip
    keeps broad repository and isolated-workspace suites out of the required
    path while permitting short deterministic invariant tests.

Call relationships:
    Developers and ``tools/run_acceptance.py`` call this script.  Each selected
    unittest is a direct, non-isolated unit boundary and executes in a separate
    subprocess so independent checks use available CPU cores without sharing
    repository authority state. Full portable publication closure belongs to
    the documented integration gates, not this 30-second-per-case tier.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Sequence


REPO_ROOT = Path(__file__).resolve().parents[1]
FAST_TESTS = (
    "tests.vnext.test_normal_run_authority",
    "tests.vnext.test_b06_guarded_result_v3.B06GuardSourceTest",
    "tests.vnext.test_text_results_v2",
    "tests.vnext.test_normal_text_input_v2",
    "tests.vnext.test_financial_candidates.LcrEntityFastTest.test_unidentified_consolidated_group_is_rejected",
    "tests.vnext.test_financial_candidates.LcrEntityFastTest.test_unidentified_named_holding_is_rejected",
    "tests.vnext.test_financial_candidates.LcrEntityFastTest.test_explicit_subsidiaries_keep_their_original_definition",
    "tests.vnext.test_financial_balance_scope.AumClientFastTest.test_excluding_clients",
    "tests.vnext.test_financial_balance_scope.AumClientFastTest.test_but_not_clients",
    "tests.vnext.test_financial_balance_scope.AumClientFastTest.test_selected_clients",
    "tests.vnext.test_financial_balance_scope.AumClientFastTest.test_only_private_clients",
    "tests.vnext.test_financial_balance_scope.AumClientFastTest.test_only_institutional_and_retail_clients",
    "tests.vnext.test_financial_balance_scope.AumClientFastTest.test_unrelated_exclusion_does_not_change_aum_scope",
    "tests.vnext.test_financial_balance_scope.FinancialBalanceScopeTest.test_var_reported_estimate_is_distinct_from_an_illustrative_table",
    "tests.vnext.test_financial_structured.FinancialStructuredTest.test_native_tags_do_not_override_an_explicit_non_reported_table_declaration",
    "tests.vnext.test_normal_candidate_authority",
    "tests.vnext.test_normal_candidate_semantics",
    "tests.vnext.test_text_results",
    "tests.vnext.test_risk_signals",
    "tests.vnext.test_governance_signals",
    "tests.vnext.test_governance_compensation_table",
    "tests.vnext.test_normal_governance_input.NormalGovernanceMetadataTest",
    "tests.vnext.test_normal_governance_input.NormalGovernanceBoundaryTest.test_actual_legacy_attempt_is_pinned_without_inventing_id",
    "tests.vnext.test_normal_governance_input.NormalGovernanceBoundaryTest.test_later_failed_get_never_falls_back_to_success",
    "tests.vnext.test_normal_governance_input.NormalGovernanceBoundaryTest.test_preparation_reads_original_proofs_without_derived_inventories",
    "tests.vnext.test_normal_governance_input.NormalGovernanceBoundaryTest.test_imported_registry_cannot_relabel_a_different_subject",
    "tests.vnext.test_normal_governance_input.AuditorV2InputTest",
    "tests.vnext.test_normal_source_authority",
    "tests.vnext.test_replay.ReplayTest.test_validate_and_freeze_replays_run_before_pass",
    "tests.vnext.test_financial_duration",
    "tests.vnext.test_text_coverage",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_original_two_modes_keep_amounts_and_explain_different_measurements",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_primary_equity_amount_sign_scale_and_unit_conflicts_reject",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_explicit_additional_current_borrowing_blocks_both_modes",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_borrowing_keyword_and_explicit_past_issuance_do_not_block",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_current_named_carrying_total_is_reconciled_but_unknown_balance_is_not",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_current_balance_cannot_inherit_an_unspecified_date",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_zero_clause_cannot_hide_a_positive_balance_or_unsupported_amount",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_same_xml_and_primary_alternate_total_still_needs_its_own_arithmetic",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_unconsumed_known_concept_must_agree_with_primary",
    "tests.vnext.test_b06_disclosure_v2.B06DisclosureV2Test.test_newer_disclosed_credit_group_is_derived_from_table_members",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_invalid_source_fiscal_label_and_cik_are_integrity_failures",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_saved_noncalendar_inputs_use_dei_fiscal_label",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_amendment_keeps_original_and_does_not_claim_current_success",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_latest_period_cannot_fall_back_when_only_amendment_is_present",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_ambiguous_columns_dates_and_relevant_shards_are_not_no_change",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_period_rechecks_entity_and_does_not_promote_quarter_to_year",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_00",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_01",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_02",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_03",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_04",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_05",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_06",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_07",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_08",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_registry_company_09",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_unknown_subject_policy_isolated_without_using_predecessor",
    "tests.vnext.test_normal_annual_input.NormalAnnualInputTest.test_later_source_failure_is_not_relabelled_as_old_success",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_development_modes_rebuild_real_source_relations",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_same_arithmetic_but_explicit_lease_exclusion_rejects_at_relation",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_selected_model_cannot_grant_inclusion_or_nonoverlap",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_custom_outside_calculation_allowlist_cannot_disappear",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_approval_fields_and_duplicate_formula_not_part_of_proposal",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_asset_payment_wrong_year_and_entity_do_not_become_liability",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_missing_primary_or_note_is_not_zero",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_forged_matching_ledger_has_no_admission",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_reverse_subject_exclusion_and_inclusion_are_conflicts",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_custom_tax_loan_and_credit_facility_remain_unresolved",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_added_balance_sheet_financing_row_cannot_inherit_coverage",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_primary_only_sign_conflict_is_not_whitespace",
    "tests.vnext.test_b06_new_source.B06NewSourceTest.test_dynamic_amounts_are_reread_with_new_test_identity",
    "tests.vnext.test_r5_b06.B06PrimaryTest",
    "tests.vnext.test_r5_b06_followup",
    "tests.vnext.test_r5_b06_scope",
    "tests.vnext.test_annual_publication_authority",
    "tests.vnext.test_annual_publication",
    "tests.vnext.test_annual_continuity.AnnualContinuityBoundaryTest",
    "tests.vnext.test_annual_continuity.AnnualModelConfigurationTest",
    "tests.vnext.test_annual_continuity.AnnualContinuationPermissionTest",
    "tests.vnext.test_annual_group_prompt.AnnualGroupPromptTest.test_prompt_changes_only_instruction_and_its_task_identities",
    "tests.vnext.test_annual_group_prompt.AnnualGroupPromptTest.test_no_requirement_and_other_task_retain_original_prompt",
    "tests.vnext.test_annual_group_prompt.AnnualGroupPromptTest.test_prompt_file_tamper_is_rejected_without_rewriting_repository",
    "tests.vnext.test_annual_group_prompt.AnnualGroupPromptTest.test_stage_three_counts_two_closed_attempts_before_new_slots",
    "tests.vnext.test_annual_update.AnnualUpdateTest.test_candidate_leading_publication_survives_discovery_failure",
    "tests.vnext.test_annual_update.AnnualUpdateTest.test_publication_progress_is_explicit_and_run_specific",
    "tests.vnext.test_annual_repair.AnnualLabelRegressionTest.test_policy_selects_new_requirement_only",
    "tests.vnext.test_r4_release_gate.R4ReleaseAggregateGateTest",
    "tests.vnext.test_r4_publication_boundaries",
    "tests.vnext.test_r4_projection.R4ProjectionBoundaryTest."
    "test_complete_grid_rejects_missing_duplicate_extra_and_false_applicability",
    "tests.vnext.test_successor_invocation_control",
    "tests.vnext.test_live_scoped_reader.LiveScopedEnvelopeTest",
    "tests.vnext.test_r4_live_authority.R4LiveAuthorityShapeTest",
    "tests.vnext.test_r4_live_authority.R4ExecutionPrefixTest",
    "tests.vnext.test_r4_live_plan.R4DraftPlanRiskTest",
    "tests.vnext.test_issue28_v2.Issue28V2FastTest."
    "test_real_five_file_revision_has_exact_parent_and_no_activation",
    "tests.vnext.test_source_scope.SourceScopeTest."
    "test_complete_native_candidate_and_evidence_are_bound",
    "tests.vnext.test_scoped_reader.ScopedReaderTest."
    "test_all_four_zero_call_classes_cannot_prepare_requests",
    "tests.vnext.test_offline_execution_session.OfflineExecutionSessionTest."
    "test_unknown_is_terminal_and_cannot_be_retried",
    "tests.vnext.test_cutover_qualification.CutoverQualificationTest."
    "test_layout_terminal_requires_approval_publish_and_validation",
    "tests.vnext.test_ai_reader_contract.AiReaderContractTest."
    "test_deepseek_chat_envelope_is_json_and_tool_free",
    "tests.vnext.test_review_binding.ReviewBindingTest."
    "test_optional_system_decision_is_auditable",
    "tests.vnext.test_legacy_projector.LegacyProjectorTest."
    "test_legacy_inventory_binds_frozen_commit_and_source_blobs",
    "tests.vnext.test_issue28_requirement_transition."
    "Issue28RequirementTransitionFastTest."
    "test_profile_snapshot_loads_with_historical_parent_fast_smoke",
    "tests.vnext.test_issue15_authority.Issue15AuthorityTest."
    "test_reusable_producer_scopes_match_exact_base_call_graph",
    "tests.vnext.test_source_strategy_registry.SourceStrategyRegistryTest."
    "test_registry_covers_exact_39_without_migration_state",
    "tests.vnext.test_deterministic_router.DeterministicRouterTest."
    "test_e01_matched_event_key_set_has_exact_legacy_parity",
    "tests.vnext.test_invocation_control",
    "tests.vnext.test_stage_c_context_packet.StageCContextPacketFastTest."
    "test_current_packet_persists_no_credit_and_zero_current_egress",
    "tests.vnext.test_table_stage_c_financial_materialization",
    "tests.vnext.test_table_stage_c_a_packet.TableStageCAPacketTest."
    "test_packet_sections_preserve_stage_c_a_claim_boundaries",
    "tests.vnext.test_stage_c_context_packet.StageCContextPacketFastTest."
    "test_historical_stage_c_b_packet_remains_content_addressed",
    "tests.vnext.test_table_context_attestation.TableContextAttestationTest."
    "test_historical_occupancy_request_has_no_current_credit",
    "tests.vnext.test_table_context_measurement."
    "TableContextMeasurementTerminalTest."
    "test_revpar_terminal_is_consumed_exact_and_non_credit",
    "tests.vnext.test_table_context_qualification_guard."
    "TableContextQualificationGuardTest."
    "test_missing_or_excess_usage_is_terminal_and_skips_ordinal_two",
    "tests.vnext.test_table_context_attestation.TableContextAttestationTest."
    "test_historical_revpar_request_has_no_current_credit",
    "tests.vnext.test_stage_c_context_packet.StageCContextPacketFastTest."
    "test_current_packet_persists_sibling_and_financial_blockers",
    "tests.vnext.test_zero_ai_release.ZeroAiReleaseFastTest."
    "test_r2_predecessor_bundle_fast_smoke",
    "tests.vnext.test_acceptance_runner.AcceptanceRunnerTest."
    "test_r4_plan_uses_fast_runner_without_full_discovery",
)
FAST_TEST_TIMEOUT_SECONDS = 30


class FastTestError(ValueError):
    """Report an invalid fast-test CLI configuration."""


def _run_case(*, test_name: str) -> Dict[str, object]:
    """Execute one direct unittest case without sharing process state.

    Args:
        test_name: Fully qualified unittest method selected by R4.

    Returns:
        Test name, return code, duration, and bounded diagnostics.
    """
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    started = time.monotonic()
    try:
        completed = subprocess.run(
            args=[sys.executable, "-m", "unittest", "-q", test_name],
            cwd=str(REPO_ROOT),
            check=False,
            capture_output=True,
            encoding="utf-8",
            env=environment,
            timeout=FAST_TEST_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as error:
        stderr = error.stderr
        stdout = error.stdout
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", errors="replace")
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", errors="replace")
        return {
            "test": test_name,
            "return_code": 124,
            "duration_seconds": round(time.monotonic() - started, 3),
            "stderr_tail": (
                (stderr or "")[-2000:]
                + "\nFAST_TEST_TIMEOUT_SECONDS={}\n".format(
                    FAST_TEST_TIMEOUT_SECONDS,
                )
            ),
            "stdout_tail": (stdout or "")[-2000:],
        }
    return {
        "test": test_name,
        "return_code": completed.returncode,
        "duration_seconds": round(time.monotonic() - started, 3),
        "stderr_tail": completed.stderr[-2000:],
        "stdout_tail": completed.stdout[-2000:],
    }


def run_fast_tests(*, jobs: int) -> Dict[str, object]:
    """Run the complete R4-selected test list with bounded concurrency.

    Args:
        jobs: Maximum number of independent test subprocesses to run at once.

    Returns:
        A deterministic summary labelled only as fast local evidence.

    Raises:
        FastTestError: If the requested concurrency is outside the safe range.
    """
    if jobs < 1 or jobs > len(FAST_TESTS):
        raise FastTestError("FAST_TEST_JOBS_INVALID")
    started = time.monotonic()
    # Every selected method avoids shared publication state, so process-level
    # concurrency shortens feedback without changing an authority boundary.
    with concurrent.futures.ThreadPoolExecutor(
        max_workers=jobs,
    ) as executor:
        futures = {
            executor.submit(_run_case, test_name=test_name): test_name
            for test_name in FAST_TESTS
        }
        rows = [future.result() for future in futures]
    rows.sort(key=lambda row: str(row["test"]))
    return {
        "evidence_tier": "FAST_LOCAL_ONLY",
        "jobs": jobs,
        "per_case_timeout_seconds": FAST_TEST_TIMEOUT_SECONDS,
        "duration_seconds": round(time.monotonic() - started, 3),
        "tests": rows,
        "status": (
            "PASSED"
            if all(row["return_code"] == 0 for row in rows)
            else "FAILED"
        ),
    }


def main(*, argv: Sequence[str]) -> int:
    """Parse R4 fast-test options and emit a concise JSON summary.

    Args:
        argv: Command-line tokens excluding the executable name.

    Returns:
        Zero only when every selected direct test passes.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--jobs", type=int, default=min(4, len(FAST_TESTS)))
    parser.add_argument("--list", action="store_true")
    arguments = parser.parse_args(list(argv))
    if arguments.list:
        print(json.dumps({"tests": list(FAST_TESTS)}, ensure_ascii=False))
        return 0
    try:
        result = run_fast_tests(jobs=arguments.jobs)
    except FastTestError as error:
        print(json.dumps(
            {
                "status": "FAILED",
                "error_code": str(error),
                "evidence_tier": "FAST_LOCAL_ONLY",
            },
            ensure_ascii=False,
        ))
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result["status"] == "PASSED" else 1


if __name__ == "__main__":
    sys.exit(main(argv=sys.argv[1:]))
