# Marriott FY2025 company computation package (issue #54, 2026-10-04 live2)

Minimal computation handoff, not the full task-restore set.

- company-source/: source-only company package exported by the fixed PR55 program
  (checkpoint sha256:e94a80466696083a88942187a7849e356e869e73ff68291d29182c0755679805, full 38-metric scope from the repeat run; the later partial-reentry package 48a641a1 covers only B01/C01/D04 and stays in the task-state archive).
  Contains the original SEC bodies + HTTP headers of this run's 29 live GETs plus 2+0 metadata
  refreshes that the company scope needs, the unchanged task ledger, registry and rules.
  No AI assessment, Run or Result inside.
- trust-company/: the independently installed admission record for that checkpoint
  (pass its directory as --trust-root / SEC_METRICS_SOURCE_TRUST_ROOT; never generated from the package).
- d04-original-source/ + d04-original-source-trust/: the admitted original baseline company SEC
  version (checkpoint sha256:1b436ef0...) that the saved LIVE D04 judgment f252a7a4 was made on.
  The processing packet/program/trust themselves are reproducible from Git commit 7ed952bb
  (materialize-d04-handoff.py); see docs/evidence/issue54_company/live2/README.md in PR55.
- processing.json.as-run: the D04 configuration used (absolute paths of the run host).
- outputs/<run-id>/: metrics_matrix.csv, metric_evidence.csv, run_summary.json and stage reports of
  the first run, the repeat and the partial reentry.

Compute from it (fixed program = PR55 83db2c02 `install-runtime --kind local`, authority
sha256:792b5095...):
  python3 <rt>/tools/vnext_company.py install --package-root company-source --state-root <state> --trust-root trust-company --company marriott_international
  python3 <rt>/tools/vnext_company.py compute --state-root <state> --trust-root trust-company --company marriott_international --metric B01 ...
No SEC/provider calls are made by these steps.
