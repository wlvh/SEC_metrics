"""B13 per-request Candidate/Evidence on the existing WB-3 acceptance chain.

Acceptance proves complete response coverage, literal source references and
finite source-role checks. It does not certify a whole metric or publish it.
The final B13 route must consume every request and obtain its own Review.
"""
from pathlib import Path

from .canonical import content_hash, sha256_bytes, sha256_file, strict_json_loads, strict_json_file
from .capacity_utilization_source import need
from .capacity_semantic_review import validate_response
from .records import validate_record
from .normal_source_authority import ROOT
from .specs import compile_spec_file
from .sources import resolve_repository_file


def build_acceptance(*, prepared, plan, response_body):
    request = strict_json_loads(text=prepared.request_bytes.decode())
    need(request['metric_id'] == 'B13', 'B13_NATIVE_ASSESSMENT_REQUIRED')
    from .capacity_reference_contract import (ASSERTION_SCOPED_VERSION,
        CLAIM_CONTEXT_VERSION, MODEL_SPAN_VERSION, SCANNED_VERSION)
    need(request.get('source_reference_contract', {}).get('version') not in {
         SCANNED_VERSION, ASSERTION_SCOPED_VERSION, CLAIM_CONTEXT_VERSION,
         MODEL_SPAN_VERSION},
         'B13_TWO_STAGE_SCAN_EXECUTION_PROOF_REQUIRED')
    checked = validate_response(request=request, raw_response=response_body,source=strict_json_loads(text=prepared.source_bytes.decode()))
    return _build_acceptance(prepared=prepared, plan=plan, response_body=response_body, checked=checked,
        metric_id='B13', group='b13_capacity_source_assessment_v1',
        spec_path='catalog/r5/B13_capacity_disclosures_v1.md', validator_path=Path(__file__))


def _build_acceptance(*, prepared, plan, response_body, checked, metric_id, group,
                      spec_path, validator_path, stage_proof=None):
    """Shared native records; each metric's wrapper owns its source checks."""
    request = strict_json_loads(text=prepared.request_bytes.decode())
    source = strict_json_loads(text=prepared.source_bytes.decode())
    if metric_id == 'D03':
        # A complete answer may correctly leave the action, subject or period
        # unresolved. Preserve it for company Review; this one-request
        # Candidate/Evidence does not establish a metric Result.
        unresolved = d03_review_blockers(checked)
    else:
        unresolved = checked['unresolved'] or any(
            f['kind'] == 'UNRESOLVED' or f['subject'] == 'UNRESOLVED'
            or f['timing'] == 'UNRESOLVED' for f in checked['findings'])
        need(not unresolved, metric_id + '_SOURCE_ASSESSMENT_UNRESOLVED')
    document = next(d for d in source['documents']
                    if d['document_id'] == request['document_context']['document_id'])
    source_ids = [document['source_reference']['source_reference_id']]
    body = {'disclosure_group': group,
            'source_reference_ids': source_ids, 'derived_asset_ids': [plan['selected_representation_hash']],
            'selected': {'source_assessment': {
                'request_id': request['request_id'], 'unit_ids': [u['unit_id'] for u in request['units']],
                'findings': checked['findings'], 'calculation_limits': checked.get('calculation_limits', [])}},
            'competing_candidates': [],
            'unresolved_competing_claims': unresolved if metric_id == 'D03' else []}
    if 'program_quantity_contract' in checked:
        body['selected']['source_assessment']['program_quantity_contract']=checked['program_quantity_contract']
    if stage_proof is not None:
        from .capacity_reference_contract import ASSERTION_SCOPED_VERSION, SCANNED_VERSION
        need(metric_id == 'B13' and request.get('source_reference_contract', {}).get('version') in {
             SCANNED_VERSION, ASSERTION_SCOPED_VERSION},
             'B13_TWO_STAGE_ACCEPTANCE_SCOPE_CHANGED')
        body['selected']['source_assessment']['scan_stage_proof'] = stage_proof
    candidate = validate_record(record={'record_type': 'OBSERVATION_CANDIDATE', **body,
        'candidate_hash': content_hash(value=body), 'attempt_id': {
            'B13': 'capacity:', 'D03': 'regulatory:', 'D04': 'going-concern:'
        }[metric_id] + plan['ai_invocation_plan_id'][7:],
        'assistant_output_sha256': sha256_bytes(content=response_body), 'status': 'CANDIDATE'})
    evidence_body = {'candidate_hash': candidate['candidate_hash'], 'status': 'PASS',
        'normalized_values': candidate['selected'],
        'checks': [
            {'check': metric_id + '_COMPLETE_REQUEST_UNIT_RESPONSE', 'status': 'PASS',
             'request_id': request['request_id'], 'unit_ids': [u['unit_id'] for u in request['units']]},
            {'check': metric_id + ('_ORIGINAL_SOURCE_REFERENCES_AND_FORMAT'
                                  if metric_id == 'D03' else
                                  '_ORIGINAL_SOURCE_REFERENCES_AND_ROLES'), 'status': 'PASS',
             'findings': checked['findings']}],
        'reason_codes': [], 'identity_constraints': []}
    if metric_id == 'D03' and unresolved:
        evidence_body['checks'].append({'check': 'D03_UNRESOLVED_RETAINED_FOR_COMPANY_REVIEW',
            'status': 'PASS', 'unresolved': unresolved})
    if 'program_quantity_contract' in checked:
        evidence_body['checks'].append({'check':'B13_PROGRAM_OWNED_ORIGINAL_QUANTITY_ROLES','status':'PASS',
            'program_quantity_contract':checked['program_quantity_contract']})
    if stage_proof is not None:
        evidence_body['checks'].append({'check':'B13_SAVED_SCAN_STAGE_AND_INTERPRETATION_LINK','status':'PASS',
            'scan_stage_proof':stage_proof})
    evidence = validate_record(record={'record_type': 'EVIDENCE_CHECK', **evidence_body,
        'evidence_check_id': content_hash(value=evidence_body)})
    spec = compile_spec_file(path=ROOT / spec_path, dependency_specs={})
    return {'candidate_hash': candidate['candidate_hash'], 'candidate_record': candidate,
        'derived_asset_id': plan['selected_representation_hash'],
        'evidence_candidate_hash': candidate['candidate_hash'], 'evidence_check_id': evidence['evidence_check_id'],
        'evidence_record': evidence, 'evidence_status': 'PASS',
        'reader_input_manifest_id': plan['source_identity_hash'], 'source_reference_ids': source_ids,
        'spec_semantic_hash': spec['spec_semantic_hash'],
        'task_contract_hash': plan['task_contract_hash'],
        'validator_semantic_hash': content_hash(value={
            'module': sha256_file(path=validator_path),
            'policy': request['policy_sha256']}),
        'validator_semantic_version': metric_id + '_REQUEST_SOURCE_ASSESSMENT_V1'}


def d03_review_blockers(checked):
    """Keep explicit uncertainty and uncertain current/negative classifications."""
    blockers = list(checked['unresolved'])
    for index, finding in enumerate(checked['findings']):
        if (finding['kind'] == 'UNRESOLVED' or
                (finding['kind'] in {'CURRENT_REGULATORY_ACTION',
                                     'NO_ACTION_DECLARATION'} and
                 (finding['subject'] == 'UNRESOLVED' or
                  finding['timing'] == 'UNRESOLVED'))):
            blockers.append({'unit_id': finding['unit_id'],
                             'finding_index': index,
                             'reason': 'D03_FINDING_SCOPE_OR_MEANING_UNRESOLVED'})
    return blockers


def collect_native_assessments(*, prepared_requests, ledger):
    """Read all current source requests; a diagnostic terminal cannot fill one.

    This uses the existing ledger and native success reader. Missing/failed
    requests remain explicit development/execution gaps, never nondisclosure.
    """
    from . import invocation_control as control
    from .native_unit_index import validate_request_partition
    from .native_assessment_replay import replay_native_response
    need(bool(prepared_requests), 'B13_COMPLETE_REQUEST_SET_REQUIRED')
    source = strict_json_loads(text=prepared_requests[0].source_bytes.decode())
    metric_id = source['metric_id']
    need(metric_id in {'B13', 'D04'}, 'NATIVE_SOURCE_METRIC_UNSUPPORTED')
    if metric_id == 'D04':
        need(source['record_type'] == 'D04_NATIVE_COMPLETE_SEMANTIC_SOURCE', 'D04_FRESH_NATIVE_SOURCE_REQUIRED')
    expected = [strict_json_loads(text=p.request_bytes.decode()) for p in prepared_requests]
    need(all(p.source_bytes == prepared_requests[0].source_bytes for p in prepared_requests),
         'B13_COMPLETE_REQUEST_SET_CHANGED')
    variants = validate_request_partition(source, expected)
    by_id = {request['request_id']: prepared for request, prepared in zip(expected, prepared_requests)}
    need(len(by_id) == len(prepared_requests), 'B13_COMPLETE_REQUEST_SET_CHANGED')
    completed, failures = {}, []
    recovered_failures = []
    batch_history = None
    recovered_batch_failed_ordinals = []
    recovered_batch_http402_ordinals = []
    recovered_batch_engineering_ordinals = []
    with ledger.locked():
        state = ledger.snapshot()
        if (ledger.root/'batch33-authorization.json').exists():
            from .continuous_batch33 import history_for_current
            batch_history = history_for_current(ledger=ledger)
        for row in state['rows']:
            if row['channel'] != 'PROVIDER':
                continue
            path = ledger.root / 'calls' / ('%04d' % row['ordinal'])
            request_path = path / 'semantic-request.json'
            if not request_path.exists():
                continue
            saved = strict_json_file(path=resolve_repository_file(repo_root=path,
                                    repo_relative_path='semantic-request.json'))
            identity = saved.get('request_id')
            if identity not in by_id:
                continue
            prepared = by_id[identity]
            current = strict_json_loads(text=prepared.request_bytes.decode())
            if saved != current:
                # A failed same-digest original may have different wire bytes
                # after the lossless-source repair (original113). Keep that
                # failure visible without replaying or fixing it in place.
                # Only the exact, separately granted group's new request may
                # later replace its failure as current assessment input.
                allowed = False
                if batch_history is not None and row['status'] == 'FAILED_TERMINAL':
                    from .continuous_call_policy import configured_transport_policy
                    from .continuous_semantic_calls import request_digest
                    from .continuous_batch33 import groups_for
                    auth = batch_history['authorization']
                    old = batch_history['original_same_digest_failures'].get(str(row['ordinal']))
                    if old is not None:
                        policy = configured_transport_policy(requirement=prepared.requirement, repo_root=ROOT)
                        digest = request_digest(current, policy)
                        groups = [group for group in groups_for(auth)
                                  if group['historical_ordinal'] == row['ordinal']
                                  and group['initial_request_digest'] == digest
                                  and group['metric_id'] == current['metric_id']
                                  and group['company_id'] == current['company_id']
                                  and group['source_id'] == current['source_id']]
                        allowed = (len(groups) == 1
                            and old['intent']['intent_id'] == strict_json_file(path=path/'intent.json')['intent_id']
                            and old['terminal']['terminal_id'] == strict_json_file(path=path/'terminal.json')['terminal_id']
                            and saved['request_id'] == current['request_id']
                            and digest == old['intent']['request_digest'])
                need(allowed, 'B13_SAVED_REQUEST_CHANGED')
            need(identity not in completed, 'B13_DUPLICATE_NATIVE_ASSESSMENT')
            if row['status'] != 'SUCCEEDED':
                failures.append({'request_id': identity, 'ordinal': row['ordinal'], 'status': row['status']})
                continue
            replay = replay_native_response(prepared=prepared, path=path)
            success = replay['success']; acceptance = success['acceptance_receipt']
            terminal = strict_json_file(path=path / 'terminal.json')
            intent = (strict_json_file(path=path / 'intent.json')
                      if (ledger.root / 'recovery-110.json').exists() or batch_history is not None else {})
            if 'recovery_authorization_id' in intent:
                from .continuous_recovery_110 import history_for_success
                history = history_for_success(ledger=ledger, intent=intent, terminal=terminal)
                recovered_failures.append(history)
                failures = [failure for failure in failures
                            if failure['ordinal'] != history['authorization']['original_ordinal']]
            if 'batch_authorization_id' in intent:
                from .continuous_batch33 import group_id, groups_for
                authorized = batch_history['authorization']
                group = next(x for x in groups_for(authorized)
                             if group_id(x) == intent['batch_group_id'])
                if group['historical_ordinal'] in authorized['same_digest_original_ordinals']:
                    original_ordinal = group['historical_ordinal']
                    need(any(failure['ordinal'] == original_ordinal for failure in failures),
                         'BATCH33_ORIGINAL_FAILED_REQUEST_NOT_RETAINED')
                    failures = [failure for failure in failures
                                if failure['ordinal'] != original_ordinal]
                    recovered_batch_failed_ordinals.append(original_ordinal)
                if 'batch_recovery_172_id' in intent:
                    recovery172 = batch_history.get('recovery_172')
                    need(recovery172 is not None
                         and intent['batch_recovery_172_id'] == recovery172['authorization_id']
                         and intent['batch_group_id'] == recovery172['batch_group_id']
                         and any(failure['ordinal'] == recovery172['original_ordinal']
                                 for failure in failures),
                         'BATCH33_HTTP402_ORIGINAL_NOT_RETAINED')
                    failures = [failure for failure in failures
                                if failure['ordinal'] != recovery172['original_ordinal']]
                    recovered_batch_http402_ordinals.append(recovery172['original_ordinal'])
                if 'batch_repair_189_id' in intent:
                    repair189 = batch_history.get('repair_189')
                    need(repair189 is not None
                         and intent['batch_repair_189_id'] == repair189['authorization_id']
                         and intent['batch_group_id'] == repair189['group_id']
                         and any(claim['intent']['ordinal'] == repair189['failed_ordinal']
                                 and claim['terminal'] is not None
                                 and claim['terminal']['status'] == 'FAILED_TERMINAL'
                                 for claim in batch_history['claims']),
                         'BATCH33_ENGINEERING_FAILED_ORIGINAL_NOT_RETAINED')
                    recovered_batch_engineering_ordinals.append(repair189['failed_ordinal'])
                if 'batch_repair_191_id' in intent:
                    v4_enphase = batch_history.get('b13_v4_enphase')
                    need(v4_enphase is not None
                         and intent['batch_repair_191_id'] == v4_enphase['authorization_id']
                         and intent['batch_group_id'] == v4_enphase['failed_group_id']
                         and any(claim['intent']['ordinal'] == v4_enphase['failed_ordinal']
                                 and claim['terminal'] is not None
                                 and claim['terminal']['status'] == 'FAILED_TERMINAL'
                                 for claim in batch_history['claims']),
                         'B13_V4_ENPHASE_FAILED_ORIGINAL_NOT_RETAINED')
                    recovered_batch_engineering_ordinals.append(v4_enphase['failed_ordinal'])
            completed[identity] = {'request_id': identity, 'ordinal': row['ordinal'],
                'terminal_id': terminal['terminal_id'], 'acceptance_receipt_id': success['acceptance_receipt_id'],
                'candidate': acceptance['candidate_record'], 'evidence': acceptance['evidence_record'],
                'source_revalidation': replay['revalidation']}
    missing = [r['request_id'] for r in expected if r['request_id'] not in completed]
    rows = [completed[r['request_id']] for r in expected if r['request_id'] in completed]
    findings = [f for row in rows for f in row['candidate']['selected']['source_assessment']['findings']]
    current = [f for f in findings if f['subject'] == 'TARGET_REGISTRANT' and f['timing'] == 'CURRENT_REPORT']
    kinds = {f['kind'] for f in current}
    relevant = [f for f in findings if f['kind'] in {
        'ACTUAL_PRODUCTION', 'AVAILABLE_CAPACITY', 'CAPACITY_QUALITATIVE', 'PLANNED_CAPACITY'}]
    if metric_id == 'D04':
        from .d04_native_assessment import CURRENT_KINDS
        relevant = [f for f in current if f['kind'] in CURRENT_KINDS]
    if missing:
        branch = 'INCOMPLETE_ASSESSMENT_NOT_NONDISCLOSURE'
    elif metric_id == 'D04' and len(kinds & CURRENT_KINDS) > 1:
        branch = 'CROSS_REQUEST_GOING_CONCERN_RECONCILIATION_REQUIRED'
    elif metric_id == 'B13' and {'ACTUAL_PRODUCTION', 'AVAILABLE_CAPACITY'} <= kinds:
        branch = 'COMPARABLE_QUANTITY_PAIR_ASSESSMENT_REQUIRED'
    elif relevant:
        branch = 'TEXT_QUAL_PROPOSAL_REQUIRES_NATIVE_REVIEW'
    else:
        branch = 'DEFINED_SCOPE_ABSENCE_PROPOSAL_REQUIRES_NATIVE_REVIEW'
    body = {'record_type': metric_id + '_NATIVE_SOURCE_ASSESSMENT_SET', 'source_id': source['semantic_source_id'],
        'company_id': source['company_id'], 'required_request_ids': [r['request_id'] for r in expected],
        'completed': rows, 'missing_request_ids': missing, 'failed_requests': failures,
        'all_source_requests_accepted': not missing, 'proposed_branch': branch,
        'source_findings': findings, 'mode': 'LIVE' if ledger.live else 'RECORDED_TEST_ONLY',
        'metric_result_created': False, 'review_complete': False, 'production_authorized': False}
    if any(version != 'BASE' for version in variants):
        body['native_request_variants'] = variants
    if recovered_failures:
        body['recovered_http402_failures'] = recovered_failures
    if batch_history is not None:
        body['batch_history'] = batch_history
        body['recovered_batch_failed_ordinals'] = sorted(recovered_batch_failed_ordinals)
        if recovered_batch_http402_ordinals:
            body['recovered_batch_http402_ordinals'] = sorted(recovered_batch_http402_ordinals)
        if recovered_batch_engineering_ordinals:
            body['recovered_batch_engineering_ordinals'] = sorted(recovered_batch_engineering_ordinals)
    return {**body, 'assessment_set_id': content_hash(value=body)}
