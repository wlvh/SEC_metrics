# Company separation runtime v1

Inherit issue_28_v14 business semantics and all parent obligations.
Verify complete source histories on the preparation side; computing consumes only the company admission.
Independent installed trust owns admission. Original ledgers, old Runs and closed budgets are unchanged.
Local SEC calls require a separately authorized bounded invocation; installation grants no calls.
No new provider/paid calls, activation, publication or deployment authority.
